# WebView Launcher  (versi 2.1)

Aplikasi Android native (Java murni, 100% offline) untuk menjalankan proyek HTML lokal.

## Yang baru di versi 2.1

- **Dua menu utama**: **Grid Launcher** (menu lama: tambah .zip/.html, tersimpan di daftar) dan **Text Editor**.
- **Text Editor = pengelola berkas + editor kode** (`EditorFragment`, `FileEditorActivity`, `util/DocStore`):
  - Pilih **folder utama** yang diizinkan (Storage Access Framework, tanpa izin "semua berkas"). Tombol **Ganti folder utama**
    ada di tengah atas (antara Impor dan Ekspor), hanya tampil di folder utama.
  - Tiap folder (termasuk folder utama) punya **Impor** di kiri atas (semua jenis berkas, boleh banyak, masuk ke
    folder yang sedang dibuka) dan **Ekspor .zip** di kanan atas (semua berkas dan aset folder itu, disimpan ke
    folder Download dengan nama folder).
  - **3 berkas terakhir diedit** tampil horizontal di atas (bisa digeser); di bawahnya isi folder berupa daftar vertikal.
  - **Tombol tambah**: *Tambah file* (nama + ekstensi bebas, langsung masuk editor) dan *Tambah folder*
    (hanya membuat folder). Tekan lama / titik tiga pada item: ganti nama atau hapus.
  - **Editor layar penuh**: alat di atas, simbol cepat + status di bawah. Ciri khas: lencana warna per jenis berkas,
    simpan otomatis dengan penanda status, tombol Jalankan bulat beraksen.
  - **Jalankan**: .html/.htm/.xhtml/.svg tampil visual (folder disalin sementara agar CSS/JS/gambar relatif
    termuat); berkas lain hanya menghasilkan teks (.js dijalankan dan keluaran console ditampilkan; .py, .css,
    dll. ditampilkan sebagai teks, tidak dieksekusi).
  - Fitur editor: nomor baris, pewarna sintaks (hanya bagian yang terlihat, ringan untuk puluhan ribu baris),
    cari & ganti (opsi Aa / regex), format HTML-CSS-JS, undo/redo, salin / tempel / kosongkan, pergi ke baris,
    duplikat/hapus/pindah baris, komentari, indentasi otomatis, ukuran huruf, simpan otomatis, baris simbol cepat.
    Kode **tidak bisa digeser ke samping**: baris panjang turun ke bawah tanpa menjadi baris baru (nomor baris tetap).
    Berlaku juga untuk penampil Code di info berkas (`CodeLinesView`).
- **Bilah tab bawah datar**: tanpa bayangan dan tanpa lekukan; posisi logo Grid Launcher dan Text Editor tetap.
- **Info berkas > Code**: tombol untuk melihat isi kode berkas (proyek .zip: pilih berkas lain di dalamnya).
- **Pindai Perangkat**: memindai semua folder, hanya menampilkan folder yang berisi html/css/js/zip.
  Tersedia di Tambah HTML (html/zip) dan Library (html/css/js/zip, bisa pilih banyak).
  Membutuhkan izin "Akses semua berkas" (Android 11+) atau izin baca penyimpanan (Android 10 ke bawah).
- **Pratinjau langsung**: WebView Launcher muncul di "Buka dengan" untuk .html/.css/.js.
- **Menu navigasi** (logo 3 garis di kanan atas) dengan animasi halus; berisi **Library** dan **togle bahasa**.
- **Library**: simpan CSS/JS/Bootstrap dll. ke dalam aplikasi; dari HTML cukup tulis nama berkasnya.
- **Togle bahasa**: kiri Indonesia (bawaan), kanan Inggris. Header "WebView Launcher" tidak berubah.
- **Tema** (menu navigasi): togle gelap (kiri, bawaan) / terang (kanan) dan Color: Ungu (bawaan), Oren,
  Coklat, Cyan, Merah, Biru, Kuning, Silver, serta Custom (roda warna HSV penuh + penggeser kecerahan +
  kolom RGB + kolom hex). Tersimpan di SharedPreferences (hilang hanya bila data aplikasi dihapus).
  Warna aksen dipasang lewat `theme/Palette` + `theme/ThemeApplier` (view diberi `android:tag`).
- **Library & Assets**: bisa menyimpan berkas apa pun (css/js/zip, gambar, video, font, dll.).
- **Editor kode**: tanda otomatis (auto-complete) untuk { } ( ) [ ] " ' ` , tag penutup HTML, `</` + nama tag,
  `<!--`, dan Backspace pada pasangan kosong; nomor baris dan warna sintaks selalu aktif; alat editor hanya
  Bungkus baris + penggeser ukuran huruf; tombol Pergi ke baris di toolbar; Kosongkan punya 2 pilihan
  (bisa undo/redo, atau hapus permanen).
- **Code** (info berkas): penampil kode `CodeLinesView` (digambar di kanvas, mulus untuk puluhan ribu baris,
  Pergi ke baris, fling, penggeser cepat); proyek .zip menampilkan folder dulu (`CodeBrowserActivity`).
- **Akses Internet** (togle di menu navigasi, bawaan MATI): mati = 100% offline (semua permintaan
  http/https/ws ke luar diblokir, termasuk CDN, localhost, dan browsing); hidup = diizinkan, tetapi bila
  perangkat tidak punya koneksi internet perilakunya kembali seperti mati. Otomatis mati lagi saat pengguna
  keluar dari aplikasi, kecuali **Aktivitas Latar Belakang** hidup. Proses baru selalu mulai dari mati.
- **Aktivitas Latar Belakang** (togle): bila hidup, selama ada halaman yang terbuka berjalan layanan latar
  depan (dengan notifikasi) supaya sistem tidak mudah mematikan aplikasi, dan togle internet tidak otomatis
  mati saat keluar. Android/OEM tetap bisa membatasi aplikasi (penghemat baterai).

## Tampilan tahan segala ukuran layar
Lihat `docs/UI_GUIDELINES.md`. Label satu baris memakai `android:tag="fit"` (mengecil otomatis), dan
`python3 tools/check_layouts.py` memeriksa layout terhadap pola yang rawan merusak di layar kecil.

## Fitur

- **Pembaca HTML**: tambahkan `.zip` (berisi html/css/js dan file/folder pendukung lain,
  diekstrak otomatis, mencari `index.html`) atau file `.html` tunggal. Dibuka lewat WebView
  layar penuh dengan dukungan modul JavaScript dan fetch(). Tombol kembali menyusut jadi
  garis kecil di atas layar setelah 1.5 detik tak disentuh (ketuk garisnya untuk memunculkan
  lagi).
- **Ikon otomatis** (bila tidak memilih gambar ikon saat menambah):
  - `.zip` yang berisi gambar bernama `icon.png` / `icon.jpg` (juga `.jpeg`, `.webp`) memakai
    gambar itu. Yang paling dekat dengan akar zip diutamakan. Gambar dipotong persegi dari
    tengah, dan bila masih kotak bersudut tajam, sudutnya dibulatkan sedikit agar halus.
    Gambar yang sudutnya sudah transparan dibiarkan apa adanya.
  - Tidak ada icon di dalam zip: ikon oranye (HTML) atau hijau (.zip) seperti sebelumnya.
- **Nama otomatis** (bila kolom nama kosong): diambil dari nama berkas, dengan spasi di setiap
  huruf besar dan garis bawah/strip jadi spasi.
  `WebviewLauncher.zip` → `Webview Launcher`, `Webview_Launcher.html` → `Webview Launcher`.
  Singkatan tetap utuh (`HTMLParser` → `HTML Parser`).
- **Splash screen** memakai logo tanpa background (`res/drawable-nodpi/splash_logo.png`) di atas
  latar `#202835`, warna yang sama dengan latar ikon aplikasi. (Android 12+ menampilkan splash
  bawaan sistem dengan ikon aplikasi sepersekian detik sebelum splash ini; itu perilaku sistem.)
- **Ikon adaptif** (Android 8+): foto ikon yang sama di atas latar `#202835`, supaya splash bawaan
  Android 12+ tidak lagi menampilkan kotak putih di belakang ikon. Android 7 ke bawah memakai
  `ic_launcher.jpg` seperti biasa.
- **Tekan lama** pada item di grid: muncul pilihan bergambar **tanda seru** (info berkas) dan
  **tempat sampah** (hapus).
- **Info berkas**: menampilkan nama tampilan, nama berkas asli, lokasi folder asal berkas
  (mis. `Download/WebViewLauncher/WebViewLauncher.zip`), ukuran, jenis (.zip/.html), dan kapan
  berkas ditambahkan. Untuk item yang ditambahkan sebelum fitur ini ada, kolom yang tidak
  tersimpan ditampilkan sebagai "Tidak diketahui".
- Tema warna ungu-toska gelap, seluruh ikon berupa gambar vector buatan sendiri.

Fitur PDF reader dari versi 1.0 sudah dihapus. Sisa daftar PDF lama dibersihkan otomatis saat
aplikasi diperbarui.

## Cara build APK

Proyek Android Studio standar (Gradle, Java).

1. Buka **Android Studio** → `Open` → pilih folder `WebViewLauncher`.
2. Tunggu Gradle sync selesai (butuh internet pertama kali untuk mengunduh dependensi AndroidX).
3. `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`.
4. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

Alternatif: `./gradlew assembleDebug` (jalankan `gradle wrapper` dulu bila `gradlew` belum ada),
atau import folder ini di aplikasi IDE Android seperti CodeAssist.

## Struktur singkat kode

- `SplashActivity` — splash screen, lalu membuka `MainActivity`
- `App` — bahasa, aturan auto-mati internet saat keluar aplikasi, layanan latar belakang
- `util/InternetPolicy`, `service/KeepAliveService`, `widget/OnOffToggle` — Akses Internet & Latar Belakang
- `MainActivity` — header, logo menu, tab Grid Launcher/Text Editor (ViewPager2), panel navigasi
- `GameFragment` — menu Grid: grid proyek HTML, dialog hapus
- `EditorFragment` — menu Text Editor: pengelola berkas (folder utama, impor, ekspor .zip, tambah file/folder)
- `FileEditorActivity` — editor teks layar penuh + Jalankan
- `util/DocStore`, `util/FileKind`, `util/FileRunner`, `util/ZipExporter` — akses folder (SAF), jenis berkas, penyiapan Jalankan, ekspor .zip
- `CodeViewActivity` — tombol Code di info berkas
- `ScanActivity` — Pindai Perangkat (`util/StorageScanner`)
- `widget/CodeEditText`, `util/SyntaxHighlighter`, `util/CodeFormatter` — komponen editor kode
- `LibraryActivity` — daftar dan tambah/hapus berkas Library
- `PreviewActivity` — pratinjau berkas dari aplikasi lain ("Buka dengan")
- `AddGameActivity` — tambah proyek (ikon & nama otomatis)
- `WebGameActivity` — WebView layar penuh, navigasi collapse lewat `widget/CollapsibleNav`
- `util/LibraryStore`, `util/EditorBuilder`, `util/DialogUtils` — Library, penyusun proyek (lama), dialog konfirmasi
- `widget/HamburgerView`, `widget/LangToggle` — logo menu dan togle bahasa
- `util/ProjectImporter` — logika memasukkan proyek ke daftar
- `util/ZipExtractor` — ekstraksi zip, cari `index.html` dan `icon.*`
- `util/IconUtils`, `util/DocumentIconGenerator`, `util/NameFormatter` — ikon dan nama otomatis
- `data/DataStore` — penyimpanan daftar ke JSON lokal
