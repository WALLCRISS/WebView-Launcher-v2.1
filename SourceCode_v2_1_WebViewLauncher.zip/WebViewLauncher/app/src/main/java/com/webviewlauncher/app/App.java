package com.webviewlauncher.app;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import androidx.core.os.LocaleListCompat;

import com.webviewlauncher.app.service.KeepAliveService;
import com.webviewlauncher.app.util.FileUtils;
import com.webviewlauncher.app.util.InternetPolicy;

import java.io.File;

/**
 * - Menerapkan bahasa pilihan pengguna (bawaan: Indonesia) setiap aplikasi dimulai.
 * - Membersihkan sisa berkas pratinjau dari sesi sebelumnya.
 * - Akses Internet selalu MATI saat aplikasi baru mulai, dan otomatis dimatikan saat pengguna
 *   keluar dari aplikasi, KECUALI Aktivitas Latar Belakang sedang hidup.
 * - Menjalankan layanan latar depan selama Aktivitas Latar Belakang hidup dan ada halaman
 *   (Grid/Flash/pratinjau) yang sedang terbuka.
 */
public class App extends Application {

    public static final String PREFS = "settings";
    public static final String KEY_LANG = "lang";

    private static final long LEAVE_DELAY_MS = 800;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int startedCount = 0;
    private int webCount = 0;

    private final Runnable leaveCheck = () -> {
        if (startedCount == 0 && InternetPolicy.isEnabled(this) && !InternetPolicy.isBackground(this)) {
            InternetPolicy.setEnabled(this, false);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        com.webviewlauncher.app.theme.Palette.load(this);
        com.webviewlauncher.app.theme.Palette.applyNightMode(this);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String lang = prefs.getString(KEY_LANG, "id");
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(lang));

        // Proses baru = aplikasi baru dibuka: internet kembali MATI.
        InternetPolicy.setEnabled(this, false);

        new Thread(() -> FileUtils.deleteRecursive(new File(getFilesDir(), "preview"))).start();

        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity a, Bundle b) {
                if (a instanceof WebGameActivity) {
                    webCount++;
                    syncService(App.this);
                }
            }

            @Override
            public void onActivityStarted(Activity a) {
                startedCount++;
                handler.removeCallbacks(leaveCheck);
            }

            @Override
            public void onActivityResumed(Activity a) {
            }

            @Override
            public void onActivityPaused(Activity a) {
            }

            @Override
            public void onActivityStopped(Activity a) {
                startedCount--;
                if (startedCount <= 0) {
                    startedCount = 0;
                    handler.removeCallbacks(leaveCheck);
                    handler.postDelayed(leaveCheck, LEAVE_DELAY_MS);
                }
            }

            @Override
            public void onActivitySaveInstanceState(Activity a, Bundle b) {
            }

            @Override
            public void onActivityDestroyed(Activity a) {
                if (a instanceof WebGameActivity) {
                    webCount = Math.max(0, webCount - 1);
                    syncService(App.this);
                }
            }
        });
    }

    /** Menyalakan/mematikan layanan latar depan sesuai togle dan jumlah halaman yang terbuka. */
    public static void syncService(Context ctx) {
        App app = (App) ctx.getApplicationContext();
        boolean want = InternetPolicy.isBackground(app) && app.webCount > 0;
        Intent svc = new Intent(app, KeepAliveService.class);
        try {
            if (want) ContextCompat.startForegroundService(app, svc);
            else app.stopService(svc);
        } catch (Exception ignored) {
        }
    }
}
