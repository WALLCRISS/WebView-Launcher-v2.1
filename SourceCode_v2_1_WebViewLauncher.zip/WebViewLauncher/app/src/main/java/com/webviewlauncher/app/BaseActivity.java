package com.webviewlauncher.app;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.LayoutRes;
import androidx.appcompat.app.AppCompatActivity;

import com.webviewlauncher.app.theme.Palette;
import com.webviewlauncher.app.theme.ThemeApplier;

/**
 * Dasar semua layar: memasang warna aksen tema ke view bertag setelah layout dibuat, dan membuat
 * ulang layar bila warna tema diubah dari layar lain.
 */
public abstract class BaseActivity extends AppCompatActivity {

    private int themeVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        themeVersion = Palette.version;
    }

    @Override
    public void setContentView(@LayoutRes int layoutResID) {
        super.setContentView(layoutResID);
        ThemeApplier.apply(findViewById(android.R.id.content));
    }

    protected boolean recreateOnThemeChange() {
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (themeVersion != Palette.version) {
            themeVersion = Palette.version;
            if (recreateOnThemeChange()) recreate();
        }
    }
}
