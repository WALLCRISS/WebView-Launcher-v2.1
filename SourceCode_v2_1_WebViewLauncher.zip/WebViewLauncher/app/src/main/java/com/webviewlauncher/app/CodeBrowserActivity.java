package com.webviewlauncher.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.webviewlauncher.app.theme.ThemeApplier;
import com.webviewlauncher.app.util.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Penjelajah isi proyek .zip: menampilkan folder (yang di dalamnya ada berkas html/css/js dll.)
 * lalu berkas-berkasnya. Ketuk berkas untuk melihat kodenya.
 */
public class CodeBrowserActivity extends BaseActivity {

    private static final String[] TEXT_EXT = {"html", "htm", "xhtml", "css", "js", "mjs", "json", "txt",
            "md", "svg", "xml", "csv", "yml", "yaml"};

    private static final class Row {
        File file;
        boolean dir;
        int count;
    }

    private File root;
    private File current;
    private TextView title;
    private TextView empty;
    private View progress;
    private RecyclerView list;
    private final List<Row> rows = new ArrayList<>();
    private Adapter adapter;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean destroyed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_browser);

        String rootPath = getIntent().getStringExtra("root_path");
        if (rootPath == null) {
            finish();
            return;
        }
        root = new File(rootPath);
        current = root;

        title = findViewById(R.id.browserTitle);
        empty = findViewById(R.id.browserEmpty);
        progress = findViewById(R.id.progressBar);
        list = findViewById(R.id.browserList);
        adapter = new Adapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        findViewById(R.id.backButton).setOnClickListener(v -> goUp());
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                goUp();
            }
        });
        String name = getIntent().getStringExtra("title");
        title.setText(name == null ? root.getName() : name);
        open(root);
    }

    private void goUp() {
        if (current != null && !current.equals(root)) open(current.getParentFile());
        else finish();
    }

    private static boolean isText(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        int dot = n.lastIndexOf('.');
        if (dot < 0) return false;
        String ext = n.substring(dot + 1);
        for (String e : TEXT_EXT) if (e.equals(ext)) return true;
        return false;
    }

    /** Jumlah berkas teks di dalam folder (rekursif, dibatasi kedalaman). */
    private static int countText(File dir, int depth) {
        if (depth > 10) return 0;
        File[] kids = dir.listFiles();
        if (kids == null) return 0;
        int c = 0;
        for (File k : kids) {
            if (k.isDirectory()) c += countText(k, depth + 1);
            else if (isText(k.getName())) c++;
        }
        return c;
    }

    private void open(final File dir) {
        current = dir;
        String rel = dir.equals(root) ? "" : dir.getAbsolutePath().substring(root.getAbsolutePath().length());
        String name = getIntent().getStringExtra("title");
        title.setText((name == null ? root.getName() : name) + rel);
        progress.setVisibility(View.VISIBLE);
        empty.setVisibility(View.GONE);
        new Thread(() -> {
            final List<Row> result = new ArrayList<>();
            File[] kids = dir.listFiles();
            if (kids != null) {
                for (File k : kids) {
                    Row r = new Row();
                    r.file = k;
                    if (k.isDirectory()) {
                        r.count = countText(k, 0);
                        if (r.count == 0) continue;     // hanya folder yang berisi berkas kode
                        r.dir = true;
                        result.add(r);
                    } else if (isText(k.getName())) {
                        result.add(r);
                    }
                }
            }
            Collections.sort(result, new Comparator<Row>() {
                @Override
                public int compare(Row a, Row b) {
                    if (a.dir != b.dir) return a.dir ? -1 : 1;
                    return a.file.getName().compareToIgnoreCase(b.file.getName());
                }
            });
            handler.post(() -> {
                if (destroyed) return;
                rows.clear();
                rows.addAll(result);
                adapter.notifyDataSetChanged();
                progress.setVisibility(View.GONE);
                empty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
                list.scrollToPosition(0);
            });
        }).start();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.VH> {

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_scan, parent, false);
            ThemeApplier.apply(v);
            return new VH(v);
        }

        @Override
        public int getItemCount() {
            return rows.size();
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            final Row r = rows.get(position);
            h.icon.setImageResource(r.dir ? R.drawable.ic_folder : R.drawable.ic_file);
            h.name.setText(r.file.getName());
            h.check.setVisibility(View.GONE);
            if (r.dir) {
                h.info.setText(getString(R.string.scan_folder_info, r.count));
                h.itemView.setOnClickListener(v -> open(r.file));
            } else {
                h.info.setText(FileUtils.formatFileSize(r.file.length()));
                h.itemView.setOnClickListener(v -> {
                    Intent i = new Intent(CodeBrowserActivity.this, CodeViewActivity.class);
                    i.putExtra("entry_path", r.file.getAbsolutePath());
                    i.putExtra("root_path", root.getAbsolutePath());
                    startActivity(i);
                });
            }
        }

        class VH extends RecyclerView.ViewHolder {
            final ImageView icon;
            final TextView name;
            final TextView info;
            final android.widget.CheckBox check;

            VH(@NonNull View v) {
                super(v);
                icon = v.findViewById(R.id.itemIcon);
                name = v.findViewById(R.id.itemName);
                info = v.findViewById(R.id.itemInfo);
                check = v.findViewById(R.id.itemCheck);
            }
        }
    }
}
