package com.webviewlauncher.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.webviewlauncher.app.util.DialogUtils;
import com.webviewlauncher.app.util.FileUtils;
import com.webviewlauncher.app.util.SyntaxHighlighter;
import com.webviewlauncher.app.widget.CodeLinesView;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Penampil kode baca-saja (dari tombol "Code" di info berkas, atau dari penjelajah folder proyek
 * .zip). Memakai {@link CodeLinesView} yang hanya menggambar baris yang terlihat, jadi file
 * puluhan ribu baris tetap mulus. Punya tombol "Pergi ke baris" dan salin.
 */
public class CodeViewActivity extends BaseActivity {

    /** Batas pengaman membaca satu berkas; 25 ribu baris kode biasanya hanya ±1 MB. */
    private static final long MAX_BYTES = 50L * 1024 * 1024;

    private CodeLinesView codeView;
    private TextView fileInfo;
    private View progress;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean destroyed = false;
    private String fullText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_view);

        codeView = findViewById(R.id.codeView);
        fileInfo = findViewById(R.id.fileInfo);
        progress = findViewById(R.id.progressBar);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.copyButton).setOnClickListener(v -> copy(fullText, R.string.copied));
        findViewById(R.id.gotoButton).setOnClickListener(v -> promptGoTo());
        codeView.setLineListener((idx, text) -> copy(text, R.string.line_copied));
        codeView.setTextSizeSp(getSharedPreferences(App.PREFS, MODE_PRIVATE).getFloat("editor_font", 13f));

        String entryPath = getIntent().getStringExtra("entry_path");
        String rootPath = getIntent().getStringExtra("root_path");
        if (entryPath == null) {
            finish();
            return;
        }
        File file = new File(entryPath);
        String shown = file.getName();
        if (rootPath != null && entryPath.startsWith(rootPath)) {
            shown = entryPath.substring(rootPath.length());
            while (shown.startsWith("/")) shown = shown.substring(1);
        }
        ((TextView) findViewById(R.id.fileName)).setText(shown);
        load(file);
    }

    private static int languageOf(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".css")) return SyntaxHighlighter.LANG_CSS;
        if (n.endsWith(".js") || n.endsWith(".mjs") || n.endsWith(".json")) return SyntaxHighlighter.LANG_JS;
        if (n.endsWith(".html") || n.endsWith(".htm") || n.endsWith(".xhtml") || n.endsWith(".svg")
                || n.endsWith(".xml")) return SyntaxHighlighter.LANG_HTML;
        return SyntaxHighlighter.LANG_NONE;
    }

    private void load(final File file) {
        progress.setVisibility(View.VISIBLE);
        final int lang = languageOf(file.getName());
        new Thread(() -> {
            String text = null;
            String[] lines = null;
            try (FileInputStream in = new FileInputStream(file)) {
                int toRead = (int) Math.min(file.length(), MAX_BYTES);
                byte[] buf = new byte[toRead];
                int off = 0;
                while (off < toRead) {
                    int r = in.read(buf, off, toRead - off);
                    if (r < 0) break;
                    off += r;
                }
                text = new String(buf, 0, off, StandardCharsets.UTF_8);
                lines = splitLines(text);
            } catch (IOException | RuntimeException | OutOfMemoryError e) {
                text = null;
            }
            final String fText = text;
            final String[] fLines = lines;
            handler.post(() -> {
                if (destroyed) return;
                progress.setVisibility(View.GONE);
                if (fText == null || fLines == null) {
                    Toast.makeText(this, R.string.code_read_failed, Toast.LENGTH_LONG).show();
                    return;
                }
                fullText = fText;
                codeView.setLines(fLines, lang);
                fileInfo.setText(getString(R.string.code_lines_size, fLines.length,
                        FileUtils.formatFileSize(file.length())));
            });
        }).start();
    }

    /** Memecah teks menjadi baris (menangani \n, \r\n, \r) dan mengganti tab dengan 2 spasi. */
    private static String[] splitLines(String text) {
        List<String> out = new ArrayList<>(Math.max(16, text.length() / 40));
        int n = text.length();
        int start = 0;
        for (int i = 0; i < n; i++) {
            char c = text.charAt(i);
            if (c == '\n' || c == '\r') {
                out.add(clean(text, start, i));
                if (c == '\r' && i + 1 < n && text.charAt(i + 1) == '\n') i++;
                start = i + 1;
            }
        }
        if (start <= n) out.add(clean(text, start, n));
        return out.toArray(new String[0]);
    }

    private static String clean(String t, int a, int b) {
        String s = t.substring(a, b);
        return s.indexOf('\t') >= 0 ? s.replace("\t", "  ") : s;
    }

    private void promptGoTo() {
        final int total = codeView.getLineCount();
        if (total == 0) return;
        DialogUtils.promptNumber(this, getString(R.string.goto_title),
                getString(R.string.goto_hint, total), getString(R.string.goto_confirm), text -> {
                    try {
                        codeView.goToLine(Math.max(1, Math.min(Integer.parseInt(text), total)));
                    } catch (NumberFormatException ignored) {
                    }
                });
    }

    private void copy(String text, int toastRes) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("code", text));
            Toast.makeText(this, toastRes, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, R.string.copy_failed, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
