package com.webviewlauncher.app;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.webviewlauncher.app.theme.ThemeApplier;
import com.webviewlauncher.app.util.DialogUtils;
import com.webviewlauncher.app.util.DocStore;
import com.webviewlauncher.app.util.FileKind;
import com.webviewlauncher.app.util.FileUtils;
import com.webviewlauncher.app.util.ZipExporter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Menu Text Editor: pengelola berkas untuk folder utama yang dipilih (dan diizinkan) pengguna.
 *
 * Tiap folder (termasuk direktori utama) tampil sama: impor di kiri atas, ekspor .zip di kanan atas,
 * 3 berkas yang terakhir diedit berjajar horizontal di atas (bisa digeser), lalu isi folder berupa
 * daftar vertikal. Tombol tambah membuat file (nama + ekstensi bebas, langsung dibuka di editor)
 * atau folder (hanya dibuat). Mengetuk berkas membuka {@link FileEditorActivity} layar penuh.
 *
 * Penyimpanan memakai Storage Access Framework (lihat {@link DocStore}), jadi tidak butuh izin
 * "semua berkas": pengguna cukup memilih folder sekali.
 */
public class EditorFragment extends Fragment {

    private static final String PREF_TREE = "editor_tree_uri";
    private static final String STATE_IMPORT_TARGET = "import_target";
    private static final ExecutorService IO = Executors.newFixedThreadPool(2);

    private static final int T_RECENTS = 0;
    private static final int T_LABEL = 1;
    private static final int T_UP = 2;
    private static final int T_ROW = 3;

    /** Satu tingkat navigasi: id dokumen + nama tampilan. */
    private static final class Folder {
        final String docId;
        String name;

        Folder(String docId, String name) {
            this.docId = docId;
            this.name = name;
        }
    }

    /** Satu baris di RecyclerView. */
    private static final class Row {
        final int type;
        final DocStore.Node node;
        final List<DocStore.Node> recents;

        Row(int type, DocStore.Node node, List<DocStore.Node> recents) {
            this.type = type;
            this.node = node;
            this.recents = recents;
        }
    }

    private final ArrayList<Folder> stack = new ArrayList<>();
    private final ArrayList<Row> rows = new ArrayList<>();

    private SharedPreferences prefs;
    private DocStore store;
    private Uri treeUri;
    private RowAdapter adapter;
    private OnBackPressedCallback backCallback;

    private TextView titleView;
    private TextView pathView;
    private View btnImport;
    private View btnExport;
    private View changeRow;
    private View busy;
    private View emptyFolder;
    private View noRoot;
    private View fab;
    private RecyclerView list;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean viewAlive = false;
    private int generation = 0;
    private int busyCount = 0;
    private String pendingImportTarget;
    private Folder pendingExport;

    private final ActivityResultLauncher<Uri> pickTree = registerForActivityResult(
            new ActivityResultContracts.OpenDocumentTree(), this::onTreePicked);
    private final ActivityResultLauncher<String[]> pickFiles = registerForActivityResult(
            new ActivityResultContracts.OpenMultipleDocuments(), this::onFilesPicked);
    private final ActivityResultLauncher<String> askStorage = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                Folder f = pendingExport;
                pendingExport = null;
                if (f == null) return;
                if (granted) doExport(f);
                else toast(getString(R.string.fm_need_storage));
            });

    // ------------------------------------------------------------ siklus hidup

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_editor, container, false);
        viewAlive = true;
        busyCount = 0;
        prefs = requireContext().getSharedPreferences(App.PREFS, Context.MODE_PRIVATE);
        if (savedInstanceState != null) pendingImportTarget = savedInstanceState.getString(STATE_IMPORT_TARGET);

        titleView = root.findViewById(R.id.fmTitle);
        pathView = root.findViewById(R.id.fmPath);
        btnImport = root.findViewById(R.id.fmImport);
        btnExport = root.findViewById(R.id.fmExport);
        changeRow = root.findViewById(R.id.fmChange);
        busy = root.findViewById(R.id.fmBusy);
        emptyFolder = root.findViewById(R.id.fmEmpty);
        noRoot = root.findViewById(R.id.fmNoRoot);
        fab = root.findViewById(R.id.fmFab);
        list = root.findViewById(R.id.fmList);

        adapter = new RowAdapter();
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        list.setAdapter(adapter);
        list.setItemAnimator(null);

        root.findViewById(R.id.fmChoose).setOnClickListener(v -> pickTree.launch(null));
        root.findViewById(R.id.fmChange).setOnClickListener(v -> pickTree.launch(null));
        btnImport.setOnClickListener(v -> startImport());
        btnExport.setOnClickListener(v -> startExport());
        fab.setOnClickListener(v -> showAddMenu());

        // Tombol kembali sistem: naik satu folder (hanya aktif saat halaman ini yang tampil).
        backCallback = new OnBackPressedCallback(false) {
            @Override
            public void handleOnBackPressed() {
                MainActivity main = (MainActivity) getActivity();
                if (main != null && main.closeNavIfOpen()) return;
                goUp();
            }
        };

        loadRoot();
        ThemeApplier.apply(root);
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // getViewLifecycleOwner() baru boleh dipakai di sini, bukan di onCreateView.
        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(), backCallback);
    }

    @Override
    public void onResume() {
        super.onResume();
        backCallback.setEnabled(stack.size() > 1);
        // Setelah kembali dari editor / layar lain: segarkan daftar dan "terakhir diedit".
        if (store != null) refresh();
    }

    @Override
    public void onPause() {
        super.onPause();
        if (backCallback != null) backCallback.setEnabled(false);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (pendingImportTarget != null) outState.putString(STATE_IMPORT_TARGET, pendingImportTarget);
    }

    @Override
    public void onDestroyView() {
        viewAlive = false;
        generation++;
        handler.removeCallbacksAndMessages(null);
        super.onDestroyView();
    }

    // ------------------------------------------------------------ folder utama

    /** Memuat folder utama tersimpan; bila izinnya hilang kembali ke layar "Pilih folder". */
    private void loadRoot() {
        store = null;
        treeUri = null;
        stack.clear();
        String saved = prefs.getString(PREF_TREE, null);
        if (saved != null) {
            Uri uri = Uri.parse(saved);
            boolean granted = false;
            for (UriPermission p : requireContext().getContentResolver().getPersistedUriPermissions()) {
                if (p.getUri().equals(uri) && p.isReadPermission() && p.isWritePermission()) {
                    granted = true;
                    break;
                }
            }
            if (granted) {
                treeUri = uri;
                store = new DocStore(requireContext(), uri);
                stack.add(new Folder(store.rootId(), null));
            } else {
                prefs.edit().remove(PREF_TREE).apply();
                toast(getString(R.string.fm_access_lost));
            }
        }
        render(null);
    }

    private void onTreePicked(@Nullable Uri uri) {
        if (uri == null || !viewAlive) return;
        try {
            requireContext().getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (SecurityException e) {
            toast(getString(R.string.fm_access_lost));
            return;
        }
        // Lepas izin folder utama yang lama agar daftar izin sistem tidak menumpuk.
        String old = prefs.getString(PREF_TREE, null);
        if (old != null && !old.equals(uri.toString())) {
            try {
                requireContext().getContentResolver().releasePersistableUriPermission(Uri.parse(old),
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {
            }
        }
        prefs.edit().putString(PREF_TREE, uri.toString()).apply();
        loadRoot();
        refresh();
    }

    // ------------------------------------------------------------ navigasi & daftar

    private Folder current() {
        return stack.get(stack.size() - 1);
    }

    private String currentRel() {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i < stack.size(); i++) {
            if (sb.length() > 0) sb.append('/');
            sb.append(stack.get(i).name);
        }
        return sb.toString();
    }

    private void goUp() {
        if (stack.size() <= 1) return;
        stack.remove(stack.size() - 1);
        backCallback.setEnabled(stack.size() > 1);
        refresh();
    }

    private void openFolder(DocStore.Node n) {
        stack.add(new Folder(n.docId, n.name));
        backCallback.setEnabled(true);
        refresh();
    }

    /** Memindai folder sekarang di thread latar, lalu menggambar ulang daftar. */
    private void refresh() {
        if (!viewAlive) return;
        if (store == null) {
            render(null);
            return;
        }
        final int gen = ++generation;
        final Folder f = current();
        final DocStore s = store;
        setBusy(true);
        IO.execute(() -> {
            DocStore.Scan scan = null;
            String rootName = null;
            boolean ok = true;
            try {
                if (f.name == null) rootName = s.rootName();
                scan = s.scan(f.docId);
            } catch (Exception e) {
                ok = false;
            }
            final DocStore.Scan result = scan;
            final String rn = rootName;
            final boolean success = ok;
            handler.post(() -> {
                if (!viewAlive) return;
                setBusy(false);
                if (gen != generation) return;      // sudah ada pemindaian yang lebih baru
                if (rn != null && f.name == null) f.name = rn;
                if (!success) {
                    // Folder dihapus / izin dicabut di luar aplikasi.
                    if (!s.isAccessible()) {
                        prefs.edit().remove(PREF_TREE).apply();
                        toast(getString(R.string.fm_access_lost));
                        loadRoot();
                    } else if (stack.size() > 1) {
                        goUp();          // folder ini hilang: kembali ke atasnya
                    }
                    return;
                }
                render(result);
            });
        });
    }

    private void setBusy(boolean on) {
        busyCount = Math.max(0, busyCount + (on ? 1 : -1));
        if (busy != null) busy.setVisibility(busyCount > 0 ? View.VISIBLE : View.INVISIBLE);
    }

    private void render(@Nullable DocStore.Scan scan) {
        if (!viewAlive) return;
        boolean hasRoot = store != null;
        noRoot.setVisibility(hasRoot ? View.GONE : View.VISIBLE);
        fab.setVisibility(hasRoot ? View.VISIBLE : View.GONE);
        btnImport.setVisibility(hasRoot ? View.VISIBLE : View.INVISIBLE);
        btnExport.setVisibility(hasRoot ? View.VISIBLE : View.INVISIBLE);
        changeRow.setVisibility(hasRoot && stack.size() == 1 ? View.VISIBLE : View.GONE);

        rows.clear();
        if (!hasRoot) {
            titleView.setText(R.string.fm_title_default);
            pathView.setText("");
            emptyFolder.setVisibility(View.GONE);
            adapter.notifyDataSetChanged();
            backCallback.setEnabled(false);
            return;
        }

        Folder f = current();
        titleView.setText(f.name != null ? f.name : getString(R.string.fm_title_default));
        StringBuilder path = new StringBuilder();
        for (int i = 0; i < stack.size(); i++) {
            if (i > 0) path.append("  ›  ");
            String n = stack.get(i).name;
            path.append(n != null ? n : "…");
        }
        pathView.setText(path.toString());

        if (scan != null) {
            Set<String> recentIds = new HashSet<>();
            if (!scan.recents.isEmpty()) {
                rows.add(new Row(T_RECENTS, null, scan.recents));
                for (DocStore.Node r : scan.recents) recentIds.add(r.docId);
            }
            if (stack.size() > 1) rows.add(new Row(T_UP, null, null));

            List<DocStore.Node> rest = new ArrayList<>();
            for (DocStore.Node n : scan.children) {
                if (!n.dir && recentIds.contains(n.docId)) continue;   // sudah tampil di kartu atas
                rest.add(n);
            }
            if (!scan.recents.isEmpty() && !rest.isEmpty()) rows.add(new Row(T_LABEL, null, null));
            for (DocStore.Node n : rest) rows.add(new Row(T_ROW, n, null));
            emptyFolder.setVisibility(scan.children.isEmpty() ? View.VISIBLE : View.GONE);
        } else {
            emptyFolder.setVisibility(View.GONE);
        }
        adapter.notifyDataSetChanged();
        backCallback.setEnabled(stack.size() > 1 && isResumed());
    }

    // ------------------------------------------------------------ buka berkas

    private void openFile(DocStore.Node n) {
        if (store == null) return;
        String ext = FileKind.ext(n.name);
        if (FileKind.isBinary(ext)) {
            // Gambar, audio, video, zip, dll.: dibuka di aplikasi lain (bukan editor teks).
            try {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(store.docUri(n.docId), FileKind.mimeFor(ext));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(i);
            } catch (Exception e) {
                toast(getString(R.string.fm_open_failed));
            }
            return;
        }
        String fullRel = n.rel;
        String base = currentRel();
        if (!base.isEmpty()) fullRel = base + "/" + n.rel;
        launchEditor(n.docId, n.parentId, n.name, fullRel);
    }

    private void launchEditor(String docId, String parentId, String name, String relPath) {
        Intent i = new Intent(requireContext(), FileEditorActivity.class);
        i.putExtra(FileEditorActivity.EXTRA_TREE, treeUri.toString());
        i.putExtra(FileEditorActivity.EXTRA_DOC, docId);
        i.putExtra(FileEditorActivity.EXTRA_PARENT, parentId);
        i.putExtra(FileEditorActivity.EXTRA_NAME, name);
        i.putExtra(FileEditorActivity.EXTRA_REL, relPath);
        startActivity(i);
    }

    // ------------------------------------------------------------ tambah file / folder

    private void showAddMenu() {
        if (store == null) return;
        final Context ctx = requireContext();
        View view = LayoutInflater.from(ctx).inflate(R.layout.dialog_add_menu, null);
        ThemeApplier.apply(view);
        final Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(view);
        view.findViewById(R.id.addCancel).setOnClickListener(v -> dialog.dismiss());
        view.findViewById(R.id.addFile).setOnClickListener(v -> {
            dialog.dismiss();
            promptNewFile();
        });
        view.findViewById(R.id.addFolder).setOnClickListener(v -> {
            dialog.dismiss();
            promptNewFolder();
        });
        showDialog(dialog);
    }

    private interface OnName {
        void run(String name, String ext);
    }

    /**
     * Dialog nama (dan ekstensi bila withExt). Ekstensi bebas apa pun; deretan chip hanya jalan pintas.
     */
    private void showNameDialog(String title, String positive, String name, String ext, boolean withExt,
                                OnName cb) {
        final Context ctx = requireContext();
        View view = LayoutInflater.from(ctx).inflate(R.layout.dialog_name, null);
        ThemeApplier.apply(view);
        ((TextView) view.findViewById(R.id.nameTitle)).setText(title);
        final EditText nameField = view.findViewById(R.id.nameField);
        final EditText extField = view.findViewById(R.id.extField);
        TextView pos = view.findViewById(R.id.namePositive);
        pos.setText(positive);
        nameField.setText(name);
        nameField.setSelection(nameField.length());
        extField.setText(ext);

        view.findViewById(R.id.extBox).setVisibility(withExt ? View.VISIBLE : View.GONE);
        View chipsScroll = view.findViewById(R.id.extChipsScroll);
        chipsScroll.setVisibility(withExt ? View.VISIBLE : View.GONE);
        if (withExt) {
            LinearLayout chips = view.findViewById(R.id.extChips);
            float d = getResources().getDisplayMetrics().density;
            for (final String e : new String[]{"html", "css", "js", "json", "py", "txt", "md"}) {
                TextView chip = new TextView(ctx);
                chip.setText("." + e);
                chip.setTextSize(13f);
                chip.setTypeface(android.graphics.Typeface.MONOSPACE);
                chip.setGravity(Gravity.CENTER);
                chip.setTextColor(ContextCompat.getColor(ctx, R.color.text_primary));
                chip.setBackgroundResource(R.drawable.bg_key);
                chip.setClickable(true);
                chip.setPadding((int) (12 * d), 0, (int) (12 * d), 0);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, (int) (34 * d));
                lp.setMargins(0, 0, (int) (6 * d), 0);
                chip.setLayoutParams(lp);
                chip.setOnClickListener(v -> {
                    extField.setText(e);
                    extField.setSelection(extField.length());
                });
                chips.addView(chip);
            }
        }

        final Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(view);
        view.findViewById(R.id.nameNegative).setOnClickListener(v -> dialog.dismiss());
        pos.setOnClickListener(v -> {
            String n = nameField.getText().toString().trim();
            String e = withExt ? extField.getText().toString().trim() : "";
            while (e.startsWith(".")) e = e.substring(1);
            if (n.isEmpty()) {
                toast(getString(R.string.fm_name_empty));
                return;
            }
            if (!validName(n) || !validName(e)) {
                toast(getString(R.string.fm_name_invalid));
                return;
            }
            dialog.dismiss();
            cb.run(n, e);
        });
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setLayout(DialogUtils.dialogWidth(ctx), ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        }
        nameField.requestFocus();
    }

    private static boolean validName(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '/' || c == '\\' || c == ':' || c == '*' || c == '?' || c == '"'
                    || c == '<' || c == '>' || c == '|' || c < 32) {
                return false;
            }
        }
        return !s.equals(".") && !s.equals("..");
    }

    private static String joinName(String name, String ext) {
        return ext.isEmpty() ? name : name + "." + ext;
    }

    /** Tambah file: dibuat di folder yang sedang dibuka, lalu otomatis masuk mode edit. */
    private void promptNewFile() {
        showNameDialog(getString(R.string.fm_new_file_title), getString(R.string.fm_create), "", "", true,
                (name, ext) -> createFile(joinName(name, ext)));
    }

    private void createFile(final String fullName) {
        final DocStore s = store;
        final Folder f = current();
        final String rel = currentRel();
        setBusy(true);
        IO.execute(() -> {
            DocStore.Node created = null;
            boolean exists = false;
            try {
                if (s.exists(f.docId, fullName)) exists = true;
                else created = s.createFile(f.docId, fullName);
            } catch (Exception ignored) {
            }
            final DocStore.Node node = created;
            final boolean dup = exists;
            handler.post(() -> {
                if (!viewAlive) return;
                setBusy(false);
                if (dup) {
                    toast(getString(R.string.fm_name_exists, fullName));
                } else if (node == null) {
                    toast(getString(R.string.fm_create_failed));
                } else {
                    String fullRel = rel.isEmpty() ? node.name : rel + "/" + node.name;
                    launchEditor(node.docId, f.docId, node.name, fullRel);   // langsung mode edit
                }
            });
        });
    }

    /** Tambah folder: hanya membuat folder, tidak masuk ke dalamnya. */
    private void promptNewFolder() {
        showNameDialog(getString(R.string.fm_new_folder_title), getString(R.string.fm_create), "", "", false,
                (name, ext) -> createFolder(name));
    }

    private void createFolder(final String name) {
        final DocStore s = store;
        final Folder f = current();
        setBusy(true);
        IO.execute(() -> {
            boolean ok = false;
            boolean exists = false;
            try {
                if (s.exists(f.docId, name)) exists = true;
                else ok = s.createDir(f.docId, name) != null;
            } catch (Exception ignored) {
            }
            final boolean success = ok;
            final boolean dup = exists;
            handler.post(() -> {
                if (!viewAlive) return;
                setBusy(false);
                if (dup) toast(getString(R.string.fm_name_exists, name));
                else if (!success) toast(getString(R.string.fm_create_failed));
                else {
                    toast(getString(R.string.fm_folder_created, name));
                    refresh();
                }
            });
        });
    }

    // ------------------------------------------------------------ ganti nama / hapus

    private void showItemActions(final DocStore.Node n) {
        DialogUtils.choice(requireContext(), n.name,
                n.dir ? getString(R.string.fm_folder_meta) : FileKind.label(FileKind.ext(n.name)),
                getString(R.string.fm_action_rename), () -> promptRename(n),
                getString(R.string.fm_action_delete), () -> confirmDelete(n));
    }

    private void promptRename(final DocStore.Node n) {
        String base = n.name;
        String ext = "";
        if (!n.dir) {
            String e = FileKind.ext(n.name);
            if (!e.isEmpty()) {
                ext = n.name.substring(n.name.length() - e.length());
                base = n.name.substring(0, n.name.length() - e.length() - 1);
            }
        }
        showNameDialog(getString(R.string.fm_rename_title), getString(R.string.save), base, ext, !n.dir,
                (name, e) -> {
                    final String full = n.dir ? name : joinName(name, e);
                    if (full.equals(n.name)) return;
                    final DocStore s = store;
                    final String parent = current().docId;
                    setBusy(true);
                    IO.execute(() -> {
                        boolean exists = false;
                        boolean ok = false;
                        try {
                            if (s.exists(parent, full)) exists = true;
                            else ok = s.rename(n.docId, full);
                        } catch (Exception ignored) {
                        }
                        final boolean dup = exists;
                        final boolean success = ok;
                        handler.post(() -> {
                            if (!viewAlive) return;
                            setBusy(false);
                            if (dup) toast(getString(R.string.fm_name_exists, full));
                            else if (!success) toast(getString(R.string.fm_rename_failed));
                            else refresh();
                        });
                    });
                });
    }

    private void confirmDelete(final DocStore.Node n) {
        DialogUtils.confirm(requireContext(), getString(R.string.fm_delete_title, n.name),
                getString(n.dir ? R.string.fm_delete_folder_message : R.string.fm_delete_file_message),
                getString(R.string.fm_action_delete), () -> {
                    final DocStore s = store;
                    setBusy(true);
                    IO.execute(() -> {
                        final boolean ok = s.delete(n.docId);
                        handler.post(() -> {
                            if (!viewAlive) return;
                            setBusy(false);
                            if (!ok) toast(getString(R.string.fm_delete_failed));
                            refresh();
                        });
                    });
                });
    }

    // ------------------------------------------------------------ impor (kiri atas)

    private void startImport() {
        if (store == null) return;
        pendingImportTarget = current().docId;      // berkas masuk ke folder yang sedang dibuka
        pickFiles.launch(new String[]{"*/*"});      // semua jenis berkas, boleh banyak
    }

    private void onFilesPicked(@Nullable List<Uri> uris) {
        final String target = pendingImportTarget;
        pendingImportTarget = null;
        if (uris == null || uris.isEmpty() || target == null || store == null || !viewAlive) return;
        final DocStore s = store;
        final String targetName = target.equals(current().docId) && current().name != null
                ? current().name : getString(R.string.fm_title_default);
        toast(getString(R.string.fm_importing));
        setBusy(true);
        final List<Uri> items = new ArrayList<>(uris);
        IO.execute(() -> {
            int ok = 0;
            int fail = 0;
            for (Uri u : items) {
                try {
                    s.importUri(target, u, s.nameOfUri(u));
                    ok++;
                } catch (Exception e) {
                    fail++;
                }
            }
            final int okCount = ok;
            final int failCount = fail;
            handler.post(() -> {
                if (!viewAlive) return;
                setBusy(false);
                if (failCount == 0) toast(getString(R.string.fm_imported, okCount, targetName));
                else toast(getString(R.string.fm_import_partial, okCount, failCount));
                refresh();
            });
        });
    }

    // ------------------------------------------------------------ ekspor .zip (kanan atas)

    private void startExport() {
        if (store == null) return;
        Folder f = current();
        if (ZipExporter.needsLegacyPermission() && ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingExport = f;
            askStorage.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return;
        }
        doExport(f);
    }

    private void doExport(final Folder f) {
        if (store == null) return;
        final DocStore s = store;
        final Context app = requireContext().getApplicationContext();
        final String name = f.name != null ? f.name : s.rootName();
        toast(getString(R.string.fm_exporting));
        setBusy(true);
        IO.execute(() -> {
            ZipExporter.Result r = null;
            try {
                r = ZipExporter.export(app, s, f.docId, name);
            } catch (Exception ignored) {
            }
            final ZipExporter.Result result = r;
            handler.post(() -> {
                if (!viewAlive) return;
                setBusy(false);
                if (result == null) toast(getString(R.string.fm_export_failed));
                else toast(getString(R.string.fm_exported, result.files, result.fileName));
            });
        });
    }

    // ------------------------------------------------------------ util UI

    private void toast(String msg) {
        if (getContext() != null) Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show();
    }

    private void showDialog(Dialog dialog) {
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setLayout(DialogUtils.dialogWidth(requireContext()), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private String agoText(long modified) {
        if (modified <= 0) return "";
        long diff = System.currentTimeMillis() - modified;
        if (diff < 0) diff = 0;
        long min = diff / 60000;
        if (min < 1) return getString(R.string.time_now);
        if (min < 60) return getString(R.string.time_min, (int) min);
        long hour = min / 60;
        if (hour < 24) return getString(R.string.time_hour, (int) hour);
        long day = hour / 24;
        if (day < 7) return getString(R.string.time_day, (int) day);
        return FileUtils.formatDate(requireContext(), modified);
    }

    // ------------------------------------------------------------ adapter

    private static final class VH extends RecyclerView.ViewHolder {
        VH(View v) {
            super(v);
        }
    }

    private final class RowAdapter extends RecyclerView.Adapter<VH> {

        @Override
        public int getItemViewType(int position) {
            return rows.get(position).type;
        }

        @Override
        public int getItemCount() {
            return rows.size();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int type) {
            LayoutInflater inf = LayoutInflater.from(parent.getContext());
            int layout;
            switch (type) {
                case T_RECENTS:
                    layout = R.layout.item_recents;
                    break;
                case T_LABEL:
                    layout = R.layout.item_section_label;
                    break;
                default:
                    layout = R.layout.item_file_row;
            }
            View v = inf.inflate(layout, parent, false);
            ThemeApplier.apply(v);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Row row = rows.get(position);
            switch (row.type) {
                case T_RECENTS:
                    bindRecents(h.itemView, row.recents);
                    break;
                case T_UP:
                    bindUp(h.itemView);
                    break;
                case T_ROW:
                    bindNode(h.itemView, row.node);
                    break;
                default:
                    break;
            }
        }
    }

    private void bindRecents(View v, List<DocStore.Node> recents) {
        LinearLayout row = v.findViewById(R.id.recentsRow);
        row.removeAllViews();
        Context ctx = requireContext();
        LayoutInflater inf = LayoutInflater.from(ctx);
        float d = getResources().getDisplayMetrics().density;
        // Lebar kartu ~46% layar: dua kartu penuh + sebagian kartu ketiga terlihat, jadi jelas bisa digeser.
        int cardW = (int) Math.max(140 * d, Math.min(190 * d, getResources().getDisplayMetrics().widthPixels * 0.46f));
        for (final DocStore.Node n : recents) {
            View card = inf.inflate(R.layout.item_recent_card, row, false);
            ThemeApplier.apply(card);
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) card.getLayoutParams();
            lp.width = cardW;
            card.setLayoutParams(lp);
            FileKind.styleBadge(ctx, (TextView) card.findViewById(R.id.cardBadge), FileKind.ext(n.name));
            ((TextView) card.findViewById(R.id.cardName)).setText(n.name);
            int slash = n.rel.lastIndexOf('/');
            String where = slash > 0 ? n.rel.substring(0, slash) : (current().name != null ? current().name : "");
            ((TextView) card.findViewById(R.id.cardPath)).setText(where);
            ((TextView) card.findViewById(R.id.cardTime)).setText(agoText(n.modified));
            card.setOnClickListener(x -> openFile(n));
            card.setOnLongClickListener(x -> {
                showItemActions(n);
                return true;
            });
            row.addView(card);
        }
    }

    private void bindUp(View v) {
        ((TextView) v.findViewById(R.id.rowName)).setText("..");
        ((TextView) v.findViewById(R.id.rowMeta)).setText(R.string.fm_up);
        v.findViewById(R.id.rowBadge).setVisibility(View.GONE);
        android.widget.ImageView icon = v.findViewById(R.id.rowIcon);
        icon.setVisibility(View.VISIBLE);
        icon.setImageResource(R.drawable.ic_up);
        v.findViewById(R.id.rowMore).setVisibility(View.GONE);
        v.setOnClickListener(x -> goUp());
        v.setOnLongClickListener(null);
    }

    private void bindNode(View v, final DocStore.Node n) {
        Context ctx = requireContext();
        ((TextView) v.findViewById(R.id.rowName)).setText(n.name);
        TextView badge = v.findViewById(R.id.rowBadge);
        android.widget.ImageView icon = v.findViewById(R.id.rowIcon);
        TextView meta = v.findViewById(R.id.rowMeta);
        v.findViewById(R.id.rowMore).setVisibility(View.VISIBLE);
        if (n.dir) {
            badge.setVisibility(View.GONE);
            icon.setVisibility(View.VISIBLE);
            icon.setImageResource(R.drawable.ic_folder);
            String date = FileUtils.formatDate(ctx, n.modified);
            meta.setText(date.isEmpty() ? getString(R.string.fm_folder_meta)
                    : getString(R.string.fm_folder_meta) + "  ·  " + date);
            v.setOnClickListener(x -> openFolder(n));
        } else {
            icon.setVisibility(View.GONE);
            badge.setVisibility(View.VISIBLE);
            FileKind.styleBadge(ctx, badge, FileKind.ext(n.name));
            StringBuilder m = new StringBuilder();
            if (n.size >= 0) m.append(FileUtils.formatFileSize(n.size));
            String date = FileUtils.formatDate(ctx, n.modified);
            if (!date.isEmpty()) {
                if (m.length() > 0) m.append("  ·  ");
                m.append(date);
            }
            meta.setText(m.toString());
            v.setOnClickListener(x -> openFile(n));
        }
        v.setOnLongClickListener(x -> {
            showItemActions(n);
            return true;
        });
        v.findViewById(R.id.rowMore).setOnClickListener(x -> showItemActions(n));
    }
}
