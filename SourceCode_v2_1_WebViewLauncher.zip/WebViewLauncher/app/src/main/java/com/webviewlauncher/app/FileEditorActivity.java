package com.webviewlauncher.app;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.core.content.ContextCompat;

import com.webviewlauncher.app.theme.Palette;
import com.webviewlauncher.app.util.CodeFormatter;
import com.webviewlauncher.app.util.DialogUtils;
import com.webviewlauncher.app.util.DocStore;
import com.webviewlauncher.app.util.FileKind;
import com.webviewlauncher.app.util.FileRunner;
import com.webviewlauncher.app.util.FileUtils;
import com.webviewlauncher.app.widget.CodeEditText;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.PatternSyntaxException;

/**
 * Editor teks layar penuh untuk satu berkas di folder utama Text Editor.
 *
 * Susunan: bilah judul (kembali, lencana jenis berkas, nama + status simpan, Simpan, Jalankan),
 * alat di bagian atas kotak kode (undo, redo, cari, format, salin, tempel, kosongkan, ke baris, lainnya),
 * lalu di bagian bawah baris simbol cepat dan status posisi kursor.
 *
 * Ciri khas: lencana warna per jenis berkas, simpan otomatis dengan penanda status langsung,
 * dan tombol Jalankan bulat beraksen. Berkas visual (html/htm/svg) dijalankan di WebView; berkas
 * lain hanya menghasilkan teks (js dijalankan dan keluaran console-nya ditampilkan).
 */
public class FileEditorActivity extends BaseActivity {

    public static final String EXTRA_TREE = "tree_uri";
    public static final String EXTRA_DOC = "doc_id";
    public static final String EXTRA_PARENT = "parent_id";
    public static final String EXTRA_NAME = "name";
    public static final String EXTRA_REL = "rel_path";

    private static final long MAX_BYTES = 20L << 20;
    private static final long AUTOSAVE_DELAY_MS = 1500;
    private static final String[] QUICK_KEYS = {"Tab", "←", "→", "{", "}", "(", ")", "[", "]", "<", ">",
            "/", "\"", "'", ";", ":", "=", "!", "#", ".", ",", "$", "&", "|", "\\", "`", "-", "_", "+",
            "*", "%", "?", "@"};
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();

    private DocStore store;
    private String docId;
    private String parentId;
    private String name;
    private String rel;
    private String ext;

    private CodeEditText editor;
    private TextView lineInfo;
    private TextView encInfo;
    private TextView saveState;
    private View btnRun;
    private View btnUndo;
    private View btnRedo;
    private View btnSave;

    private View findBar;
    private EditText findInput;
    private EditText replaceInput;
    private TextView findCount;
    private TextView optCase;
    private TextView optRegex;

    private SharedPreferences prefs;
    private float fontSp = 13f;
    private boolean autosave = true;

    private Charset charset = StandardCharsets.UTF_8;
    private boolean crlf = false;

    private boolean loaded = false;
    private boolean dirty = false;
    private boolean saving = false;
    private boolean running = false;
    private boolean destroyed = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable statusRunnable = this::updateStatus;
    private final Runnable findRunnable = this::runFind;
    private final Runnable autosaveRunnable = () -> saveAsync(null);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String tree = getIntent().getStringExtra(EXTRA_TREE);
        docId = getIntent().getStringExtra(EXTRA_DOC);
        parentId = getIntent().getStringExtra(EXTRA_PARENT);
        name = getIntent().getStringExtra(EXTRA_NAME);
        rel = getIntent().getStringExtra(EXTRA_REL);
        if (tree == null || docId == null || parentId == null || name == null) {
            finish();
            return;
        }
        if (rel == null) rel = name;
        ext = FileKind.ext(name);
        store = new DocStore(this, Uri.parse(tree));

        setContentView(R.layout.activity_file_editor);
        prefs = getSharedPreferences(App.PREFS, MODE_PRIVATE);
        fontSp = prefs.getFloat("editor_font", 13f);
        autosave = prefs.getBoolean("editor_autosave", true);

        bindViews();
        setupEditor();
        setupTools();
        setupFindBar();
        setupQuickKeys((LinearLayout) findViewById(R.id.quickKeys));

        // Layar pendek (mis. landscape): baris simbol cepat disembunyikan agar area ketik tetap luas.
        float heightDp = getResources().getDisplayMetrics().heightPixels / getResources().getDisplayMetrics().density;
        if (heightDp < 480f) findViewById(R.id.quickKeysScroll).setVisibility(View.GONE);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                attemptExit();
            }
        });

        updateSaveState();
        loadFile();
    }

    private void bindViews() {
        editor = findViewById(R.id.editor);
        lineInfo = findViewById(R.id.lineInfo);
        encInfo = findViewById(R.id.encInfo);
        saveState = findViewById(R.id.saveState);
        btnRun = findViewById(R.id.btnRun);
        btnUndo = findViewById(R.id.btnUndo);
        btnRedo = findViewById(R.id.btnRedo);
        btnSave = findViewById(R.id.btnSave);
        findBar = findViewById(R.id.findBar);
        findInput = findViewById(R.id.findInput);
        replaceInput = findViewById(R.id.replaceInput);
        findCount = findViewById(R.id.findCount);
        optCase = findViewById(R.id.optCase);
        optRegex = findViewById(R.id.optRegex);

        ((TextView) findViewById(R.id.fileTitle)).setText(name);
        FileKind.styleBadge(this, (TextView) findViewById(R.id.fileBadge), ext);
        findViewById(R.id.btnBack).setOnClickListener(v -> attemptExit());
    }

    private void setupEditor() {
        editor.setLanguage(FileKind.syntax(ext));
        editor.setHighlightEnabled(true);
        editor.setShowLineNumbers(true);
        editor.setEditorTextSize(fontSp);
        editor.setWordWrap(true);       // tidak bisa digeser ke samping: baris panjang turun ke bawah (soft wrap)
        editor.setCursorListener(this::scheduleStatus);
        editor.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (loaded) markDirty();
                scheduleStatus();
            }
        });
    }

    private void setupTools() {
        btnUndo.setOnClickListener(v -> {
            editor.undo();
            scheduleStatus();
        });
        btnRedo.setOnClickListener(v -> {
            editor.redo();
            scheduleStatus();
        });
        findViewById(R.id.btnFind).setOnClickListener(v -> toggleFindBar());
        findViewById(R.id.btnFormat).setOnClickListener(v -> formatCode());
        findViewById(R.id.btnCopy).setOnClickListener(v -> copyToClipboard());
        findViewById(R.id.btnPaste).setOnClickListener(v -> pasteFromClipboard());
        findViewById(R.id.btnClear).setOnClickListener(v -> confirmClear());
        findViewById(R.id.btnMore).setOnClickListener(v -> showToolsDialog());
        findViewById(R.id.btnGoto).setOnClickListener(v -> promptGoToLine());
        btnSave.setOnClickListener(v -> {
            if (!dirty) {
                Toast.makeText(this, R.string.ed_saved, Toast.LENGTH_SHORT).show();
                return;
            }
            saveAsync(null);
        });
        btnRun.setOnClickListener(v -> runFile());
    }

    // ------------------------------------------------------------ muat & simpan

    private void loadFile() {
        IO.execute(() -> {
            byte[] data = null;
            int error = 0;     // 0 ok, 1 gagal, 2 biner, 3 terlalu besar
            try {
                data = store.readBytes(docId, MAX_BYTES);
                int probe = Math.min(data.length, 8000);
                for (int i = 0; i < probe; i++) {
                    if (data[i] == 0) {
                        error = 2;
                        break;
                    }
                }
            } catch (DocStore.TooBigException e) {
                error = 3;
            } catch (Exception e) {
                error = 1;
            }
            final byte[] bytes = data;
            final int err = error;

            // Dekode: UTF-8 ketat; bila bukan UTF-8 yang sah, dibaca sebagai ISO-8859-1 agar tidak rusak saat disimpan.
            Charset cs = StandardCharsets.UTF_8;
            String text = "";
            if (err == 0) {
                try {
                    text = StandardCharsets.UTF_8.newDecoder()
                            .onMalformedInput(CodingErrorAction.REPORT)
                            .onUnmappableCharacter(CodingErrorAction.REPORT)
                            .decode(ByteBuffer.wrap(bytes)).toString();
                } catch (CharacterCodingException e) {
                    cs = StandardCharsets.ISO_8859_1;
                    text = new String(bytes, cs);
                }
                if (text.startsWith("\uFEFF")) text = text.substring(1);
            }
            final boolean hasCrlf = text.indexOf("\r\n") >= 0;
            if (hasCrlf) text = text.replace("\r\n", "\n");
            final String finalText = text;
            final Charset finalCs = cs;

            handler.post(() -> {
                if (destroyed) return;
                if (err != 0) {
                    int msg = err == 2 ? R.string.ed_binary : R.string.ed_load_failed;
                    if (err == 3) {
                        Toast.makeText(this, getString(R.string.ed_too_big, FileUtils.formatFileSize(MAX_BYTES)),
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                    }
                    finish();
                    return;
                }
                charset = finalCs;
                crlf = hasCrlf;
                editor.loadText(finalText);
                loaded = true;
                dirty = false;
                encInfo.setText(charset == StandardCharsets.UTF_8 ? "UTF-8" : "ISO-8859-1");
                updateSaveState();
                updateStatus();
            });
        });
    }

    private void markDirty() {
        if (!dirty) {
            dirty = true;
            updateSaveState();
        }
        handler.removeCallbacks(autosaveRunnable);
        if (autosave) handler.postDelayed(autosaveRunnable, AUTOSAVE_DELAY_MS);
    }

    private String currentTextForDisk() {
        String t = editor.getText().toString();
        return crlf ? t.replace("\n", "\r\n") : t;
    }

    private void saveAsync(Runnable onDone) {
        if (!loaded || !dirty) {
            if (onDone != null) onDone.run();
            return;
        }
        handler.removeCallbacks(autosaveRunnable);
        final String text = currentTextForDisk();
        final Charset cs = charset;
        dirty = false;
        saving = true;
        updateSaveState();
        IO.execute(() -> {
            boolean ok;
            try {
                store.writeText(docId, text, cs);
                ok = true;
            } catch (Exception e) {
                ok = false;
            }
            final boolean saved = ok;
            handler.post(() -> {
                saving = false;
                if (!saved) {
                    dirty = true;
                    if (!destroyed) Toast.makeText(this, R.string.ed_save_failed, Toast.LENGTH_SHORT).show();
                }
                if (!destroyed) updateSaveState();
                if (saved && onDone != null) onDone.run();
            });
        });
    }

    private void updateSaveState() {
        if (saveState == null) return;
        int accent = Palette.accent(this);
        String label;
        int color;
        if (!loaded) {
            label = "…";
            color = ContextCompat.getColor(this, R.color.text_faint);
        } else if (saving) {
            label = "● " + getString(R.string.ed_saving);
            color = ContextCompat.getColor(this, R.color.text_faint);
        } else if (dirty) {
            label = "● " + getString(R.string.ed_unsaved);
            color = 0xFFE0A030;
        } else {
            label = "✓ " + getString(R.string.ed_saved);
            color = accent;
        }
        saveState.setText(label + "  ·  " + rel);
        saveState.setTextColor(color);
        btnSave.setAlpha(dirty ? 1f : 0.4f);
    }

    private void attemptExit() {
        releaseTyping();
        if (!loaded || (!dirty && !saving)) {
            finish();
            return;
        }
        if (!dirty) {      // sedang menyimpan: berkas ditulis di latar belakang, aman ditinggal
            finish();
            return;
        }
        if (autosave) {
            saveAsync(this::finish);
            return;
        }
        DialogUtils.choice(this, getString(R.string.ed_unsaved_title),
                getString(R.string.ed_unsaved_message, name),
                getString(R.string.ed_save_exit), () -> saveAsync(this::finish),
                getString(R.string.ed_discard), this::finish);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (loaded && dirty && autosave) saveAsync(null);
    }

    // ------------------------------------------------------------ status

    private void scheduleStatus() {
        handler.removeCallbacks(statusRunnable);
        handler.postDelayed(statusRunnable, 200);
    }

    private void updateStatus() {
        if (destroyed) return;
        if (editor.length() == 0) {
            lineInfo.setText("");
        } else {
            int[] lc = editor.cursorLineCol();
            lineInfo.setText(getString(R.string.status_cursor, lc[0], lc[1], editor.lineCountLogical()));
        }
        btnUndo.setAlpha(editor.canUndo() ? 1f : 0.35f);
        btnRedo.setAlpha(editor.canRedo() ? 1f : 0.35f);
    }

    private void releaseTyping() {
        View focus = getCurrentFocus();
        if (focus != null) focus.clearFocus();
        hideKeyboard();
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(editor.getWindowToken(), 0);
    }

    // ------------------------------------------------------------ simbol cepat

    private void setupQuickKeys(LinearLayout row) {
        float d = getResources().getDisplayMetrics().density;
        for (final String key : QUICK_KEYS) {
            TextView tv = new TextView(this);
            tv.setText(key);
            tv.setTextColor(ContextCompat.getColor(this, R.color.text_primary));
            tv.setTextSize(14f);
            tv.setTypeface(android.graphics.Typeface.MONOSPACE);
            tv.setGravity(Gravity.CENTER);
            tv.setBackgroundResource(R.drawable.bg_key);
            tv.setClickable(true);
            tv.setFocusable(false);               // supaya fokus & keyboard tetap di kotak kode
            tv.setMinWidth((int) (40 * d));
            tv.setPadding((int) (10 * d), 0, (int) (10 * d), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, (int) (36 * d));
            lp.setMargins(0, 0, (int) (6 * d), 0);
            tv.setLayoutParams(lp);
            tv.setOnClickListener(v -> onQuickKey(key));
            row.addView(tv);
        }
    }

    private void onQuickKey(String key) {
        switch (key) {
            case "Tab": {
                int a = Math.min(editor.getSelectionStart(), editor.getSelectionEnd());
                int b = Math.max(editor.getSelectionStart(), editor.getSelectionEnd());
                boolean multi = b > a && editor.getText().subSequence(a, b).toString().indexOf('\n') >= 0;
                if (multi) editor.indentLines(true);
                else editor.insertAtCursor("  ");
                break;
            }
            case "←":
                editor.moveCursor(-1);
                break;
            case "→":
                editor.moveCursor(1);
                break;
            default:
                editor.insertAtCursor(key);
        }
    }

    // ------------------------------------------------------------ cari / ganti

    private void setupFindBar() {
        findInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                handler.removeCallbacks(findRunnable);
                handler.postDelayed(findRunnable, 250);
            }
        });
        findInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                editor.nextMatch();
                updateFindCount();
                return true;
            }
            return false;
        });
        findViewById(R.id.findNext).setOnClickListener(v -> {
            editor.nextMatch();
            updateFindCount();
        });
        findViewById(R.id.findPrev).setOnClickListener(v -> {
            editor.prevMatch();
            updateFindCount();
        });
        findViewById(R.id.findClose).setOnClickListener(v -> closeFindBar());
        optCase.setOnClickListener(v -> {
            optCase.setSelected(!optCase.isSelected());
            runFind();
        });
        optRegex.setOnClickListener(v -> {
            optRegex.setSelected(!optRegex.isSelected());
            runFind();
        });
        findViewById(R.id.btnReplace).setOnClickListener(v -> {
            if (editor.replaceCurrent(replaceInput.getText().toString())) runFind();
        });
        findViewById(R.id.btnReplaceAll).setOnClickListener(v -> {
            String q = findInput.getText().toString();
            if (q.isEmpty()) return;
            try {
                int n = editor.replaceAll(q, replaceInput.getText().toString(),
                        optCase.isSelected(), optRegex.isSelected());
                Toast.makeText(this, getString(R.string.replaced_n, n), Toast.LENGTH_SHORT).show();
                runFind();
            } catch (Exception e) {
                Toast.makeText(this, R.string.regex_invalid, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void toggleFindBar() {
        if (findBar.getVisibility() == View.VISIBLE) {
            closeFindBar();
            return;
        }
        findBar.setVisibility(View.VISIBLE);
        findBar.setAlpha(0f);
        findBar.animate().alpha(1f).setDuration(160).start();
        int a = Math.min(editor.getSelectionStart(), editor.getSelectionEnd());
        int b = Math.max(editor.getSelectionStart(), editor.getSelectionEnd());
        if (b > a && b - a <= 100) {
            String sel = editor.getText().subSequence(a, b).toString();
            if (sel.indexOf('\n') < 0) findInput.setText(sel);
        }
        findInput.requestFocus();
        findInput.setSelection(findInput.length());
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT);
        runFind();
    }

    private void closeFindBar() {
        findBar.setVisibility(View.GONE);
        editor.clearSearch();
        editor.requestFocus();
    }

    private void runFind() {
        if (destroyed) return;
        String q = findInput.getText().toString();
        try {
            editor.findAll(q, optCase.isSelected(), optRegex.isSelected());
            updateFindCount();
        } catch (PatternSyntaxException e) {
            findCount.setText("!");
        }
    }

    private void updateFindCount() {
        int n = editor.getMatchCount();
        findCount.setText(n == 0 ? "0/0" : (editor.getCurrentMatch() + 1) + "/" + n);
    }

    // ------------------------------------------------------------ salin / tempel / kosongkan

    private void copyToClipboard() {
        if (editor.length() == 0) return;
        int a = Math.min(editor.getSelectionStart(), editor.getSelectionEnd());
        int b = Math.max(editor.getSelectionStart(), editor.getSelectionEnd());
        CharSequence text = b > a ? editor.getText().subSequence(a, b) : editor.getText();
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText(name, text.toString()));
            Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, R.string.copy_failed, Toast.LENGTH_LONG).show();   // batas ukuran clipboard (~1 MB)
        }
    }

    private void pasteFromClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = cm == null ? null : cm.getPrimaryClip();
        CharSequence text = null;
        if (clip != null && clip.getItemCount() > 0) text = clip.getItemAt(0).coerceToText(this);
        if (text == null || text.length() == 0) {
            Toast.makeText(this, R.string.flash_clipboard_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        editor.insertAtCursor(text.toString());   // toString(): buang format web, kode harus teks polos
    }

    private void confirmClear() {
        if (editor.length() == 0) return;
        DialogUtils.choice(this, getString(R.string.clear_title, name), getString(R.string.clear_message),
                getString(R.string.clear_undoable), () -> editor.replaceWholeText(""),
                getString(R.string.clear_permanent), () -> {
                    editor.loadText("");
                    markDirty();            // loadText tidak memicu penanda ubah; tandai manual
                });
    }

    // ------------------------------------------------------------ format

    private void formatCode() {
        if (!FileKind.canFormat(ext)) {
            Toast.makeText(this, R.string.ed_format_unsupported, Toast.LENGTH_SHORT).show();
            return;
        }
        if (editor.length() == 0) return;
        final String src = editor.getText().toString();
        final int lang = FileKind.syntax(ext);
        Toast.makeText(this, R.string.format_busy, Toast.LENGTH_SHORT).show();
        IO.execute(() -> {
            String out;
            try {
                out = CodeFormatter.format(lang, src);
            } catch (Throwable t) {
                out = null;
            }
            final String result = out;
            handler.post(() -> {
                if (destroyed) return;
                if (result == null) {
                    Toast.makeText(this, R.string.format_failed, Toast.LENGTH_LONG).show();
                } else if (editor.length() == src.length()) {   // belum diubah pengguna selama memformat
                    editor.replaceWholeText(result);
                    scheduleStatus();
                }
            });
        });
    }

    // ------------------------------------------------------------ alat lainnya

    private TextView toggleRow(Context ctx, float d, String label, boolean on, Runnable onClick) {
        final String onText = getString(R.string.state_on);
        final String offText = getString(R.string.state_off);
        final TextView item = new TextView(ctx);
        item.setTag(new boolean[]{on});
        item.setText(label + ": " + (on ? onText : offText));
        item.setTextColor(ContextCompat.getColor(ctx, R.color.text_primary));
        item.setTextSize(14f);
        item.setGravity(Gravity.CENTER);
        item.setBackgroundResource(R.drawable.bg_button_flat);
        item.setClickable(true);
        item.setPadding(0, (int) (14 * d), 0, (int) (14 * d));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = (int) (8 * d);
        item.setLayoutParams(lp);
        item.setOnClickListener(v -> {
            boolean[] state = (boolean[]) item.getTag();
            state[0] = !state[0];
            item.setText(label + ": " + (state[0] ? onText : offText));
            onClick.run();
        });
        return item;
    }

    private void showToolsDialog() {
        final Context ctx = this;
        final Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        final float d = getResources().getDisplayMetrics().density;
        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundResource(R.drawable.bg_dialog);
        int p = (int) (20 * d);
        box.setPadding(p, (int) (22 * d), p, (int) (18 * d));

        TextView title = new TextView(ctx);
        title.setText(R.string.tools_title);
        title.setTextColor(ContextCompat.getColor(ctx, R.color.text_primary));
        title.setTextSize(17f);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, (int) (16 * d));
        box.addView(title);

        box.addView(toggleRow(ctx, d, getString(R.string.ed_autosave), autosave, () -> {
            autosave = !autosave;
            prefs.edit().putBoolean("editor_autosave", autosave).apply();
            handler.removeCallbacks(autosaveRunnable);
            if (autosave && dirty) handler.postDelayed(autosaveRunnable, AUTOSAVE_DELAY_MS);
        }));

        final TextView sizeLabel = new TextView(ctx);
        sizeLabel.setTextColor(ContextCompat.getColor(ctx, R.color.text_secondary));
        sizeLabel.setTextSize(12f);
        sizeLabel.setPadding(0, (int) (14 * d), 0, (int) (4 * d));
        sizeLabel.setText(getString(R.string.tool_font_size) + ": " + Math.round(fontSp));
        box.addView(sizeLabel);

        final TextView preview = new TextView(ctx);
        preview.setText(R.string.tool_font_preview);
        preview.setTypeface(android.graphics.Typeface.MONOSPACE);
        preview.setTextColor(ContextCompat.getColor(ctx, R.color.text_primary));
        preview.setTextSize(fontSp);
        preview.setPadding((int) (12 * d), (int) (10 * d), (int) (12 * d), (int) (10 * d));
        preview.setBackgroundResource(R.drawable.bg_editor);
        box.addView(preview);

        final android.widget.SeekBar bar = new android.widget.SeekBar(ctx);
        bar.setMax(15);                                  // 9 sp .. 24 sp
        bar.setProgress(Math.round(fontSp) - 9);
        android.content.res.ColorStateList tint = android.content.res.ColorStateList.valueOf(Palette.accent(ctx));
        bar.setProgressTintList(tint);
        bar.setThumbTintList(tint);
        bar.setPadding((int) (6 * d), (int) (14 * d), (int) (6 * d), (int) (6 * d));
        bar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar sb, int progress, boolean fromUser) {
                float sp = 9 + progress;
                sizeLabel.setText(getString(R.string.tool_font_size) + ": " + Math.round(sp));
                preview.setTextSize(sp);
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar sb) {
                setFontSize(9 + sb.getProgress());   // diterapkan saat dilepas (hemat render)
            }
        });
        box.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        dialog.setContentView(box);
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setLayout(DialogUtils.dialogWidth(ctx), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private void setFontSize(float sp) {
        fontSp = Math.max(9f, Math.min(24f, sp));
        prefs.edit().putFloat("editor_font", fontSp).apply();
        editor.setEditorTextSize(fontSp);
    }

    private void promptGoToLine() {
        final int total = editor.lineCountLogical();
        DialogUtils.promptNumber(this, getString(R.string.goto_title),
                getString(R.string.goto_hint, total), getString(R.string.goto_confirm), text -> {
                    try {
                        int n = Integer.parseInt(text);
                        editor.goToLine(Math.max(1, Math.min(n, total)));
                    } catch (NumberFormatException ignored) {
                    }
                });
    }

    // ------------------------------------------------------------ jalankan

    private void runFile() {
        if (running || !loaded) return;
        final String text = editor.getText().toString();
        if (text.trim().isEmpty()) {
            Toast.makeText(this, R.string.flash_empty_code, Toast.LENGTH_SHORT).show();
            return;
        }
        running = true;
        btnRun.setAlpha(0.6f);
        releaseTyping();

        final boolean visual = FileKind.isVisual(ext);
        if (visual) Toast.makeText(this, R.string.ed_run_preparing, Toast.LENGTH_SHORT).show();

        // Simpan dulu (bila ada perubahan) agar yang dijalankan sama dengan yang ada di berkas.
        final boolean needSave = dirty;
        final String diskText = needSave ? currentTextForDisk() : null;
        final Charset cs = charset;
        if (needSave) {
            handler.removeCallbacks(autosaveRunnable);
            dirty = false;
            updateSaveState();
        }
        final Context app = getApplicationContext();

        IO.execute(() -> {
            boolean saveFailed = false;
            FileRunner.Result res = null;
            try {
                if (needSave) {
                    try {
                        store.writeText(docId, diskText, cs);
                    } catch (Exception e) {
                        saveFailed = true;
                    }
                }
                if (visual) {
                    res = FileRunner.prepareVisual(app, store, parentId, name, rel, FileRunner.needsWholeRoot(text));
                } else {
                    res = FileRunner.prepareText(app, name, ext, text);
                }
            } catch (Exception e) {
                res = null;
            }
            final FileRunner.Result result = res;
            final boolean failedSave = saveFailed;
            handler.post(() -> {
                running = false;
                if (destroyed) return;
                btnRun.setAlpha(1f);
                if (failedSave) {
                    dirty = true;
                    updateSaveState();
                }
                if (result == null) {
                    Toast.makeText(this, R.string.flash_run_error, Toast.LENGTH_LONG).show();
                    return;
                }
                Intent intent = new Intent(this, WebGameActivity.class);
                intent.putExtra("entry_path", result.entry.getAbsolutePath());
                intent.putExtra("root_path", result.root.getAbsolutePath());
                intent.putExtra("title", name);
                startActivity(intent);
            });
        });
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
