package com.webviewlauncher.app;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.webviewlauncher.app.adapter.GameAdapter;
import com.webviewlauncher.app.data.DataStore;
import com.webviewlauncher.app.model.GameItem;
import com.webviewlauncher.app.util.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class GameFragment extends Fragment {

    private RecyclerView recyclerView;
    private TextView emptyText;
    private GameAdapter adapter;
    private final List<GameItem> items = new ArrayList<>();
    private DataStore dataStore;

    private final ActivityResultLauncher<Intent> addGameLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> reload()
    );

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_grid, container, false);
        com.webviewlauncher.app.theme.ThemeApplier.apply(root);

        dataStore = new DataStore(requireContext());
        recyclerView = root.findViewById(R.id.recyclerView);
        emptyText = root.findViewById(R.id.emptyText);
        emptyText.setText(R.string.empty_games);

        recyclerView.setLayoutManager(new GridLayoutManager(requireContext(), spanCountForScreen()));
        adapter = new GameAdapter(items, new GameAdapter.Listener() {
            @Override
            public void onClick(GameItem item) {
                Intent intent = new Intent(requireContext(), WebGameActivity.class);
                intent.putExtra("entry_path", item.entryFilePath);
                intent.putExtra("title", item.title);
                startActivity(intent);
            }

            @Override
            public boolean onLongClick(GameItem item) {
                showActionsDialog(item);
                return true;
            }
        });
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = root.findViewById(R.id.fab);
        fab.setOnClickListener(v -> addGameLauncher.launch(new Intent(requireContext(), AddGameActivity.class)));

        reload();
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        items.clear();
        items.addAll(dataStore.loadGames());
        adapter.notifyDataSetChanged();
        updateEmptyState();
    }

    private void updateEmptyState() {
        emptyText.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
    }

    /**
     * Ditampilkan saat item ditekan lama: pilihan bergambar tempat sampah (hapus).
     */
    private void showActionsDialog(GameItem item) {
        Context ctx = requireContext();
        View view = LayoutInflater.from(ctx).inflate(R.layout.dialog_item_actions, null);
        com.webviewlauncher.app.theme.ThemeApplier.apply(view);
        ((TextView) view.findViewById(R.id.actionTitle)).setText(item.title);

        Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(view);

        view.findViewById(R.id.actionDelete).setOnClickListener(v -> {
            dialog.dismiss();
            deleteItem(item);
        });
        view.findViewById(R.id.actionInfo).setOnClickListener(v -> {
            dialog.dismiss();
            showFileInfoDialog(item);
        });

        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width = com.webviewlauncher.app.util.DialogUtils.dialogWidth(ctx);
            window.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    /**
     * Ditampilkan saat tombol info (tanda seru) di dialog aksi ditekan: menampilkan nama asli
     * berkas, lokasi asalnya di penyimpanan, ukuran, jenis, dan kapan ditambahkan.
     */
    private void showFileInfoDialog(GameItem item) {
        Context ctx = requireContext();
        String unknown = getString(R.string.info_unknown);
        View view = LayoutInflater.from(ctx).inflate(R.layout.dialog_file_info, null);
        com.webviewlauncher.app.theme.ThemeApplier.apply(view);

        ((TextView) view.findViewById(R.id.infoDisplayName)).setText(
                isBlank(item.title) ? unknown : item.title);

        ((TextView) view.findViewById(R.id.infoOriginalName)).setText(
                isBlank(item.originalFileName) ? unknown : item.originalFileName);

        ((TextView) view.findViewById(R.id.infoLocation)).setText(
                isBlank(item.sourcePath) ? unknown : item.sourcePath);

        String sizeText = item.fileSizeBytes >= 0 ? FileUtils.formatFileSize(item.fileSizeBytes) : unknown;
        ((TextView) view.findViewById(R.id.infoSize)).setText(sizeText);

        String typeText = isBlank(item.fileType) ? unknown
                : item.fileType.toUpperCase(Locale.ROOT);
        ((TextView) view.findViewById(R.id.infoType)).setText(typeText);

        String dateText = item.dateAddedMillis > 0
                ? FileUtils.formatDate(ctx, item.dateAddedMillis) : unknown;
        ((TextView) view.findViewById(R.id.infoDateAdded)).setText(dateText);

        Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(view);

        view.findViewById(R.id.infoClose).setOnClickListener(v -> dialog.dismiss());
        view.findViewById(R.id.infoCode).setOnClickListener(v -> {
            dialog.dismiss();
            File rootDir = new File(ctx.getFilesDir(), "games/" + item.id);
            boolean isZip = "zip".equalsIgnoreCase(item.fileType)
                    || ((item.fileType == null || item.fileType.isEmpty()) && countFiles(rootDir) > 1);
            Intent intent;
            if (isZip) {
                // .zip: tampilkan folder dulu, lalu berkas html/css/js di dalamnya
                intent = new Intent(ctx, CodeBrowserActivity.class);
                intent.putExtra("title", item.title);
            } else {
                intent = new Intent(ctx, CodeViewActivity.class);
                intent.putExtra("entry_path", item.entryFilePath);
            }
            intent.putExtra("root_path", rootDir.getAbsolutePath());
            startActivity(intent);
        });

        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width = com.webviewlauncher.app.util.DialogUtils.dialogWidth(ctx);
            window.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private void deleteItem(GameItem item) {
        // Hapus folder proyek yang telah diekstrak beserta ikonnya
        FileUtils.deleteRecursive(new File(requireContext().getFilesDir(), "games/" + item.id));
        if (item.iconPath != null && !item.iconPath.isEmpty()) {
            FileUtils.deleteRecursive(new File(item.iconPath));
        }
        items.remove(item);
        dataStore.saveGames(items);
        adapter.notifyDataSetChanged();
        updateEmptyState();
    }

    private static int countFiles(File dir) {
        File[] kids = dir.listFiles();
        if (kids == null) return 0;
        int c = 0;
        for (File k : kids) c += k.isDirectory() ? countFiles(k) : 1;
        return c;
    }

    /** Jumlah kolom menyesuaikan lebar layar: 2 di HP sangat kecil, makin banyak di layar lebar/tablet. */
    private int spanCountForScreen() {
        float widthDp = getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density;
        return Math.max(2, Math.min(8, (int) (widthDp / 110f)));
    }
}
