package com.webviewlauncher.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.webviewlauncher.app.util.DialogUtils;
import com.webviewlauncher.app.util.FileUtils;
import com.webviewlauncher.app.util.LibraryStore;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Library: menyimpan berkas CSS/JS/Bootstrap/dll. ke dalam aplikasi. Berkas yang dipilih disalin
 * ke storage internal, jadi tetap ada walau berkas aslinya di perangkat sudah dihapus. HTML
 * (Grid, Flash, atau pratinjau) dapat memanggilnya hanya dengan nama berkas.
 */
public class LibraryActivity extends BaseActivity {

    private RecyclerView list;
    private TextView emptyText;
    private ProgressBar progress;
    private View fab;
    private final List<LibraryStore.Entry> entries = new ArrayList<>();
    private Adapter adapter;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean destroyed = false;

    private final ActivityResultLauncher<String[]> pickLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenMultipleDocuments(),
            uris -> {
                if (uris != null && !uris.isEmpty()) importAll(uris);
            }
    );

    private final ActivityResultLauncher<Intent> scanLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                String[] paths = result.getData().getStringArrayExtra(ScanActivity.EXTRA_PATHS);
                if (paths == null || paths.length == 0) return;
                List<Uri> uris = new ArrayList<>();
                for (String p : paths) uris.add(Uri.fromFile(new java.io.File(p)));
                importAll(uris);
            }
    );

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);

        list = findViewById(R.id.libraryList);
        emptyText = findViewById(R.id.emptyText);
        progress = findViewById(R.id.progressBar);
        fab = findViewById(R.id.fabAdd);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        fab.setOnClickListener(v -> pickLauncher.launch(new String[]{"*/*"}));
        findViewById(R.id.fabScan).setOnClickListener(v -> {
            Intent i = new Intent(this, ScanActivity.class);
            i.putExtra(ScanActivity.EXTRA_MODE, ScanActivity.MODE_LIBRARY);
            scanLauncher.launch(i);
        });

        adapter = new Adapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        // Petunjuk cara pakai ditampilkan sebagai kartu di atas daftar.
        TextView hint = new TextView(this);
        hint.setText(R.string.library_hint);
        hint.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        hint.setTextSize(12f);
        hint.setLineSpacing(0f, 1.15f);
        hint.setBackgroundResource(R.drawable.bg_card);
        int pad = (int) (14 * getResources().getDisplayMetrics().density);
        hint.setPadding(pad, pad, pad, pad);
        adapter.hintView = hint;

        reload();
    }

    private void reload() {
        progress.setVisibility(View.VISIBLE);
        new Thread(() -> {
            final List<LibraryStore.Entry> result = LibraryStore.list(getApplicationContext());
            handler.post(() -> {
                if (destroyed) return;
                entries.clear();
                entries.addAll(result);
                adapter.notifyDataSetChanged();
                progress.setVisibility(View.GONE);
                emptyText.setVisibility(entries.isEmpty() ? View.VISIBLE : View.GONE);
            });
        }).start();
    }

    private void importAll(final List<Uri> uris) {
        progress.setVisibility(View.VISIBLE);
        fab.setEnabled(false);
        new Thread(() -> {
            int ok = 0;
            int failed = 0;
            for (Uri uri : uris) {
                String name = queryName(uri);
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new java.io.IOException("cannot open");
                    if (name.toLowerCase(Locale.ROOT).endsWith(".zip")) {
                        LibraryStore.addZip(getApplicationContext(), in, name);
                    } else {
                        LibraryStore.addFile(getApplicationContext(), in, name);
                    }
                    ok++;
                } catch (Exception e) {
                    failed++;
                }
            }
            final int fOk = ok;
            final int fFailed = failed;
            handler.post(() -> {
                if (destroyed) return;
                fab.setEnabled(true);
                if (fOk > 0) {
                    Toast.makeText(this, getString(R.string.library_added, fOk), Toast.LENGTH_SHORT).show();
                }
                if (fFailed > 0) {
                    Toast.makeText(this, R.string.library_add_failed, Toast.LENGTH_LONG).show();
                }
                reload();
            });
        }).start();
    }

    private void confirmDelete(final LibraryStore.Entry entry) {
        DialogUtils.confirm(this,
                getString(R.string.library_delete_title),
                getString(R.string.library_delete_message, entry.file.getName()),
                getString(R.string.delete),
                () -> new Thread(() -> {
                    LibraryStore.delete(entry.file);
                    handler.post(() -> {
                        if (!destroyed) reload();
                    });
                }).start());
    }

    private String queryName(Uri uri) {
        String result = "";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {
        }
        if (result == null || result.isEmpty()) result = uri.getLastPathSegment();
        return result == null ? "" : result;
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ------------------------------------------------------------------ Adapter

    private class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        private static final int TYPE_HINT = 0;
        private static final int TYPE_ITEM = 1;
        View hintView;

        @Override
        public int getItemViewType(int position) {
            return position == 0 ? TYPE_HINT : TYPE_ITEM;
        }

        @Override
        public int getItemCount() {
            return entries.size() + 1;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            if (viewType == TYPE_HINT) {
                ViewGroup.MarginLayoutParams lp = new ViewGroup.MarginLayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.bottomMargin = (int) (12 * getResources().getDisplayMetrics().density);
                hintView.setLayoutParams(lp);
                return new RecyclerView.ViewHolder(hintView) {
                };
            }
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_library, parent, false);
            com.webviewlauncher.app.theme.ThemeApplier.apply(v);
            return new ItemVH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            if (!(holder instanceof ItemVH)) return;
            ItemVH h = (ItemVH) holder;
            final LibraryStore.Entry e = entries.get(position - 1);
            h.name.setText(e.file.getName());
            h.icon.setImageResource(e.isDir ? R.drawable.ic_folder : R.drawable.ic_file);
            h.info.setText(e.isDir
                    ? getString(R.string.library_folder_info, e.fileCount, FileUtils.formatFileSize(e.size))
                    : FileUtils.formatFileSize(e.size));
            h.delete.setOnClickListener(v -> confirmDelete(e));
        }
    }

    private static class ItemVH extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView name;
        final TextView info;
        final View delete;

        ItemVH(@NonNull View v) {
            super(v);
            icon = v.findViewById(R.id.itemIcon);
            name = v.findViewById(R.id.itemName);
            info = v.findViewById(R.id.itemInfo);
            delete = v.findViewById(R.id.itemDelete);
        }
    }
}
