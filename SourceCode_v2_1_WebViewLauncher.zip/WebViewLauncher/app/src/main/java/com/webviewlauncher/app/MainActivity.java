package com.webviewlauncher.app;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.ColorUtils;
import androidx.core.os.LocaleListCompat;
import androidx.core.widget.TextViewCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import android.content.pm.PackageInfo;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.PathInterpolator;
import android.widget.TextView;

import com.webviewlauncher.app.data.DataStore;
import com.webviewlauncher.app.util.DialogUtils;
import com.webviewlauncher.app.util.InternetPolicy;
import com.webviewlauncher.app.widget.OnOffToggle;
import com.webviewlauncher.app.widget.HamburgerView;
import com.webviewlauncher.app.widget.LangToggle;

/**
 * Layar utama: header (judul + logo menu), tab Grid / Flash, dan panel navigasi yang
 * meluncur dari kanan (Library, bahasa).
 */
public class MainActivity extends BaseActivity {

    private static final String STATE_NAV_OPEN = "nav_open";

    private ViewPager2 pager;
    private TextView tabGrid;
    private TextView tabFlash;
    private View tabBar;
    private View tabIndicator;
    private HamburgerView burger;
    private View scrim;
    private View navPanel;
    private ViewGroup navContent;
    private LangToggle langToggle;
    private OnOffToggle internetToggle;
    private OnOffToggle backgroundToggle;

    private final ActivityResultLauncher<String> notifPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                // Layanan latar depan tetap berjalan walau notifikasi ditolak (hanya tidak terlihat).
            });

    private boolean navOpen = false;
    private float navWidth;
    private float tabPos = 0f;

    private OnBackPressedCallback backCallback;
    private final PathInterpolator easeOut = new PathInterpolator(0.22f, 1f, 0.36f, 1f);
    private final PathInterpolator easeIn = new PathInterpolator(0.5f, 0f, 0.75f, 0f);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Fitur PDF sudah dihapus: bersihkan sisa data lama bila aplikasi diperbarui.
        new DataStore(this).purgeLegacyDocuments();

        float density = getResources().getDisplayMetrics().density;

        pager = findViewById(R.id.pager);
        tabGrid = findViewById(R.id.tabGrid);
        tabFlash = findViewById(R.id.tabFlash);
        tabBar = findViewById(R.id.tabBar);
        tabIndicator = findViewById(R.id.tabIndicator);
        burger = findViewById(R.id.menuButton);
        scrim = findViewById(R.id.scrim);
        navPanel = findViewById(R.id.navPanel);
        navContent = findViewById(R.id.navContent);
        langToggle = findViewById(R.id.langToggle);
        internetToggle = findViewById(R.id.internetToggle);
        backgroundToggle = findViewById(R.id.backgroundToggle);

        setupPager();
        setupNav();

        if (savedInstanceState != null && savedInstanceState.getBoolean(STATE_NAV_OPEN, false)) {
            navPanel.post(() -> openNav(false));
        }
    }

    /**
     * Mencabut fokus dari kotak teks mana pun dan menutup keyboard. Tanpa ini, halaman Text Editor
     * yang sudah bergeser keluar layar masih memegang fokus sehingga ketikan tetap masuk ke sana.
     */
    private void releaseTyping() {
        View focus = getCurrentFocus();
        if (focus != null) focus.clearFocus();
        android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager)
                getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(pager.getWindowToken(), 0);
        tabBar.setFocusableInTouchMode(true);
        tabBar.requestFocus();      // fokus dialihkan ke bilah tab (bukan kotak teks)
    }

    // ---------------------------------------------------------------- Tab Grid | Flash

    private void setupPager() {
        pager.setAdapter(new FragmentStateAdapter(this) {
            @NonNull
            @Override
            public Fragment createFragment(int position) {
                return position == 0 ? new GameFragment() : new EditorFragment();
            }

            @Override
            public int getItemCount() {
                return 2;
            }
        });
        // Geser sentuh dimatikan agar tidak bentrok dengan gulir kotak kode; pindah lewat tab.
        pager.setUserInputEnabled(false);
        pager.setOffscreenPageLimit(1);

        tabGrid.setOnClickListener(v -> {
            releaseTyping();
            pager.setCurrentItem(0, true);
        });
        tabFlash.setOnClickListener(v -> {
            releaseTyping();
            pager.setCurrentItem(1, true);
        });

        tabBar.addOnLayoutChangeListener((v, l, tp, r, b, ol, ot, or, ob) -> {
            // Ruang kosong di tengah mengikuti lebar lekukan bilah (proporsional di semua layar)
            int w = r - l;
            if (w > 0) {
                int gap = (int) (com.webviewlauncher.app.widget.NotchBarLayout.notchWidth(w, getResources().getDisplayMetrics().density) * 0.8f);
                View g = findViewById(R.id.tabGap);
                if (g.getLayoutParams().width != gap) {
                    g.getLayoutParams().width = gap;
                    g.requestLayout();
                }
            }
            applyTabPosition(tabPos);
        });

        // Bilah tab disembunyikan saat keyboard tampil agar area ketik tidak sempit
        final View root = findViewById(android.R.id.content);
        root.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            android.graphics.Rect r = new android.graphics.Rect();
            root.getWindowVisibleDisplayFrame(r);
            int full = root.getRootView().getHeight();
            boolean keyboard = full > 0 && (full - r.bottom) > full * 0.15f;
            tabBar.setVisibility(keyboard ? View.GONE : View.VISIBLE);
        });

        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float offset, int offsetPixels) {
                applyTabPosition(position + offset);
            }

            @Override
            public void onPageSelected(int position) {
                releaseTyping();
            }
        });
        applyTabPosition(pager.getCurrentItem());
    }

    /** pos 0..1: 0 = Grid terpilih penuh, 1 = Flash terpilih penuh. */
    private void applyTabPosition(float pos) {
        tabPos = pos;
        View row = findViewById(R.id.tabRow);
        if (tabGrid.getWidth() > 0 && tabFlash.getWidth() > 0 && row != null) {
            float cA = row.getLeft() + tabGrid.getLeft() + tabGrid.getWidth() / 2f;
            float cB = row.getLeft() + tabFlash.getLeft() + tabFlash.getWidth() / 2f;
            float cx = cA + (cB - cA) * Math.max(0f, Math.min(1f, pos));
            tabIndicator.setTranslationX(cx - tabIndicator.getWidth() / 2f);
        }

        int on = com.webviewlauncher.app.theme.Palette.accent(this);
        int off = ContextCompat.getColor(this, R.color.text_faint);
        int iconOn = com.webviewlauncher.app.theme.Palette.accent(this);
        float clamped = Math.max(0f, Math.min(1f, pos));

        int gridText = ColorUtils.blendARGB(on, off, clamped);
        int flashText = ColorUtils.blendARGB(off, on, clamped);
        tabGrid.setTextColor(gridText);
        tabFlash.setTextColor(flashText);
        TextViewCompat.setCompoundDrawableTintList(tabGrid,
                ColorStateList.valueOf(ColorUtils.blendARGB(iconOn, off, clamped)));
        TextViewCompat.setCompoundDrawableTintList(tabFlash,
                ColorStateList.valueOf(ColorUtils.blendARGB(off, iconOn, clamped)));
    }

    // ---------------------------------------------------------------- Panel navigasi

    private void setupNav() {
        float density = getResources().getDisplayMetrics().density;
        navWidth = Math.min(290 * density, getResources().getDisplayMetrics().widthPixels * 0.86f);
        ViewGroup.LayoutParams lp = navPanel.getLayoutParams();
        lp.width = (int) navWidth;
        navPanel.setLayoutParams(lp);

        backCallback = new OnBackPressedCallback(false) {
            @Override
            public void handleOnBackPressed() {
                closeNav(true);
            }
        };
        getOnBackPressedDispatcher().addCallback(this, backCallback);

        burger.setOnClickListener(v -> {
            if (navOpen) closeNav(true);
            else openNav(true);
        });
        scrim.setOnClickListener(v -> closeNav(true));

        findViewById(R.id.navTheme).setOnClickListener(v -> {
            startActivity(new Intent(this, ThemeActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            closeNav(true);
        });

        findViewById(R.id.navLibrary).setOnClickListener(v -> {
            startActivity(new Intent(this, LibraryActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            closeNav(true);
        });

        // Togle bahasa: kiri = Indonesia, kanan = Inggris.
        boolean english = "en".equals(getResources().getConfiguration().locale.getLanguage());
        langToggle.setEnglish(english, false);
        langToggle.setOnToggleListener(isEnglish -> {
            String tag = isEnglish ? "en" : "id";
            getSharedPreferences(App.PREFS, MODE_PRIVATE).edit().putString(App.KEY_LANG, tag).apply();
            // Menerapkan bahasa membuat layar dibuat ulang; panel navigasi dibuka lagi otomatis.
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag));
        });

        // Akses Internet (bawaan MATI) dan Aktivitas Latar Belakang
        syncNetworkToggles();
        internetToggle.setListener(this::onInternetRequest);
        backgroundToggle.setListener(this::onBackgroundRequest);

        String version = "";
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            version = "v" + info.versionName;
        } catch (Exception ignored) {
        }
        ((TextView) findViewById(R.id.navVersion)).setText(
                getString(R.string.app_name) + "  ·  " + version);
    }

    private void syncNetworkToggles() {
        internetToggle.setChecked(InternetPolicy.isEnabled(this), false);
        backgroundToggle.setChecked(InternetPolicy.isBackground(this), false);
    }

    private void onInternetRequest(boolean on) {
        if (!on) {
            InternetPolicy.setEnabled(this, false);
            internetToggle.setChecked(false, true);
            return;
        }
        if (!InternetPolicy.wasWarned(this)) {
            DialogUtils.confirm(this, getString(R.string.internet_warn_title),
                    getString(R.string.internet_warn_message), getString(R.string.internet_warn_confirm), () -> {
                        InternetPolicy.markWarned(this);
                        enableInternet();
                    });
            return;
        }
        enableInternet();
    }

    private void enableInternet() {
        InternetPolicy.setEnabled(this, true);
        internetToggle.setChecked(true, true);
        if (!InternetPolicy.hasNetwork(this)) {
            Toast.makeText(this, R.string.internet_no_connection, Toast.LENGTH_LONG).show();
        }
    }

    private void onBackgroundRequest(boolean on) {
        if (on && Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
        InternetPolicy.setBackground(this, on);
        backgroundToggle.setChecked(on, true);
        App.syncService(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Togle internet bisa saja dimatikan otomatis saat pengguna keluar dari aplikasi.
        syncNetworkToggles();
    }

    /** Dipakai halaman Text Editor: bila panel navigasi terbuka, tombol kembali menutupnya dulu. */
    public boolean closeNavIfOpen() {
        if (!navOpen) return false;
        closeNav(true);
        return true;
    }

    private void openNav(boolean animate) {
        releaseTyping();
        navOpen = true;
        backCallback.setEnabled(true);
        scrim.setVisibility(View.VISIBLE);
        navPanel.setVisibility(View.VISIBLE);
        burger.animateTo(1f, animate);

        if (!animate) {
            scrim.animate().cancel();
            navPanel.animate().cancel();
            scrim.setAlpha(1f);
            navPanel.setTranslationX(0f);
            for (int i = 0; i < navContent.getChildCount(); i++) {
                View c = navContent.getChildAt(i);
                c.animate().cancel();
                c.setAlpha(1f);
                c.setTranslationX(0f);
            }
            return;
        }

        if (navPanel.getTranslationX() == 0f) navPanel.setTranslationX(navWidth);
        navPanel.animate().translationX(0f).setDuration(420).setInterpolator(easeOut).start();
        scrim.animate().alpha(1f).setDuration(320).start();

        float shift = 28 * getResources().getDisplayMetrics().density;
        for (int i = 0; i < navContent.getChildCount(); i++) {
            View c = navContent.getChildAt(i);
            c.animate().cancel();
            c.setAlpha(0f);
            c.setTranslationX(shift);
            c.animate().alpha(1f).translationX(0f)
                    .setStartDelay(110L + i * 55L).setDuration(380).setInterpolator(easeOut).start();
        }
    }

    private void closeNav(boolean animate) {
        navOpen = false;
        backCallback.setEnabled(false);
        burger.animateTo(0f, animate);

        if (!animate) {
            scrim.setAlpha(0f);
            scrim.setVisibility(View.GONE);
            navPanel.setVisibility(View.GONE);
            return;
        }

        navPanel.animate().translationX(navWidth).setDuration(300).setInterpolator(easeIn)
                .withEndAction(() -> {
                    if (!navOpen) navPanel.setVisibility(View.GONE);
                }).start();
        scrim.animate().alpha(0f).setDuration(280)
                .withEndAction(() -> {
                    if (!navOpen) scrim.setVisibility(View.GONE);
                }).start();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(STATE_NAV_OPEN, navOpen);
    }
}
