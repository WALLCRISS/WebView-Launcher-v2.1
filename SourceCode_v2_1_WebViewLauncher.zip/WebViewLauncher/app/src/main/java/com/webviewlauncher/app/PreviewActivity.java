package com.webviewlauncher.app;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.widget.Toast;

import com.webviewlauncher.app.util.FileUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Pratinjau langsung: muncul di daftar "Buka dengan" saat berkas .html/.css/.js ditekan di
 * pengelola berkas. Berkas tidak disimpan ke Grid maupun Flash; hanya disalin sementara dan
 * dihapus lagi saat layar ditutup.
 *
 * - .html: dijalankan seperti WebView Launcher biasa (layar penuh). Berkas yang tidak ada
 *   (css/js yang dipanggil) dicari di Library.
 * - .css / .js: berdiri sendiri tidak menampilkan apa-apa, jadi ditampilkan sebagai teks kode.
 */
public class PreviewActivity extends WebGameActivity {

    private static final long MAX_TEXT_BYTES = 32L * 1024 * 1024;

    private File previewDir;

    @SuppressWarnings("deprecation")
    @Override
    protected void loadContent() {
        Intent intent = getIntent();
        Uri uri = intent.getData();
        if (uri == null && intent.hasExtra(Intent.EXTRA_STREAM)) {
            uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        }
        if (uri == null) {
            fail();
            return;
        }

        final Uri source = uri;
        final File dir = new File(getFilesDir(), "preview/" + FileUtils.randomId());
        previewDir = dir;

        new Thread(() -> {
            try {
                final File entry = prepare(source, dir);
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    showContent(dir, entry);
                });
            } catch (Exception e) {
                runOnUiThread(this::fail);
            }
        }).start();
    }

    private void fail() {
        Toast.makeText(this, R.string.preview_error, Toast.LENGTH_LONG).show();
        finish();
    }

    private File prepare(Uri source, File dir) throws IOException {
        String name = queryName(source);
        String mime = getContentResolver().getType(source);
        String lower = name.toLowerCase(Locale.ROOT);
        String mimeLower = mime == null ? "" : mime.toLowerCase(Locale.ROOT);

        boolean isCss = lower.endsWith(".css") || mimeLower.equals("text/css");
        boolean isJs = lower.endsWith(".js") || lower.endsWith(".mjs") || mimeLower.contains("javascript");

        if (!dir.mkdirs() && !dir.isDirectory()) throw new IOException("mkdir failed");
        File index = new File(dir, "index.html");

        try (InputStream in = getContentResolver().openInputStream(source)) {
            if (in == null) throw new IOException("cannot open");
            if (!isCss && !isJs) {
                FileUtils.copyStreamToFile(in, index);
                return index;
            }
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] chunk = new byte[16384];
            long total = 0;
            int n;
            while ((n = in.read(chunk)) != -1) {
                total += n;
                if (total > MAX_TEXT_BYTES) throw new IOException("too large");
                buf.write(chunk, 0, n);
            }
            String text = new String(buf.toByteArray(), StandardCharsets.UTF_8);
            try (FileOutputStream out = new FileOutputStream(index)) {
                out.write(codeViewPage(name, text).getBytes(StandardCharsets.UTF_8));
            }
        }
        return index;
    }

    /** Halaman penampil kode bertema gelap WebView Launcher. */
    private static String codeViewPage(String title, String code) {
        StringBuilder sb = new StringBuilder(code.length() + code.length() / 8 + 1024);
        sb.append("<!DOCTYPE html><html><head><meta charset=\"utf-8\">")
                .append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
                .append("<title>").append(escape(title)).append("</title><style>")
                .append("html,body{margin:0;background:#13141C;color:#EDEBFA}")
                .append("pre{margin:0;padding:68px 16px 28px;font:13px/1.55 monospace;white-space:pre;tab-size:2;overflow:auto}")
                .append("</style></head><body><pre>");
        for (int i = 0; i < code.length(); i++) {
            char c = code.charAt(i);
            switch (c) {
                case '&': sb.append("&amp;"); break;
                case '<': sb.append("&lt;"); break;
                case '>': sb.append("&gt;"); break;
                default: sb.append(c);
            }
        }
        sb.append("</pre></body></html>");
        return sb.toString();
    }

    private static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private String queryName(Uri uri) {
        String result = "";
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) result = cursor.getString(idx);
                }
            } catch (Exception ignored) {
            }
        }
        if (result == null || result.isEmpty()) result = uri.getLastPathSegment();
        return result == null ? "" : result;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (previewDir != null && isFinishing()) FileUtils.deleteRecursive(previewDir);
    }
}
