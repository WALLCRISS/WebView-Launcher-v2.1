package com.webviewlauncher.app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.webviewlauncher.app.util.DialogUtils;
import com.webviewlauncher.app.util.FileUtils;
import com.webviewlauncher.app.util.StorageScanner;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Pindai: memindai seluruh folder di perangkat, menampilkan hanya folder yang berisi berkas
 * html / css / js / zip. Buka folder lalu pilih berkas.
 *
 * mode "game"    : hanya html/htm/zip; ketuk satu berkas langsung mengembalikannya.
 * mode "library" : html/css/js/zip; boleh memilih banyak lalu tombol Tambahkan.
 * Hasil: EXTRA_PATHS (array path absolut).
 */
public class ScanActivity extends BaseActivity {

    public static final String EXTRA_MODE = "mode";
    public static final String MODE_GAME = "game";
    public static final String MODE_LIBRARY = "library";
    public static final String EXTRA_PATHS = "paths";

    private static final int REQ_LEGACY_STORAGE = 77;

    private RecyclerView list;
    private TextView status;
    private TextView title;
    private TextView emptyText;
    private View progress;
    private View addButton;
    private TextView addLabel;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean destroyed = false;
    private boolean libraryMode;
    private volatile boolean cancelled = false;
    private boolean scanning = false;
    private boolean askedPermission = false;

    private final List<StorageScanner.Group> groups = new ArrayList<>();
    private StorageScanner.Group openGroup = null;
    private final Set<File> selected = new LinkedHashSet<>();
    private Adapter adapter;
    private OnBackPressedCallback backCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);
        libraryMode = MODE_LIBRARY.equals(getIntent().getStringExtra(EXTRA_MODE));

        list = findViewById(R.id.scanList);
        status = findViewById(R.id.scanStatus);
        title = findViewById(R.id.scanTitle);
        emptyText = findViewById(R.id.scanEmpty);
        progress = findViewById(R.id.scanProgress);
        addButton = findViewById(R.id.scanAdd);
        addLabel = findViewById(R.id.scanAddLabel);

        adapter = new Adapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        findViewById(R.id.backButton).setOnClickListener(v -> handleBack());
        findViewById(R.id.rescanButton).setOnClickListener(v -> {
            if (!scanning) startScanIfPermitted();
        });
        addButton.setOnClickListener(v -> returnSelected(new ArrayList<>(selected)));

        backCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                handleBack();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, backCallback);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (groups.isEmpty() && !scanning) startScanIfPermitted();
    }

    private void handleBack() {
        if (openGroup != null) {
            openGroup = null;
            selected.clear();
            showGroups();
        } else {
            cancelled = true;
            finish();
        }
    }

    // ------------------------------------------------------------------ izin

    private boolean hasPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        }
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void startScanIfPermitted() {
        if (hasPermission()) {
            startScan();
            return;
        }
        if (askedPermission) {
            progress.setVisibility(View.GONE);
            status.setText(R.string.scan_permission_denied);
            return;
        }
        askedPermission = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            DialogUtils.confirm(this, getString(R.string.scan_permission_title),
                    getString(R.string.scan_permission_message),
                    getString(R.string.scan_permission_open), () -> {
                        try {
                            Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                    Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Exception e) {
                            startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                        }
                    });
            progress.setVisibility(View.GONE);
            status.setText(R.string.scan_permission_denied);
            // setelah kembali dari Pengaturan, onResume memulai pemindaian bila izin sudah diberikan
            askedPermission = false;
            return;
        }
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_LEGACY_STORAGE);
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_LEGACY_STORAGE) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startScan();
            else {
                progress.setVisibility(View.GONE);
                status.setText(R.string.scan_permission_denied);
            }
        }
    }

    // ------------------------------------------------------------------ pemindaian

    private void startScan() {
        scanning = true;
        cancelled = false;
        openGroup = null;
        selected.clear();
        groups.clear();
        adapter.notifyDataSetChanged();
        emptyText.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);
        status.setText(getString(R.string.scan_scanning, 0));
        title.setText(R.string.scan_title);
        addButton.setVisibility(View.GONE);

        final Set<String> exts = new HashSet<>(libraryMode
                ? Arrays.asList("html", "htm", "css", "js", "mjs", "zip")
                : Arrays.asList("html", "htm", "zip"));

        new Thread(() -> {
            final long[] lastPost = {0};
            final List<StorageScanner.Group> result = StorageScanner.scan(getApplicationContext(), exts,
                    new StorageScanner.Callback() {
                        @Override
                        public void onProgress(final int found) {
                            long now = System.currentTimeMillis();
                            if (now - lastPost[0] < 250) return;
                            lastPost[0] = now;
                            handler.post(() -> {
                                if (!destroyed && scanning) status.setText(getString(R.string.scan_scanning, found));
                            });
                        }

                        @Override
                        public boolean isCancelled() {
                            return cancelled || destroyed;
                        }
                    });
            handler.post(() -> {
                if (destroyed) return;
                scanning = false;
                groups.clear();
                groups.addAll(result);
                progress.setVisibility(View.GONE);
                showGroups();
            });
        }).start();
    }

    private void showGroups() {
        title.setText(R.string.scan_title);
        addButton.setVisibility(View.GONE);
        status.setText(getString(R.string.scan_done, groups.size()));
        emptyText.setVisibility(groups.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
        list.scrollToPosition(0);
    }

    private void showFiles(StorageScanner.Group g) {
        openGroup = g;
        selected.clear();
        title.setText(StorageScanner.displayPath(this, g.dir));
        status.setText(getString(R.string.scan_folder_info, g.files.size()));
        emptyText.setVisibility(View.GONE);
        updateAddButton();
        adapter.notifyDataSetChanged();
        list.scrollToPosition(0);
    }

    private void updateAddButton() {
        boolean show = libraryMode && openGroup != null && !selected.isEmpty();
        addButton.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) addLabel.setText(getString(R.string.scan_add_selected, selected.size()));
    }

    private void returnSelected(List<File> files) {
        if (files.isEmpty()) return;
        String[] paths = new String[files.size()];
        for (int i = 0; i < paths.length; i++) paths[i] = files.get(i).getAbsolutePath();
        Intent data = new Intent();
        data.putExtra(EXTRA_PATHS, paths);
        setResult(Activity.RESULT_OK, data);
        finish();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        cancelled = true;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ------------------------------------------------------------------ daftar

    private class Adapter extends RecyclerView.Adapter<Adapter.VH> {

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View item = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_scan, parent, false);
            com.webviewlauncher.app.theme.ThemeApplier.apply(item);
            return new VH(item);
        }

        @Override
        public int getItemCount() {
            return openGroup == null ? groups.size() : openGroup.files.size();
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            if (openGroup == null) {
                final StorageScanner.Group g = groups.get(position);
                h.icon.setImageResource(R.drawable.ic_folder);
                h.name.setText(StorageScanner.displayPath(ScanActivity.this, g.dir));
                h.info.setText(getString(R.string.scan_folder_info, g.files.size()));
                h.check.setVisibility(View.GONE);
                h.itemView.setOnClickListener(v -> showFiles(g));
            } else {
                final File f = openGroup.files.get(position);
                h.icon.setImageResource(R.drawable.ic_file);
                h.name.setText(f.getName());
                h.info.setText(FileUtils.formatFileSize(f.length()));
                if (libraryMode) {
                    h.check.setVisibility(View.VISIBLE);
                    h.check.setChecked(selected.contains(f));
                    h.itemView.setOnClickListener(v -> {
                        if (!selected.remove(f)) selected.add(f);
                        h.check.setChecked(selected.contains(f));
                        updateAddButton();
                    });
                } else {
                    h.check.setVisibility(View.GONE);
                    h.itemView.setOnClickListener(v -> {
                        List<File> one = new ArrayList<>();
                        one.add(f);
                        returnSelected(one);
                    });
                }
            }
        }

        class VH extends RecyclerView.ViewHolder {
            final ImageView icon;
            final TextView name;
            final TextView info;
            final CheckBox check;

            VH(@NonNull View v) {
                super(v);
                icon = v.findViewById(R.id.itemIcon);
                name = v.findViewById(R.id.itemName);
                info = v.findViewById(R.id.itemInfo);
                check = v.findViewById(R.id.itemCheck);
            }
        }
    }
}
