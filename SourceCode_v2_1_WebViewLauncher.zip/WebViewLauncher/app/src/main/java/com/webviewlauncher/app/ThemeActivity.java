package com.webviewlauncher.app;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.webviewlauncher.app.theme.Palette;
import com.webviewlauncher.app.util.ColorPickerDialog;
import com.webviewlauncher.app.widget.LangToggle;

/**
 * Menu Tema: togle mode gelap (kiri, bawaan) / terang (kanan), dan Color: daftar warna utama
 * (Ungu, Oren, Coklat, Cyan, Merah, Biru, Kuning, Silver) + Custom (roda warna lengkap).
 */
public class ThemeActivity extends BaseActivity {

    private LinearLayout colorGrid;
    private View colorSwatch;
    private TextView colorName;
    private View colorArrow;
    private boolean expanded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        LangToggle mode = findViewById(R.id.modeToggle);
        mode.setLabels(getString(R.string.theme_dark), getString(R.string.theme_light), 12f);
        mode.setEnglish(!Palette.isDark(this), false);     // kanan = terang
        mode.setOnToggleListener(light -> Palette.setDark(this, !light));

        colorGrid = findViewById(R.id.colorGrid);
        colorSwatch = findViewById(R.id.colorSwatch);
        colorName = findViewById(R.id.colorName);
        colorArrow = findViewById(R.id.colorArrow);
        findViewById(R.id.colorRow).setOnClickListener(v -> toggleColors());

        buildGrid();
        updateHeader();
        if (savedInstanceState != null && savedInstanceState.getBoolean("expanded")) {
            expanded = true;
            colorGrid.setVisibility(View.VISIBLE);
            colorArrow.setRotation(180f);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("expanded", expanded);
    }

    private void toggleColors() {
        expanded = !expanded;
        colorArrow.animate().rotation(expanded ? 180f : 0f).setDuration(220).start();
        if (expanded) {
            colorGrid.setAlpha(0f);
            colorGrid.setVisibility(View.VISIBLE);
            colorGrid.animate().alpha(1f).setDuration(220).start();
        } else {
            colorGrid.animate().alpha(0f).setDuration(160).withEndAction(() -> {
                if (!expanded) colorGrid.setVisibility(View.GONE);
            }).start();
        }
    }

    private void updateHeader() {
        int preset = Palette.getPreset(this);
        int accent = Palette.accent(this);
        colorSwatch.setBackground(circle(accent, 0, 0));
        colorName.setText(preset == Palette.CUSTOM_INDEX ? getString(R.string.theme_custom)
                : getString(Palette.PRESET_NAME[preset]));
    }

    private GradientDrawable circle(int fill, int strokeColor, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        if (strokePx > 0) g.setStroke(strokePx, strokeColor);
        return g;
    }

    private void buildGrid() {
        colorGrid.removeAllViews();
        float d = getResources().getDisplayMetrics().density;
        int selected = Palette.getPreset(this);
        int total = Palette.PRESET_ACCENT.length + 1;   // + Custom
        LinearLayout row = null;
        for (int i = 0; i < total; i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                colorGrid.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            final boolean isCustom = i == Palette.PRESET_ACCENT.length;
            final int index = isCustom ? Palette.CUSTOM_INDEX : i;
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(0, (int) (10 * d), 0, (int) (6 * d));
            cell.setClickable(true);

            View dot = new View(this);
            boolean isSel = selected == index;
            GradientDrawable g;
            if (isCustom) {
                g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setGradientType(GradientDrawable.SWEEP_GRADIENT);
                g.setColors(new int[]{0xFFFF0000, 0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFF0000FF,
                        0xFFFF00FF, 0xFFFF0000});
            } else {
                g = circle(Palette.PRESET_ACCENT[i], 0, 0);
            }
            g.setStroke((int) ((isSel ? 3 : 1) * d),
                    isSel ? ContextCompat.getColor(this, R.color.text_primary)
                            : ContextCompat.getColor(this, R.color.divider));
            dot.setBackground(g);
            cell.addView(dot, new LinearLayout.LayoutParams((int) (46 * d), (int) (46 * d)));

            TextView label = new TextView(this);
            label.setText(isCustom ? getString(R.string.theme_custom) : getString(Palette.PRESET_NAME[i]));
            label.setTextSize(11f);
            label.setTextColor(ContextCompat.getColor(this, isSel ? R.color.text_primary : R.color.text_secondary));
            label.setGravity(Gravity.CENTER);
            label.setPadding(0, (int) (6 * d), 0, 0);
            cell.addView(label);

            cell.setOnClickListener(v -> {
                if (isCustom) {
                    ColorPickerDialog.show(this, Palette.getCustom(this), color -> {
                        Palette.setCustom(this, color);
                        recreate();
                    });
                } else {
                    Palette.setPreset(this, index);
                    recreate();
                }
            });
            row.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        // sel kosong agar baris terakhir tetap rata 3 kolom
        if (total % 3 != 0 && row != null) {
            for (int k = total % 3; k < 3; k++) {
                row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            }
        }
    }
}
