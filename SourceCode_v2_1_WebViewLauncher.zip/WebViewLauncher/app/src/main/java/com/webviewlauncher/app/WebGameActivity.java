package com.webviewlauncher.app;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;

import com.webviewlauncher.app.util.InternetPolicy;
import com.webviewlauncher.app.util.LibraryStore;
import com.webviewlauncher.app.widget.CollapsibleNav;

import java.io.File;
import java.io.IOException;

/**
 * Menampilkan berkas HTML lokal (proyek Grid, kode Flash, atau pratinjau) lewat WebView
 * layar penuh. Memakai WebViewAssetLoader agar halaman dianggap berasal dari origin https://
 * lokal (bukan file://), sehingga modul JavaScript, fetch(), dan aset relatif tetap berfungsi.
 *
 * Library: bila sebuah berkas yang diminta halaman tidak ada di proyek, aplikasi mencarinya
 * di Library, jadi HTML cukup menulis nama berkasnya seolah berada di folder yang sama.
 *
 * Extras: "entry_path" (berkas HTML utama), "root_path" (opsional, akar proyek; bila kosong
 * dicari dari folder proyek di bawah games/), "title".
 */
public class WebGameActivity extends BaseActivity {

    private static final String DOMAIN = "appassets.androidx.webkit.internal";

    private WebView webView;
    private FrameLayout customViewContainer;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private View exitButton;
    private CollapsibleNav collapsibleNav;

    private File contentRoot;
    private WebViewAssetLoader contentLoader;
    private WebViewAssetLoader libLoader;
    private LibraryStore.Index libIndex;

    @Override
    protected boolean recreateOnThemeChange() {
        return false;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyImmersiveMode();
        setContentView(R.layout.activity_web_game);

        webView = findViewById(R.id.webView);
        customViewContainer = findViewById(R.id.customViewContainer);
        exitButton = findViewById(R.id.exitButton);
        View navLine = findViewById(R.id.navLine);

        exitButton.setOnClickListener(v -> finish());
        collapsibleNav = new CollapsibleNav(exitButton, navLine);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        // Halaman lokal (https://) boleh memanggil localhost (http://) saat Akses Internet hidup.
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        applyNetworkPolicy();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                customViewContainer.addView(view);
                customViewContainer.setVisibility(View.VISIBLE);
                webView.setVisibility(View.GONE);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                customViewContainer.removeView(customView);
                customViewContainer.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
                customView = null;
                if (customViewCallback != null) {
                    customViewCallback.onCustomViewHidden();
                    customViewCallback = null;
                }
            }
        });

        loadContent();
    }

    /**
     * Menentukan apa yang ditampilkan. Bawaan: membaca extras intent. PreviewActivity
     * menimpa ini untuk membuka berkas dari aplikasi lain.
     */
    protected void loadContent() {
        String entryPath = getIntent().getStringExtra("entry_path");
        if (entryPath == null) {
            finish();
            return;
        }
        File entryFile = new File(entryPath);
        String rootPath = getIntent().getStringExtra("root_path");
        File root = rootPath != null ? new File(rootPath) : resolveContentRoot(entryFile);
        showContent(root, entryFile);
    }

    /** Menyiapkan penyaji berkas lokal lalu memuat halaman utama. Harus dipanggil di thread utama. */
    protected void showContent(File root, File entryFile) {
        contentRoot = root;
        libIndex = new LibraryStore.Index(LibraryStore.dir(this));

        contentLoader = new WebViewAssetLoader.Builder()
                .setDomain(DOMAIN)
                .addPathHandler("/content/", new WebViewAssetLoader.InternalStoragePathHandler(this, root))
                .build();
        libLoader = new WebViewAssetLoader.Builder()
                .setDomain(DOMAIN)
                .addPathHandler("/lib/", new WebViewAssetLoader.InternalStoragePathHandler(this, LibraryStore.dir(this)))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return intercept(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (DOMAIN.equals(u.getHost())) return false;
                // Navigasi/browsing keluar hanya boleh bila Akses Internet hidup dan ada koneksi.
                return isWebScheme(u.getScheme()) && !InternetPolicy.isAllowed(WebGameActivity.this);
            }
        });

        webView.loadUrl("https://" + DOMAIN + "/content/" + relativePath(root, entryFile));
    }

    /**
     * Urutan: berkas proyek -> berkas Library (nama persis atau nama berkasnya saja).
     * Alamat yang diawali "/" tanpa "content/" (mis. "/style.css") dianggap relatif terhadap akar proyek.
     */
    @Nullable
    private WebResourceResponse intercept(Uri uri) {
        if (!DOMAIN.equals(uri.getHost())) {
            if (isWebScheme(uri.getScheme()) && !InternetPolicy.isAllowed(this)) {
                return InternetPolicy.blockedResponse();   // 100% offline saat togle mati
            }
            return null;
        }
        String path = uri.getPath();
        if (path == null) return null;

        if (path.startsWith("/lib/")) {
            return libLoader.shouldInterceptRequest(uri);
        }

        String rel = path.startsWith("/content/") ? path.substring("/content/".length())
                : (path.startsWith("/") ? path.substring(1) : path);
        if (rel.isEmpty()) return null;

        if (isProjectFile(rel)) {
            Uri contentUri = path.startsWith("/content/") ? uri
                    : Uri.parse("https://" + DOMAIN + "/content/" + Uri.encode(rel, "/"));
            return contentLoader.shouldInterceptRequest(contentUri);
        }

        String libRel = libIndex.find(rel);
        if (libRel != null) {
            return libLoader.shouldInterceptRequest(
                    Uri.parse("https://" + DOMAIN + "/lib/" + Uri.encode(libRel, "/")));
        }
        return null;
    }

    private static boolean isWebScheme(String scheme) {
        return "http".equals(scheme) || "https".equals(scheme) || "ws".equals(scheme) || "wss".equals(scheme);
    }

    /** Memblokir/mengizinkan pemuatan dari jaringan sesuai togle Akses Internet (dan ada tidaknya koneksi). */
    private void applyNetworkPolicy() {
        if (webView == null) return;
        try {
            webView.getSettings().setBlockNetworkLoads(!InternetPolicy.isAllowed(this));
        } catch (SecurityException ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyNetworkPolicy();
    }

    private boolean isProjectFile(String rel) {
        try {
            File f = new File(contentRoot, rel);
            String root = contentRoot.getCanonicalPath();
            String canon = f.getCanonicalPath();
            return canon.startsWith(root + File.separator) && f.isFile();
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Mencari folder akar dari sebuah berkas HTML yang diekstrak, yaitu folder
     * langsung di bawah "games/" (folder ber-ID unik milik satu proyek HTML).
     */
    private File resolveContentRoot(File entryFile) {
        File gamesRoot = new File(getFilesDir(), "games");
        File current = entryFile;
        File child = current;
        while (current != null && !current.equals(gamesRoot)) {
            child = current;
            current = current.getParentFile();
        }
        return current != null ? child : entryFile.getParentFile();
    }

    private String relativePath(File root, File file) {
        String rootPath = root.getAbsolutePath();
        String filePath = file.getAbsolutePath();
        if (filePath.startsWith(rootPath)) {
            String rel = filePath.substring(rootPath.length());
            if (rel.startsWith(File.separator)) rel = rel.substring(1);
            return rel;
        }
        return file.getName();
    }

    private void applyImmersiveMode() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        View decor = getWindow().getDecorView();
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decor.setSystemUiVisibility(flags);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (customView != null) {
                webView.getWebChromeClient().onHideCustomView();
                return true;
            }
            if (webView.canGoBack()) {
                webView.goBack();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        if (collapsibleNav != null) collapsibleNav.destroy();
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
