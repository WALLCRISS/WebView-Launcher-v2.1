package com.webviewlauncher.app.data;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.webviewlauncher.app.model.GameItem;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Penyimpanan sederhana berbasis berkas JSON di storage internal aplikasi.
 * Tidak memerlukan database eksternal, sepenuhnya offline.
 */
public class DataStore {

    private static final String GAMES_FILE = "games.json";
    private static final String LEGACY_DOCUMENTS_FILE = "documents.json";

    private final Context context;
    private final File gamesFile;

    public DataStore(Context context) {
        this.context = context.getApplicationContext();
        gamesFile = new File(this.context.getFilesDir(), GAMES_FILE);
    }

    public synchronized List<GameItem> loadGames() {
        List<GameItem> list = new ArrayList<>();
        String content = readFile(gamesFile);
        if (content == null) return list;
        try {
            JSONArray arr = new JSONArray(content);
            for (int i = 0; i < arr.length(); i++) {
                list.add(GameItem.fromJson(arr.getJSONObject(i)));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public synchronized void saveGames(List<GameItem> items) {
        try {
            JSONArray arr = new JSONArray();
            for (GameItem item : items) arr.put(item.toJson());
            writeFile(gamesFile, arr.toString());
        } catch (Exception ignored) {
        }
    }

    /**
     * Fitur PDF sudah dihapus. Bila aplikasi diperbarui dari versi lama, bersihkan sisa
     * daftar PDF: ikonnya, izin akses berkas yang dulu disimpan, dan berkas daftarnya.
     */
    public synchronized void purgeLegacyDocuments() {
        File legacy = new File(context.getFilesDir(), LEGACY_DOCUMENTS_FILE);
        if (!legacy.exists()) return;
        String content = readFile(legacy);
        if (content != null) {
            try {
                JSONArray arr = new JSONArray(content);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String iconPath = o.optString("iconPath", "");
                    if (!iconPath.isEmpty()) new File(iconPath).delete();
                    String uri = o.optString("documentUri", "");
                    if (!uri.isEmpty()) {
                        try {
                            context.getContentResolver().releasePersistableUriPermission(
                                    Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } catch (Exception ignored) {
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
        legacy.delete();
    }

    private String readFile(File file) {
        if (!file.exists()) return null;
        try (FileInputStream fis = new FileInputStream(file)) {
            StringBuilder sb = new StringBuilder();
            InputStreamReader reader = new InputStreamReader(fis, StandardCharsets.UTF_8);
            char[] buffer = new char[4096];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, read);
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private void writeFile(File file, String content) {
        try (FileOutputStream fos = new FileOutputStream(file, false)) {
            fos.write(content.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
        }
    }
}
