package com.webviewlauncher.app.theme;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.ColorUtils;

import com.webviewlauncher.app.App;
import com.webviewlauncher.app.R;

/**
 * Tema aplikasi: mode gelap/terang (bawaan gelap) dan warna utama (aksen). Disimpan di
 * SharedPreferences sehingga tidak hilang saat aplikasi ditutup (hanya hilang bila data dihapus).
 */
public final class Palette {

    public static final String KEY_DARK = "theme_dark";
    public static final String KEY_PRESET = "theme_preset";
    public static final String KEY_CUSTOM = "theme_custom";

    public static final int CUSTOM_INDEX = 8;

    /** Urutan: Ungu (bawaan), Oren, Coklat, Cyan, Merah, Biru, Kuning, Silver. */
    public static final int[] PRESET_ACCENT = {
            0xFF7C6FEA, 0xFFFF9A3C, 0xFFA1745A, 0xFF26C6DA, 0xFFEF5350, 0xFF4A90F5, 0xFFFFD54A, 0xFFC0C5CE};
    public static final int[] PRESET_DIM = {
            0xFF5B4FC7, 0xFFE8750F, 0xFF7B5340, 0xFF00A0B4, 0xFFC62828, 0xFF2F6FD6, 0xFFE0B000, 0xFF8E95A3};
    public static final int[] PRESET_NAME = {
            R.string.theme_purple, R.string.theme_orange, R.string.theme_brown, R.string.theme_cyan,
            R.string.theme_red, R.string.theme_blue, R.string.theme_yellow, R.string.theme_silver};

    private static int accent = PRESET_ACCENT[0];
    private static int accentDim = PRESET_DIM[0];
    private static int preset = 0;
    private static boolean loaded = false;

    /** Naik setiap kali warna aksen berubah; layar yang sudah terbuka membuat ulang dirinya. */
    public static int version = 0;

    private Palette() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(App.PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized void load(Context c) {
        SharedPreferences p = prefs(c);
        preset = p.getInt(KEY_PRESET, 0);
        if (preset == CUSTOM_INDEX) {
            int custom = p.getInt(KEY_CUSTOM, PRESET_ACCENT[0]);
            accent = custom | 0xFF000000;
            accentDim = deriveDim(accent);
        } else {
            if (preset < 0 || preset >= PRESET_ACCENT.length) preset = 0;
            accent = PRESET_ACCENT[preset];
            accentDim = PRESET_DIM[preset];
        }
        loaded = true;
    }

    public static boolean isDark(Context c) {
        return prefs(c).getBoolean(KEY_DARK, true);
    }

    /** Menerapkan mode gelap/terang ke seluruh aplikasi (layar dibuat ulang otomatis). */
    public static void setDark(Context c, boolean dark) {
        prefs(c).edit().putBoolean(KEY_DARK, dark).apply();
        AppCompatDelegate.setDefaultNightMode(dark ? AppCompatDelegate.MODE_NIGHT_YES
                : AppCompatDelegate.MODE_NIGHT_NO);
    }

    public static void applyNightMode(Context c) {
        AppCompatDelegate.setDefaultNightMode(isDark(c) ? AppCompatDelegate.MODE_NIGHT_YES
                : AppCompatDelegate.MODE_NIGHT_NO);
    }

    public static int getPreset(Context c) {
        ensure(c);
        return preset;
    }

    public static void setPreset(Context c, int index) {
        prefs(c).edit().putInt(KEY_PRESET, index).apply();
        load(c);
        version++;
    }

    public static void setCustom(Context c, int color) {
        prefs(c).edit().putInt(KEY_CUSTOM, color | 0xFF000000).putInt(KEY_PRESET, CUSTOM_INDEX).apply();
        load(c);
        version++;
    }

    public static int getCustom(Context c) {
        return prefs(c).getInt(KEY_CUSTOM, PRESET_ACCENT[0]) | 0xFF000000;
    }

    private static void ensure(Context c) {
        if (!loaded) load(c);
    }

    public static int accent(Context c) {
        ensure(c);
        return accent;
    }

    public static int accentDim(Context c) {
        ensure(c);
        return accentDim;
    }

    /** Warna teks/ikon di atas permukaan berwarna aksen (gelap bila aksen terang, mis. kuning/silver). */
    public static int onAccent(int background) {
        return ColorUtils.calculateLuminance(background) > 0.5 ? 0xFF1B1D28 : 0xFFFFFFFF;
    }

    /** Aksen yang kontrasnya enak dibaca untuk keyword/tag pada latar saat ini. */
    public static int accentForSyntax(Context c, boolean dark) {
        ensure(c);
        return dark ? ColorUtils.blendARGB(accent, 0xFFFFFFFF, 0.30f)
                : ColorUtils.blendARGB(accentDim, 0xFF000000, 0.20f);
    }

    public static int deriveDim(int color) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[1] = Math.min(1f, hsv[1] * 1.05f);
        hsv[2] = hsv[2] * 0.78f;
        return Color.HSVToColor(hsv);
    }
}
