package com.webviewlauncher.app.theme;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.core.graphics.ColorUtils;
import androidx.core.widget.CompoundButtonCompat;
import androidx.core.widget.ImageViewCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.webviewlauncher.app.R;

/**
 * Memasang warna aksen dinamis ke view yang diberi android:tag tertentu di XML.
 * Tag: bg_run, bg_info, bg_indicator, bg_find, bg_chip, bg_navline, fab, accent, on_accent,
 * outline, btn_filled. Panggil {@link #apply(View)} setelah inflate (activity, fragment, dialog,
 * item daftar).
 */
public final class ThemeApplier {

    private ThemeApplier() {
    }

    public static void apply(View v) {
        if (v == null) return;
        Object tag = v.getTag();
        if (tag instanceof String) {
            // Boleh beberapa tag sekaligus dipisah koma, mis. "accent,fit"
            for (String t : ((String) tag).split(",")) applyTag(v, t.trim());
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) apply(g.getChildAt(i));
        }
    }

    private static float dp(Context c, float v) {
        return v * c.getResources().getDisplayMetrics().density;
    }

    private static int col(Context c, int res) {
        return ContextCompat.getColor(c, res);
    }

    public static Drawable rippleFill(Context c, int fill, float radiusDp, boolean oval) {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(oval ? GradientDrawable.OVAL : GradientDrawable.RECTANGLE);
        shape.setColor(fill);
        if (!oval) shape.setCornerRadius(dp(c, radiusDp));
        int rip = ColorUtils.setAlphaComponent(Palette.onAccent(fill), 0x44);
        return new RippleDrawable(ColorStateList.valueOf(rip), shape, null);
    }

    private static void applyTag(View v, String tag) {
        Context c = v.getContext();
        int accent = Palette.accent(c);
        int dim = Palette.accentDim(c);
        int on = Palette.onAccent(dim);
        switch (tag) {
            case "bg_run":
                v.setBackground(rippleFill(c, dim, 26, false));
                fitText(v);
                break;
            case "fit":
                fitText(v);
                break;
            case "bg_info":
                v.setBackground(rippleFill(c, dim, 0, true));
                if (v instanceof ImageView)
                    ImageViewCompat.setImageTintList((ImageView) v, ColorStateList.valueOf(on));
                break;
            case "bg_indicator": {
                GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                        new int[]{dim, accent});
                g.setCornerRadius(dp(c, 3));
                v.setBackground(g);
                break;
            }
            case "bg_find": {
                GradientDrawable g = new GradientDrawable();
                g.setColor(col(c, R.color.bg_surface));
                g.setStroke((int) dp(c, 1), dim);
                g.setCornerRadius(dp(c, 14));
                v.setBackground(g);
                break;
            }
            case "bg_navline": {
                GradientDrawable g = new GradientDrawable();
                g.setColor(accent);
                g.setCornerRadius(dp(c, 3));
                v.setBackground(g);
                break;
            }
            case "bg_chip": {
                StateListDrawable sl = new StateListDrawable();
                GradientDrawable sel = new GradientDrawable();
                sel.setColor(ColorUtils.blendARGB(col(c, R.color.bg_card), accent, 0.22f));
                sel.setStroke((int) dp(c, 1), accent);
                sel.setCornerRadius(dp(c, 18));
                GradientDrawable norm = new GradientDrawable();
                norm.setColor(col(c, R.color.bg_card));
                norm.setStroke((int) dp(c, 1), col(c, R.color.divider));
                norm.setCornerRadius(dp(c, 18));
                sl.addState(new int[]{android.R.attr.state_selected}, sel);
                sl.addState(new int[]{}, new RippleDrawable(
                        ColorStateList.valueOf(col(c, R.color.ripple)), norm, null));
                v.setBackground(sl);
                break;
            }
            case "fab":
                if (v instanceof FloatingActionButton) {
                    FloatingActionButton f = (FloatingActionButton) v;
                    f.setBackgroundTintList(ColorStateList.valueOf(dim));
                    f.setImageTintList(ColorStateList.valueOf(on));
                }
                break;
            case "accent":
                tintAccent(v, accent);
                break;
            case "on_accent":
                if (v instanceof TextView) {
                    ((TextView) v).setTextColor(on);
                    fitText(v);
                }
                else if (v instanceof ImageView)
                    ImageViewCompat.setImageTintList((ImageView) v, ColorStateList.valueOf(on));
                break;
            case "outline":
                if (v instanceof MaterialButton) {
                    MaterialButton b = (MaterialButton) v;
                    b.setStrokeColor(ColorStateList.valueOf(dim));
                    b.setIconTint(ColorStateList.valueOf(accent));
                }
                break;
            case "btn_filled":
                if (v instanceof MaterialButton) {
                    MaterialButton b = (MaterialButton) v;
                    b.setBackgroundTintList(ColorStateList.valueOf(dim));
                    b.setTextColor(on);
                } else {
                    v.setBackgroundTintList(ColorStateList.valueOf(dim));
                    if (v instanceof TextView) ((TextView) v).setTextColor(on);
                }
                break;
            default:
                break;
        }
    }

    /**
     * Teks satu baris yang mengecil otomatis (sampai 9sp) bila ruangnya sempit, alih-alih terpotong
     * atau turun ke baris kedua. Dipakai untuk label tab, tombol, dan judul. Lihat docs/UI_GUIDELINES.md.
     * Syarat: lebar view harus terbatas (0dp berbobot atau match_parent), bukan wrap_content.
     */
    public static void fitText(View v) {
        if (!(v instanceof TextView)) return;
        TextView t = (TextView) v;
        t.setMaxLines(1);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        float sp = t.getTextSize() / t.getResources().getDisplayMetrics().scaledDensity;
        int max = Math.max(10, (int) Math.ceil(sp));
        androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                t, 9, max, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
    }

    private static void tintAccent(View v, int accent) {
        if (v instanceof CheckBox) {
            CompoundButtonCompat.setButtonTintList((CheckBox) v, ColorStateList.valueOf(accent));
        } else if (v instanceof ProgressBar) {
            ((ProgressBar) v).setIndeterminateTintList(ColorStateList.valueOf(accent));
        } else if (v instanceof TextView) {
            ((TextView) v).setTextColor(accent);
        } else if (v instanceof ImageView) {
            ImageViewCompat.setImageTintList((ImageView) v, ColorStateList.valueOf(accent));
        }
    }
}
