package com.webviewlauncher.app.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Perapi kode (formatter) untuk HTML, CSS, dan JavaScript. Dibuat konservatif: untuk JS,
 * kode yang sudah berbaris-baris hanya dirapikan indentasinya (tidak ada baris yang
 * digabung/dipecah) sehingga aman; pemecahan baris hanya dilakukan pada kode "minify".
 */
public final class CodeFormatter {

    private static final String IND = "  ";
    private static final Set<String> VOID_TAGS = new HashSet<>(Arrays.asList(
            "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta",
            "param", "source", "track", "wbr"));

    private CodeFormatter() {
    }

    public static String format(int lang, String src) {
        String s = src.replace("\r\n", "\n").replace('\r', '\n');
        switch (lang) {
            case SyntaxHighlighter.LANG_CSS:
                return css(s);
            case SyntaxHighlighter.LANG_JS:
                return js(s);
            case SyntaxHighlighter.LANG_HTML:
                return html(s);
            default:
                return s;
        }
    }

    private static String indent(int depth) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < depth; i++) sb.append(IND);
        return sb.toString();
    }

    private static void rtrimSpaces(StringBuilder sb) {
        int n = sb.length();
        while (n > 0 && (sb.charAt(n - 1) == ' ' || sb.charAt(n - 1) == '\t')) n--;
        sb.setLength(n);
    }

    // ------------------------------------------------------------------ CSS

    static String css(String s) {
        StringBuilder sb = new StringBuilder(s.length() + s.length() / 4);
        int depth = 0;
        int paren = 0;
        boolean pendingSpace = false;
        int n = s.length();
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (c == '/' && i + 1 < n && s.charAt(i + 1) == '*') {
                int end = s.indexOf("*/", i + 2);
                end = end < 0 ? n : end + 2;
                if (sb.length() > 0 && sb.charAt(sb.length() - 1) != '\n' && sb.charAt(sb.length() - 1) != ' ') sb.append(' ');
                sb.append(s, i, end);
                i = end - 1;
                pendingSpace = true;
                continue;
            }
            if (c == '"' || c == '\'') {
                if (pendingSpace) addSpace(sb);
                pendingSpace = false;
                int j = i + 1;
                while (j < n && s.charAt(j) != c) {
                    if (s.charAt(j) == '\\') j++;
                    j++;
                }
                j = Math.min(j + 1, n);
                sb.append(s, i, j);
                i = j - 1;
                continue;
            }
            if (Character.isWhitespace(c)) {
                pendingSpace = true;
                continue;
            }
            switch (c) {
                case '{':
                    rtrimSpaces(sb);
                    if (sb.length() > 0 && sb.charAt(sb.length() - 1) != '\n') sb.append(' ');
                    sb.append('{');
                    depth++;
                    newline(sb, depth);
                    pendingSpace = false;
                    break;
                case '}':
                    depth = Math.max(0, depth - 1);
                    newline(sb, depth);
                    sb.append('}');
                    newline(sb, depth);
                    if (depth == 0) {
                        rtrimSpaces(sb);
                        sb.append('\n');
                    }
                    pendingSpace = false;
                    break;
                case ';':
                    sb.append(';');
                    if (paren == 0) newline(sb, depth);
                    pendingSpace = false;
                    break;
                case '(':
                    if (pendingSpace) addSpace(sb);
                    pendingSpace = false;
                    paren++;
                    sb.append(c);
                    break;
                case ')':
                    paren = Math.max(0, paren - 1);
                    sb.append(c);
                    pendingSpace = false;
                    break;
                case ',':
                    sb.append(',');
                    pendingSpace = true;
                    break;
                default:
                    if (pendingSpace) addSpace(sb);
                    pendingSpace = false;
                    sb.append(c);
            }
        }
        return finish(sb);
    }

    private static void addSpace(StringBuilder sb) {
        if (sb.length() == 0) return;
        char l = sb.charAt(sb.length() - 1);
        if (l != ' ' && l != '\n' && l != '(') sb.append(' ');
    }

    private static void newline(StringBuilder sb, int depth) {
        rtrimSpaces(sb);
        if (sb.length() > 0 && sb.charAt(sb.length() - 1) != '\n') sb.append('\n');
        sb.append(indent(depth));
    }

    private static String finish(StringBuilder sb) {
        String out = sb.toString();
        out = out.replaceAll("[ \\t]+\\n", "\n").replaceAll("\\n{3,}", "\n\n");
        return out.trim() + "\n";
    }

    // ------------------------------------------------------------------ JS

    static String js(String s) {
        boolean minified = false;
        for (String line : s.split("\n", -1)) {
            if (line.length() > 300) {
                minified = true;
                break;
            }
        }
        return jsReindent(minified ? jsSplit(s) : s);
    }

    private static boolean regexAllowedAfter(StringBuilder out) {
        int i = out.length() - 1;
        while (i >= 0 && Character.isWhitespace(out.charAt(i))) i--;
        if (i < 0) return true;
        char c = out.charAt(i);
        if ("(,=:[!&|?{};+-*%<>~^".indexOf(c) >= 0) return true;
        int end = i + 1;
        while (i >= 0 && Character.isLetter(out.charAt(i))) i--;
        String w = out.substring(i + 1, end);
        return w.equals("return") || w.equals("typeof") || w.equals("case") || w.equals("in")
                || w.equals("of") || w.equals("delete") || w.equals("void");
    }

    /** Memecah kode minify menjadi banyak baris (aman terhadap string, template, komentar, regex). */
    private static String jsSplit(String s) {
        StringBuilder out = new StringBuilder(s.length() + s.length() / 5);
        int n = s.length();
        int paren = 0;
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            char nx = i + 1 < n ? s.charAt(i + 1) : '\0';
            if (c == '/' && nx == '/') {
                int e = s.indexOf('\n', i);
                e = e < 0 ? n : e;
                out.append(s, i, e);
                i = e - 1;
                continue;
            }
            if (c == '/' && nx == '*') {
                int e = s.indexOf("*/", i + 2);
                e = e < 0 ? n : e + 2;
                out.append(s, i, e);
                i = e - 1;
                continue;
            }
            if (c == '"' || c == '\'' || c == '`') {
                int j = i + 1;
                while (j < n && s.charAt(j) != c) {
                    if (s.charAt(j) == '\\') j++;
                    j++;
                }
                j = Math.min(j + 1, n);
                out.append(s, i, j);
                i = j - 1;
                continue;
            }
            if (c == '/' && regexAllowedAfter(out)) {
                int j = i + 1;
                boolean cls = false;
                while (j < n && s.charAt(j) != '\n') {
                    char d = s.charAt(j);
                    if (d == '\\') {
                        j += 2;
                        continue;
                    }
                    if (d == '[') cls = true;
                    else if (d == ']') cls = false;
                    else if (d == '/' && !cls) break;
                    j++;
                }
                j = Math.min(j + 1, n);
                while (j < n && Character.isLetter(s.charAt(j))) j++;
                out.append(s, i, j);
                i = j - 1;
                continue;
            }
            if (c == '(') paren++;
            if (c == ')') paren = Math.max(0, paren - 1);

            if (c == '{') {
                out.append('{');
                if (nextNonSpace(s, i + 1) != '}') out.append('\n');
            } else if (c == '}') {
                int len = out.length();
                int k = len - 1;
                while (k >= 0 && out.charAt(k) == ' ') k--;
                if (k >= 0 && out.charAt(k) != '{' && out.charAt(k) != '\n') out.append('\n');
                out.append('}');
                int p = i + 1;
                while (p < n && s.charAt(p) == ' ') p++;
                String rest = s.substring(p, Math.min(n, p + 8));
                char r = p < n ? s.charAt(p) : '\0';
                boolean stay = r == ',' || r == ';' || r == ')' || r == '.' || r == ']' || r == '\n' || r == '\0'
                        || rest.startsWith("else") || rest.startsWith("catch") || rest.startsWith("finally");
                if (!stay) out.append('\n');
            } else if (c == ';' && paren == 0) {
                out.append(';');
                if (nextNonSpace(s, i + 1) != '\n') out.append('\n');
            } else {
                out.append(c);
            }
        }
        return out.toString();
    }

    private static char nextNonSpace(String s, int from) {
        int i = from;
        while (i < s.length() && (s.charAt(i) == ' ' || s.charAt(i) == '\t')) i++;
        return i < s.length() ? s.charAt(i) : '\0';
    }

    /** Merapikan indentasi per baris berdasarkan kedalaman {}, (), []. Tidak menggabung/memecah baris. */
    private static String jsReindent(String s) {
        String[] lines = s.split("\n", -1);
        StringBuilder out = new StringBuilder(s.length() + 256);
        int depth = 0;
        boolean inBlockComment = false;
        boolean inTemplate = false;
        int blank = 0;
        for (String raw : lines) {
            boolean startsInside = inBlockComment || inTemplate;
            String line = startsInside ? raw : raw.trim();
            if (!startsInside) {
                if (line.isEmpty()) {
                    blank++;
                    if (blank <= 1) out.append('\n');
                    continue;
                }
                blank = 0;
                int lead = 0;
                while (lead < line.length() && "})]".indexOf(line.charAt(lead)) >= 0) lead++;
                out.append(indent(Math.max(0, depth - lead))).append(line).append('\n');
            } else {
                blank = 0;
                out.append(rtrim(line)).append('\n');
            }
            // hitung perubahan kedalaman, abaikan string/komentar
            char quote = 0;
            for (int i = 0; i < line.length(); i++) {
                char c = line.charAt(i);
                char nx = i + 1 < line.length() ? line.charAt(i + 1) : '\0';
                if (inBlockComment) {
                    if (c == '*' && nx == '/') {
                        inBlockComment = false;
                        i++;
                    }
                    continue;
                }
                if (inTemplate) {
                    if (c == '\\') i++;
                    else if (c == '`') inTemplate = false;
                    continue;
                }
                if (quote != 0) {
                    if (c == '\\') i++;
                    else if (c == quote) quote = 0;
                    continue;
                }
                if (c == '/' && nx == '/') break;
                if (c == '/' && nx == '*') {
                    inBlockComment = true;
                    i++;
                    continue;
                }
                if (c == '"' || c == '\'') {
                    quote = c;
                    continue;
                }
                if (c == '`') {
                    inTemplate = true;
                    continue;
                }
                if (c == '{' || c == '(' || c == '[') depth++;
                else if (c == '}' || c == ')' || c == ']') depth = Math.max(0, depth - 1);
            }
        }
        String r = out.toString();
        return r.replaceAll("\\n{3,}", "\n\n").trim() + "\n";
    }

    private static String rtrim(String s) {
        int n = s.length();
        while (n > 0 && Character.isWhitespace(s.charAt(n - 1))) n--;
        return s.substring(0, n);
    }

    // ------------------------------------------------------------------ HTML

    private static final class Tok {
        static final int TEXT = 0, OPEN = 1, CLOSE = 2, SELF = 3, COMMENT = 4, DOCTYPE = 5, RAW = 6;
        int type;
        String text;
        String name = "";
        String rawBody;      // isi script/style/pre
        String rawClose;     // tag penutup untuk RAW
        boolean formatBody;  // true bila isi dirapikan (script/style)
        int bodyLang;
    }

    static String html(String s) {
        List<Tok> toks = tokenizeHtml(s);
        StringBuilder out = new StringBuilder(s.length() + s.length() / 4);
        int depth = 0;
        for (int i = 0; i < toks.size(); i++) {
            Tok t = toks.get(i);
            switch (t.type) {
                case Tok.DOCTYPE:
                case Tok.COMMENT:
                case Tok.SELF:
                    line(out, depth, t.text);
                    break;
                case Tok.TEXT:
                    line(out, depth, t.text);
                    break;
                case Tok.RAW: {
                    if (t.formatBody) {
                        String body = format(t.bodyLang, t.rawBody).trim();
                        if (body.isEmpty()) {
                            line(out, depth, t.text + t.rawClose);
                        } else {
                            line(out, depth, t.text);
                            for (String l : body.split("\n", -1)) {
                                if (l.isEmpty()) out.append('\n');
                                else out.append(indent(depth + 1)).append(l).append('\n');
                            }
                            line(out, depth, t.rawClose);
                        }
                    } else {
                        line(out, depth, t.text + t.rawBody + t.rawClose);
                    }
                    break;
                }
                case Tok.OPEN: {
                    boolean isVoid = VOID_TAGS.contains(t.name);
                    // <p>teks</p> dan <div></div> tetap satu baris
                    if (!isVoid && i + 2 < toks.size() && toks.get(i + 1).type == Tok.TEXT
                            && toks.get(i + 2).type == Tok.CLOSE && toks.get(i + 2).name.equals(t.name)) {
                        line(out, depth, t.text + toks.get(i + 1).text + toks.get(i + 2).text);
                        i += 2;
                    } else if (!isVoid && i + 1 < toks.size() && toks.get(i + 1).type == Tok.CLOSE
                            && toks.get(i + 1).name.equals(t.name)) {
                        line(out, depth, t.text + toks.get(i + 1).text);
                        i += 1;
                    } else {
                        line(out, depth, t.text);
                        if (!isVoid) depth++;
                    }
                    break;
                }
                case Tok.CLOSE:
                    depth = Math.max(0, depth - 1);
                    line(out, depth, t.text);
                    break;
                default:
                    break;
            }
        }
        return out.toString().replaceAll("\\n{3,}", "\n\n").trim() + "\n";
    }

    private static void line(StringBuilder out, int depth, String text) {
        out.append(indent(depth)).append(text).append('\n');
    }

    private static List<Tok> tokenizeHtml(String s) {
        List<Tok> list = new ArrayList<>();
        String lower = s.toLowerCase(Locale.ROOT).length() == s.length() ? s.toLowerCase(Locale.ROOT) : s;
        int n = s.length();
        int i = 0;
        while (i < n) {
            char c = s.charAt(i);
            if (c != '<') {
                int j = s.indexOf('<', i);
                if (j < 0) j = n;
                String txt = s.substring(i, j).trim().replaceAll("\\s+", " ");
                if (!txt.isEmpty()) {
                    Tok t = new Tok();
                    t.type = Tok.TEXT;
                    t.text = txt;
                    list.add(t);
                }
                i = j;
                continue;
            }
            if (s.startsWith("<!--", i)) {
                int e = s.indexOf("-->", i + 4);
                e = e < 0 ? n : e + 3;
                Tok t = new Tok();
                t.type = Tok.COMMENT;
                t.text = s.substring(i, e);
                list.add(t);
                i = e;
                continue;
            }
            if (i + 1 < n && (s.charAt(i + 1) == '!' || s.charAt(i + 1) == '?')) {
                int e = s.indexOf('>', i);
                e = e < 0 ? n : e + 1;
                Tok t = new Tok();
                t.type = Tok.DOCTYPE;
                t.text = s.substring(i, e);
                list.add(t);
                i = e;
                continue;
            }
            // tag biasa: cari '>' dengan memperhatikan tanda kutip
            int j = i + 1;
            char q = 0;
            while (j < n) {
                char d = s.charAt(j);
                if (q != 0) {
                    if (d == q) q = 0;
                } else if (d == '"' || d == '\'') {
                    q = d;
                } else if (d == '>') {
                    break;
                }
                j++;
            }
            int end = Math.min(j + 1, n);
            String tag = s.substring(i, end).replaceAll("\\s+", " ");
            tag = tag.replaceAll(" +>$", ">").replaceAll(" +/>$", " />");
            boolean closing = tag.startsWith("</");
            int k = closing ? 2 : 1;
            int m = k;
            while (m < tag.length() && (Character.isLetterOrDigit(tag.charAt(m)) || tag.charAt(m) == '-'
                    || tag.charAt(m) == ':' || tag.charAt(m) == '_')) m++;
            String name = tag.substring(k, m).toLowerCase(Locale.ROOT);
            Tok t = new Tok();
            t.text = tag;
            t.name = name;
            if (closing) {
                t.type = Tok.CLOSE;
            } else if (tag.endsWith("/>")) {
                t.type = Tok.SELF;
            } else if (name.equals("script") || name.equals("style") || name.equals("pre") || name.equals("textarea")) {
                int ce = lower.indexOf("</" + name, end);
                if (ce < 0) ce = n;
                int cg = s.indexOf('>', ce);
                cg = cg < 0 ? n : cg + 1;
                t.type = Tok.RAW;
                t.rawBody = s.substring(end, ce);
                t.rawClose = ce >= n ? "" : "</" + name + ">";
                String lt = tag.toLowerCase(Locale.ROOT);
                if (name.equals("style")) {
                    t.formatBody = true;
                    t.bodyLang = SyntaxHighlighter.LANG_CSS;
                } else if (name.equals("script")) {
                    boolean plainJs = !lt.contains("type=") || lt.contains("javascript") || lt.contains("module");
                    t.formatBody = plainJs;
                    t.bodyLang = SyntaxHighlighter.LANG_JS;
                }
                list.add(t);
                i = cg;
                continue;
            } else {
                t.type = Tok.OPEN;
            }
            list.add(t);
            i = end;
        }
        return list;
    }
}
