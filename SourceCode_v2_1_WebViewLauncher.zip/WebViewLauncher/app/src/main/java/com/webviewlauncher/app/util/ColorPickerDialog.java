package com.webviewlauncher.app.util;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

import com.webviewlauncher.app.R;
import com.webviewlauncher.app.theme.ThemeApplier;
import com.webviewlauncher.app.widget.BrightnessSlider;
import com.webviewlauncher.app.widget.ColorWheelView;

import java.util.Locale;

/**
 * Pemilih warna kustom: roda warna (hue + saturasi), penggeser kecerahan, kolom RGB (0–255),
 * dan kolom hex #RRGGBB. Semua saling tersinkron.
 */
public final class ColorPickerDialog {

    public interface OnColor {
        void onColor(int argb);
    }

    private final float[] hsv = new float[3];
    private boolean updating = false;
    private ColorWheelView wheel;
    private BrightnessSlider slider;
    private View preview;
    private EditText hex, rField, gField, bField;

    private ColorPickerDialog() {
    }

    public static void show(Context ctx, int initial, OnColor cb) {
        new ColorPickerDialog().build(ctx, initial, cb);
    }

    private void build(Context ctx, int initial, OnColor cb) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.dialog_color_picker, null);
        ThemeApplier.apply(view);
        wheel = view.findViewById(R.id.colorWheel);
        slider = view.findViewById(R.id.brightness);
        preview = view.findViewById(R.id.preview);
        hex = view.findViewById(R.id.hexField);
        rField = view.findViewById(R.id.rField);
        gField = view.findViewById(R.id.gField);
        bField = view.findViewById(R.id.bField);

        Color.colorToHSV(initial, hsv);
        refresh(null);

        wheel.setListener((h, s) -> {
            hsv[0] = h;
            hsv[1] = s;
            refresh(wheel);
        });
        slider.setListener(v -> {
            hsv[2] = v;
            refresh(slider);
        });
        hex.addTextChangedListener(new SimpleWatcher(() -> {
            if (updating) return;
            String t = hex.getText().toString().trim();
            if (t.startsWith("#")) t = t.substring(1);
            if (t.length() != 6) return;
            try {
                setRgb(Color.parseColor("#" + t), hex);
            } catch (IllegalArgumentException ignored) {
            }
        }));
        TextWatcher rgbWatcher = new SimpleWatcher(() -> {
            if (updating) return;
            int r = parse(rField), g = parse(gField), b = parse(bField);
            if (r < 0 || g < 0 || b < 0) return;
            setRgb(Color.rgb(r, g, b), null);
        });
        rField.addTextChangedListener(rgbWatcher);
        gField.addTextChangedListener(rgbWatcher);
        bField.addTextChangedListener(rgbWatcher);

        Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(view);
        view.findViewById(R.id.pickCancel).setOnClickListener(v -> dialog.dismiss());
        view.findViewById(R.id.pickApply).setOnClickListener(v -> {
            dialog.dismiss();
            if (cb != null) cb.onColor(Color.HSVToColor(hsv) | 0xFF000000);
        });
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(com.webviewlauncher.app.util.DialogUtils.dialogWidth(ctx),
                    WindowManager.LayoutParams.WRAP_CONTENT);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
    }

    private int parse(EditText e) {
        try {
            int v = Integer.parseInt(e.getText().toString().trim());
            return Math.max(0, Math.min(255, v));
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    private void setRgb(int color, View source) {
        float oldHue = hsv[0];
        Color.colorToHSV(color, hsv);
        if (hsv[1] == 0f || hsv[2] == 0f) hsv[0] = oldHue;   // abu-abu/hitam: pertahankan hue
        refresh(source);
    }

    /** Memperbarui semua kontrol kecuali sumber perubahan. */
    private void refresh(View source) {
        updating = true;
        int color = Color.HSVToColor(hsv);
        if (source != wheel) wheel.setHs(hsv[0], hsv[1]);
        wheel.setValue(hsv[2]);
        slider.setColor(hsv[0], hsv[1], hsv[2]);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        g.setStroke(3, 0x55888888);
        preview.setBackground(g);
        if (source != hex) hex.setText(String.format(Locale.US, "#%06X", color & 0xFFFFFF));
        if (source != rField && source != gField && source != bField) {
            rField.setText(String.valueOf(Color.red(color)));
            gField.setText(String.valueOf(Color.green(color)));
            bField.setText(String.valueOf(Color.blue(color)));
        }
        updating = false;
    }

    private static final class SimpleWatcher implements TextWatcher {
        private final Runnable r;

        SimpleWatcher(Runnable r) {
            this.r = r;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int a, int b, int c) {
        }

        @Override
        public void onTextChanged(CharSequence s, int a, int b, int c) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            r.run();
        }
    }
}
