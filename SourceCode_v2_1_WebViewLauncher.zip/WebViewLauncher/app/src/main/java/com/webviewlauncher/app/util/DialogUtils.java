package com.webviewlauncher.app.util;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import com.webviewlauncher.app.R;
import com.webviewlauncher.app.theme.ThemeApplier;

/** Dialog konfirmasi bergaya WebView Launcher (sama dengan dialog tindakan/info). */
public final class DialogUtils {

    public interface OnText {
        void run(String text);
    }

    private DialogUtils() {
    }

    /** Lebar dialog: 90% layar di HP, tetapi tidak lebih dari 420dp di layar lebar/tablet. */
    public static int dialogWidth(Context ctx) {
        float density = ctx.getResources().getDisplayMetrics().density;
        int screen = ctx.getResources().getDisplayMetrics().widthPixels;
        return (int) Math.min(screen * 0.90f, 420f * density);
    }

    /** Dialog dengan dua pilihan tindakan (pilihan kedua berwarna bahaya) + Batal. */
    public static void choice(Context ctx, String title, String message, String firstLabel,
                              Runnable onFirst, String secondLabel, Runnable onSecond) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.dialog_choice, null);
        ThemeApplier.apply(view);
        ((TextView) view.findViewById(R.id.choiceTitle)).setText(title);
        ((TextView) view.findViewById(R.id.choiceMessage)).setText(message);
        TextView first = view.findViewById(R.id.choiceFirst);
        TextView second = view.findViewById(R.id.choiceSecond);
        first.setText(firstLabel);
        second.setText(secondLabel);

        Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(view);
        view.findViewById(R.id.choiceCancel).setOnClickListener(v -> dialog.dismiss());
        first.setOnClickListener(v -> {
            dialog.dismiss();
            if (onFirst != null) onFirst.run();
        });
        second.setOnClickListener(v -> {
            dialog.dismiss();
            if (onSecond != null) onSecond.run();
        });
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setLayout(dialogWidth(ctx),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    /** Dialog isian satu baris (angka) bergaya WebView Launcher. */
    public static void promptNumber(Context ctx, String title, String hint, String positiveLabel, OnText onOk) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.dialog_input, null);
        ThemeApplier.apply(view);
        ((TextView) view.findViewById(R.id.inputTitle)).setText(title);
        final android.widget.EditText field = view.findViewById(R.id.inputField);
        field.setHint(hint);
        TextView positive = view.findViewById(R.id.inputPositive);
        positive.setText(positiveLabel);

        Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(view);
        view.findViewById(R.id.inputNegative).setOnClickListener(v -> dialog.dismiss());
        positive.setOnClickListener(v -> {
            String text = field.getText().toString().trim();
            dialog.dismiss();
            if (onOk != null) onOk.run(text);
        });

        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setLayout(dialogWidth(ctx),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        }
        field.requestFocus();
    }

    public static void confirm(Context ctx, String title, String message, String positiveLabel,
                               Runnable onPositive) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.dialog_confirm, null);
        ThemeApplier.apply(view);
        ((TextView) view.findViewById(R.id.confirmTitle)).setText(title);
        ((TextView) view.findViewById(R.id.confirmMessage)).setText(message);
        TextView positive = view.findViewById(R.id.confirmPositive);
        positive.setText(positiveLabel);

        Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(view);
        view.findViewById(R.id.confirmNegative).setOnClickListener(v -> dialog.dismiss());
        positive.setOnClickListener(v -> {
            dialog.dismiss();
            if (onPositive != null) onPositive.run();
        });

        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width = dialogWidth(ctx);
            window.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }
}
