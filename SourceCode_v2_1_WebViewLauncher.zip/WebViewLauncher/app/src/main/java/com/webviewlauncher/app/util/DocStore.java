package com.webviewlauncher.app.util;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;
import android.provider.OpenableColumns;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Akses ke folder yang diizinkan pengguna (Storage Access Framework / ACTION_OPEN_DOCUMENT_TREE).
 * Semua fungsi di sini BLOKIR (baca/tulis disk): panggil dari thread latar, bukan thread utama.
 *
 * Satu berkas/folder dikenali lewat "document id" (docId) di dalam pohon (tree) yang dipilih.
 */
public final class DocStore {

    /** Satu berkas atau folder. */
    public static final class Node {
        public final String docId;
        public final String parentId;
        public final String name;
        public final boolean dir;
        public final long size;
        public final long modified;
        /** Path relatif terhadap folder awal pemindaian ("a/b/file.js"). */
        public String rel;

        Node(String docId, String parentId, String name, boolean dir, long size, long modified) {
            this.docId = docId;
            this.parentId = parentId;
            this.name = name;
            this.dir = dir;
            this.size = size;
            this.modified = modified;
            this.rel = name;
        }
    }

    /** Hasil pemindaian satu folder: isi langsung + 3 berkas teks yang paling baru diubah (rekursif). */
    public static final class Scan {
        public List<Node> children = new ArrayList<>();
        public List<Node> recents = new ArrayList<>();
    }

    private static final String[] COLS = {
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED};

    private static final int SCAN_MAX_NODES = 3000;
    private static final long SCAN_MAX_MS = 2500;
    /** Berkas lebih besar dari ini tidak disalin ke salinan kerja saat Jalankan (mis. video besar). */
    private static final long MIRROR_MAX_FILE = 150L << 20;

    private final ContentResolver cr;
    private final Uri tree;

    public DocStore(Context ctx, Uri treeUri) {
        this.cr = ctx.getApplicationContext().getContentResolver();
        this.tree = treeUri;
    }

    public Uri treeUri() {
        return tree;
    }

    public String rootId() {
        return DocumentsContract.getTreeDocumentId(tree);
    }

    public Uri docUri(String docId) {
        return DocumentsContract.buildDocumentUriUsingTree(tree, docId);
    }

    public String rootName() {
        String n = displayName(docUri(rootId()));
        return n == null || n.isEmpty() ? "Folder" : n;
    }

    /** true bila folder masih bisa dibaca (izin belum dicabut / folder belum dihapus). */
    public boolean isAccessible() {
        try (Cursor c = cr.query(docUri(rootId()), new String[]{Document.COLUMN_DOCUMENT_ID}, null, null, null)) {
            return c != null && c.moveToFirst();
        } catch (Exception e) {
            return false;
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = cr.query(uri, new String[]{Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
        }
        return null;
    }

    // ------------------------------------------------------------------ daftar & pemindaian

    /** Isi langsung sebuah folder: folder dulu, lalu berkas, masing-masing urut nama. */
    public List<Node> list(String parentId) {
        List<Node> out = new ArrayList<>();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        try (Cursor c = cr.query(children, COLS, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    String name = c.getString(1);
                    if (id == null || name == null) continue;
                    String mime = c.getString(2);
                    long size = c.isNull(3) ? -1 : c.getLong(3);
                    long mod = c.isNull(4) ? 0 : c.getLong(4);
                    out.add(new Node(id, parentId, name, Document.MIME_TYPE_DIR.equals(mime), size, mod));
                }
            }
        }
        Collections.sort(out, new Comparator<Node>() {
            @Override
            public int compare(Node a, Node b) {
                if (a.dir != b.dir) return a.dir ? -1 : 1;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        return out;
    }

    /**
     * Memindai folder: isi langsungnya + 3 berkas teks terbaru di seluruh bawah-pohonnya (lebar dulu,
     * dibatasi jumlah dan waktu supaya tetap cepat di pohon yang sangat besar).
     */
    public Scan scan(String folderId) {
        Scan s = new Scan();
        s.children = list(folderId);
        List<Node> files = new ArrayList<>();
        ArrayDeque<String[]> queue = new ArrayDeque<>();
        long deadline = System.currentTimeMillis() + SCAN_MAX_MS;
        int visited = s.children.size();
        for (Node n : s.children) {
            if (n.dir) queue.add(new String[]{n.docId, n.name});
            else if (FileKind.isEditable(n.name)) files.add(n);
        }
        while (!queue.isEmpty() && visited < SCAN_MAX_NODES && System.currentTimeMillis() < deadline) {
            String[] d = queue.poll();
            List<Node> kids;
            try {
                kids = list(d[0]);
            } catch (Exception e) {
                continue;
            }
            for (Node n : kids) {
                visited++;
                if (n.dir) {
                    queue.add(new String[]{n.docId, d[1] + "/" + n.name});
                } else if (FileKind.isEditable(n.name)) {
                    n.rel = d[1] + "/" + n.name;
                    files.add(n);
                }
            }
        }
        Collections.sort(files, new Comparator<Node>() {
            @Override
            public int compare(Node a, Node b) {
                return Long.compare(b.modified, a.modified);
            }
        });
        for (int i = 0; i < files.size() && i < 3; i++) s.recents.add(files.get(i));
        return s;
    }

    public boolean exists(String parentId, String name) {
        for (Node n : list(parentId)) {
            if (n.name.equals(name)) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ buat / ubah / hapus

    /** Membuat berkas kosong. Akhiran bebas apa pun (html, py, txt, atau tanpa akhiran). */
    public Node createFile(String parentId, String name) throws IOException {
        String mime = FileKind.mimeFor(FileKind.ext(name));
        Uri u = DocumentsContract.createDocument(cr, docUri(parentId), mime, name);
        if (u == null) throw new IOException("create failed");
        String actual = displayName(u);
        // Beberapa penyedia menambah akhiran bila MIME tidak cocok: kembalikan ke nama yang diminta.
        if (actual != null && !actual.equals(name)) {
            try {
                Uri r = DocumentsContract.renameDocument(cr, u, name);
                if (r != null) u = r;
            } catch (Exception ignored) {
            }
        }
        return new Node(DocumentsContract.getDocumentId(u), parentId, name, false, 0, System.currentTimeMillis());
    }

    public Node createDir(String parentId, String name) throws IOException {
        Uri u = DocumentsContract.createDocument(cr, docUri(parentId), Document.MIME_TYPE_DIR, name);
        if (u == null) throw new IOException("mkdir failed");
        return new Node(DocumentsContract.getDocumentId(u), parentId, name, true, 0, System.currentTimeMillis());
    }

    public boolean rename(String docId, String newName) {
        try {
            return DocumentsContract.renameDocument(cr, docUri(docId), newName) != null;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean delete(String docId) {
        try {
            return DocumentsContract.deleteDocument(cr, docUri(docId));
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ baca / tulis

    public byte[] readBytes(String docId, long maxBytes) throws IOException {
        try (InputStream in = cr.openInputStream(docUri(docId))) {
            if (in == null) throw new IOException("cannot open");
            ByteArrayOutputStream out = new ByteArrayOutputStream(8192);
            byte[] buf = new byte[16384];
            int n;
            long total = 0;
            while ((n = in.read(buf)) != -1) {
                total += n;
                if (total > maxBytes) throw new TooBigException();
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }

    public static final class TooBigException extends IOException {
        public TooBigException() {
            super("too big");
        }
    }

    public void writeText(String docId, String text, Charset cs) throws IOException {
        byte[] data = text.getBytes(cs);
        OutputStream out;
        try {
            out = cr.openOutputStream(docUri(docId), "wt");
        } catch (Exception e) {
            out = cr.openOutputStream(docUri(docId), "rwt");
        }
        if (out == null) throw new IOException("cannot write");
        try {
            out.write(data);
            out.flush();
        } finally {
            out.close();
        }
    }

    // ------------------------------------------------------------------ impor

    /** Nama unik di sebuah folder: "a.png" -> "a (1).png" bila sudah ada. */
    public String uniqueName(String parentId, String wanted) {
        Set<String> names = new HashSet<>();
        for (Node n : list(parentId)) names.add(n.name);
        if (!names.contains(wanted)) return wanted;
        int dot = wanted.lastIndexOf('.');
        String base = dot > 0 ? wanted.substring(0, dot) : wanted;
        String ext = dot > 0 ? wanted.substring(dot) : "";
        for (int i = 1; i < 10000; i++) {
            String cand = base + " (" + i + ")" + ext;
            if (!names.contains(cand)) return cand;
        }
        return wanted;
    }

    /** Menyalin isi sebuah Uri (berkas pilihan pengguna) menjadi berkas baru DI DALAM folder tujuan. */
    public void importUri(String parentId, Uri src, String wantedName) throws IOException {
        String name = uniqueName(parentId, wantedName);
        Node n = createFile(parentId, name);
        try (InputStream in = cr.openInputStream(src);
             OutputStream out = cr.openOutputStream(docUri(n.docId), "wt")) {
            if (in == null || out == null) throw new IOException("cannot copy");
            byte[] buf = new byte[65536];
            int len;
            while ((len = in.read(buf)) != -1) out.write(buf, 0, len);
        } catch (IOException e) {
            delete(n.docId);
            throw e;
        }
    }

    /** Nama tampilan sebuah Uri hasil pemilih berkas. */
    public String nameOfUri(Uri uri) {
        try (Cursor c = cr.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getString(0);
        } catch (Exception ignored) {
        }
        String last = uri.getLastPathSegment();
        return last == null ? "file" : last.substring(last.lastIndexOf('/') + 1);
    }

    // ------------------------------------------------------------------ ekspor .zip

    /** Menulis seluruh isi folder (berkas, aset, subfolder) ke aliran .zip. @return jumlah berkas. */
    public int writeZip(String folderId, OutputStream os) throws IOException {
        ZipOutputStream z = new ZipOutputStream(new java.io.BufferedOutputStream(os, 65536));
        int[] count = {0};
        zipDir(folderId, "", z, new byte[65536], count);
        z.finish();
        z.flush();
        return count[0];
    }

    private void zipDir(String id, String prefix, ZipOutputStream z, byte[] buf, int[] count) throws IOException {
        List<Node> kids = list(id);
        if (kids.isEmpty() && !prefix.isEmpty()) {
            z.putNextEntry(new ZipEntry(prefix));      // folder kosong tetap ikut
            z.closeEntry();
            return;
        }
        for (Node n : kids) {
            if (n.dir) {
                zipDir(n.docId, prefix + n.name + "/", z, buf, count);
            } else {
                ZipEntry e = new ZipEntry(prefix + n.name);
                if (n.modified > 0) e.setTime(n.modified);
                z.putNextEntry(e);
                try (InputStream in = cr.openInputStream(docUri(n.docId))) {
                    if (in != null) {
                        int len;
                        while ((len = in.read(buf)) != -1) z.write(buf, 0, len);
                    }
                }
                z.closeEntry();
                count[0]++;
            }
        }
    }

    // ------------------------------------------------------------------ salinan kerja untuk Jalankan

    /**
     * Menyamakan isi sebuah folder ke folder lokal aplikasi (bertahap: berkas yang sama ukuran dan
     * waktunya dilewati), supaya WebView bisa memuat HTML beserta CSS/JS/gambar relatifnya.
     */
    public void mirror(String folderId, File dest) throws IOException {
        if (!dest.isDirectory() && !dest.mkdirs()) throw new IOException("mkdir " + dest);
        Set<String> keep = new HashSet<>();
        for (Node n : list(folderId)) {
            keep.add(n.name);
            File t = new File(dest, n.name);
            if (n.dir) {
                if (t.isFile()) t.delete();
                mirror(n.docId, t);
                continue;
            }
            if (t.isDirectory()) FileUtils.deleteRecursive(t);
            if (n.size > MIRROR_MAX_FILE) continue;
            if (t.isFile() && t.length() == n.size && n.modified > 0
                    && Math.abs(t.lastModified() - n.modified) < 2000) {
                continue;
            }
            try (InputStream in = cr.openInputStream(docUri(n.docId));
                 FileOutputStream out = new FileOutputStream(t)) {
                if (in == null) continue;
                byte[] buf = new byte[65536];
                int len;
                while ((len = in.read(buf)) != -1) out.write(buf, 0, len);
            }
            if (n.modified > 0) t.setLastModified(n.modified);
        }
        String[] existing = dest.list();
        if (existing != null) {
            for (String e : existing) {
                if (!keep.contains(e)) FileUtils.deleteRecursive(new File(dest, e));
            }
        }
    }

    /** Nama yang aman dipakai sebagai nama berkas .zip. */
    public static String safeFileName(String s) {
        String r = s == null ? "" : s.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return r.isEmpty() ? "folder" : r.toLowerCase(Locale.ROOT).equals("null") ? "folder" : r;
    }
}
