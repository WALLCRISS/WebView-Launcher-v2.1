package com.webviewlauncher.app.util;

import android.content.Context;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Menyusun kode dari menu Flash (satu HTML + satu CSS + satu JS) menjadi proyek sementara
 * di filesDir/flash/run. HTML, CSS, dan JS ditulis sebagai tiga berkas terpisah
 * (index.html, style.css, script.js) dan dihubungkan lewat tag link/script, jadi berapa pun
 * panjang kodenya tidak ada string raksasa yang perlu dibungkus atau di-escape.
 */
public final class EditorBuilder {

    private EditorBuilder() {
    }

    /** @return berkas index.html hasil susunan; foldernya adalah akar proyek. */
    public static File build(Context context, String html, String css, String js) throws IOException {
        File root = new File(context.getFilesDir(), "flash/run");
        FileUtils.deleteRecursive(root);
        if (!root.mkdirs() && !root.isDirectory()) throw new IOException("mkdir failed");

        boolean hasCss = !isBlank(css);
        boolean hasJs = !isBlank(js);
        if (hasCss) write(new File(root, "style.css"), css);
        if (hasJs) write(new File(root, "script.js"), js);

        File index = new File(root, "index.html");
        write(index, assemble(html == null ? "" : html, hasCss, hasJs));
        return index;
    }

    private static String assemble(String html, boolean hasCss, boolean hasJs) {
        final String cssTag = hasCss ? "<link rel=\"stylesheet\" href=\"style.css\">\n" : "";
        final String jsTag = hasJs ? "<script src=\"script.js\"></script>\n" : "";
        final String metaCharset = "<meta charset=\"utf-8\">\n";
        final String metaViewport = "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n";

        String lower = asciiLower(html);   // panjang sama persis dengan html agar indeks sejajar
        boolean isDocument = lower.contains("<html") || lower.contains("<!doctype")
                || lower.contains("<head") || lower.contains("<body");

        if (!isDocument) {
            // Potongan HTML saja: bungkus dengan kerangka dokumen standar.
            return "<!DOCTYPE html>\n<html>\n<head>\n" + metaCharset + metaViewport + cssTag
                    + "</head>\n<body>\n" + html + "\n" + jsTag + "</body>\n</html>\n";
        }

        List<int[]> positions = new ArrayList<>();   // {posisi, urutan}
        List<String> texts = new ArrayList<>();

        int headOpenEnd = afterOpenTag(lower, "<head");
        int afterHtml = afterOpenTag(lower, "<html");
        int afterDoctype = afterOpenTag(lower, "<!doctype");
        int fallbackTop = afterHtml >= 0 ? afterHtml : (afterDoctype >= 0 ? afterDoctype : 0);

        if (!lower.contains("charset")) {
            add(positions, texts, headOpenEnd >= 0 ? headOpenEnd : fallbackTop, 0, metaCharset);
        }
        if (hasCss) {
            int pos = lower.lastIndexOf("</head>");
            if (pos < 0) pos = headOpenEnd;
            if (pos < 0) pos = lower.indexOf("<body");
            if (pos < 0) pos = fallbackTop;
            add(positions, texts, pos, 1, cssTag);
        }
        if (hasJs) {
            int pos = lower.lastIndexOf("</body>");
            if (pos < 0) pos = lower.lastIndexOf("</html>");
            if (pos < 0) pos = html.length();
            add(positions, texts, pos, 2, jsTag);
        }

        // Sisipkan dari posisi paling belakang supaya posisi sebelumnya tidak bergeser.
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < positions.size(); i++) order.add(i);
        final List<int[]> fp = positions;
        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                int[] pa = fp.get(a);
                int[] pb = fp.get(b);
                if (pa[0] != pb[0]) return pb[0] - pa[0];
                return pb[1] - pa[1];
            }
        });
        StringBuilder sb = new StringBuilder(html.length() + 256);
        sb.append(html);
        for (int idx : order) {
            sb.insert(positions.get(idx)[0], texts.get(idx));
        }
        return sb.toString();
    }

    private static void add(List<int[]> positions, List<String> texts, int pos, int order, String text) {
        positions.add(new int[]{pos, order});
        texts.add(text);
    }

    /** Posisi tepat setelah tanda '>' penutup tag pembuka (mis. "<head ...>"), atau -1. */
    private static int afterOpenTag(String lower, String tagStart) {
        int i = lower.indexOf(tagStart);
        if (i < 0) return -1;
        int gt = lower.indexOf('>', i);
        return gt < 0 ? -1 : gt + 1;
    }

    private static String asciiLower(String s) {
        char[] c = s.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (c[i] >= 'A' && c[i] <= 'Z') c[i] = (char) (c[i] + 32);
        }
        return new String(c);
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static void write(File file, String content) throws IOException {
        try (BufferedWriter w = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8), 1 << 16)) {
            w.write(content);
        }
    }
}
