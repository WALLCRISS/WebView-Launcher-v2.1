package com.webviewlauncher.app.util;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.webkit.MimeTypeMap;
import android.widget.TextView;

import androidx.core.graphics.ColorUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Pengetahuan tentang jenis berkas dari akhiran namanya: apakah menghasilkan tampilan visual
 * saat dijalankan, apakah biner, bahasa pewarna sintaks, MIME, serta warna lencana (badge) di daftar.
 */
public final class FileKind {

    private FileKind() {
    }

    /** Saat dijalankan menghasilkan tampilan visual (dibuka di WebView layar penuh). Selain ini: hanya teks. */
    private static final Set<String> VISUAL = new HashSet<>(Arrays.asList("html", "htm", "xhtml", "svg"));

    /** Berkas biner / media: tidak dibuka di editor teks, melainkan di aplikasi lain. */
    private static final Set<String> BINARY = new HashSet<>(Arrays.asList(
            "png", "jpg", "jpeg", "gif", "webp", "bmp", "ico", "heic", "heif", "avif", "tif", "tiff",
            "mp3", "wav", "ogg", "oga", "m4a", "aac", "flac", "opus", "mid", "midi",
            "mp4", "m4v", "mkv", "webm", "avi", "mov", "3gp", "flv", "wmv",
            "zip", "rar", "7z", "gz", "tgz", "bz2", "xz", "tar", "apk", "aab", "jar", "war",
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "epub",
            "ttf", "otf", "woff", "woff2", "eot", "so", "dex", "class", "bin", "exe", "dll", "db", "sqlite", "dat"));

    private static final Set<String> LANG_HTML = new HashSet<>(Arrays.asList(
            "html", "htm", "xhtml", "svg", "xml", "vue", "xaml", "plist"));
    private static final Set<String> LANG_CSS = new HashSet<>(Arrays.asList("css", "scss", "sass", "less"));
    private static final Set<String> LANG_JS = new HashSet<>(Arrays.asList(
            "js", "mjs", "cjs", "jsx", "ts", "tsx", "json", "jsonc"));

    private static final Map<String, Integer> COLORS = new HashMap<>();
    private static final int[] FALLBACK = {0xFF7C6FEA, 0xFF2BA6A0, 0xFFD05C8A, 0xFF5E8BD6,
            0xFF8E6BBF, 0xFFC07A3A, 0xFF4E9F6B, 0xFF9A7B4F};

    static {
        COLORS.put("html", 0xFFE8721E);
        COLORS.put("htm", 0xFFE8721E);
        COLORS.put("xhtml", 0xFFE8721E);
        COLORS.put("css", 0xFF2F7BE0);
        COLORS.put("scss", 0xFFCD6799);
        COLORS.put("js", 0xFFD9B400);
        COLORS.put("mjs", 0xFFD9B400);
        COLORS.put("json", 0xFF8A8F98);
        COLORS.put("ts", 0xFF3178C6);
        COLORS.put("tsx", 0xFF3178C6);
        COLORS.put("jsx", 0xFF1BA1C4);
        COLORS.put("py", 0xFF3B7BBF);
        COLORS.put("java", 0xFFB07219);
        COLORS.put("kt", 0xFF8E63E6);
        COLORS.put("php", 0xFF777BB3);
        COLORS.put("sh", 0xFF4EAA25);
        COLORS.put("sql", 0xFFE38C00);
        COLORS.put("md", 0xFF5F6B7A);
        COLORS.put("txt", 0xFF8683A3);
        COLORS.put("xml", 0xFF2E9E8F);
        COLORS.put("svg", 0xFFFFA726);
        COLORS.put("c", 0xFF00599C);
        COLORS.put("cpp", 0xFF00599C);
        COLORS.put("h", 0xFF00599C);
        COLORS.put("cs", 0xFF68217A);
        COLORS.put("go", 0xFF00ADD8);
        COLORS.put("rb", 0xFFCC342D);
        COLORS.put("yml", 0xFFCB171E);
        COLORS.put("yaml", 0xFFCB171E);
    }

    /** Akhiran huruf kecil tanpa titik, atau "" bila tidak ada ("README" -> "", ".gitignore" -> ""). */
    public static String ext(String name) {
        if (name == null) return "";
        int dot = name.lastIndexOf('.');
        if (dot <= 0 || dot == name.length() - 1) return "";
        return name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    public static boolean isVisual(String ext) {
        return VISUAL.contains(ext);
    }

    public static boolean isJs(String ext) {
        return "js".equals(ext) || "mjs".equals(ext) || "cjs".equals(ext);
    }

    public static boolean isBinary(String ext) {
        return BINARY.contains(ext);
    }

    public static boolean isEditable(String name) {
        return !BINARY.contains(ext(name));
    }

    public static boolean canFormat(String ext) {
        return syntax(ext) != SyntaxHighlighter.LANG_NONE;
    }

    /** Bahasa untuk pewarna sintaks dan alat Format. */
    public static int syntax(String ext) {
        if (LANG_HTML.contains(ext)) return SyntaxHighlighter.LANG_HTML;
        if (LANG_CSS.contains(ext)) return SyntaxHighlighter.LANG_CSS;
        if (LANG_JS.contains(ext)) return SyntaxHighlighter.LANG_JS;
        return SyntaxHighlighter.LANG_NONE;
    }

    /**
     * MIME untuk membuat dokumen di SAF. Akhiran bebas: bila tidak dikenal dipakai octet-stream
     * supaya penyedia dokumen TIDAK menambahkan akhiran tambahan (mis. "a.py" menjadi "a.py.txt").
     */
    public static String mimeFor(String ext) {
        if (ext == null || ext.isEmpty()) return "application/octet-stream";
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m == null || m.isEmpty() ? "application/octet-stream" : m;
    }

    public static int color(String ext) {
        Integer c = COLORS.get(ext);
        if (c != null) return c;
        if (ext == null || ext.isEmpty()) return 0xFF8683A3;
        return FALLBACK[Math.abs(ext.hashCode()) % FALLBACK.length];
    }

    /** Teks pendek di lencana: "HTML", "PY", ... ; tanpa akhiran: "FILE". */
    public static String label(String ext) {
        if (ext == null || ext.isEmpty()) return "FILE";
        String up = ext.toUpperCase(Locale.ROOT);
        return up.length() > 4 ? up.substring(0, 4) : up;
    }

    /** Memberi gaya lencana berwarna (persegi membulat + singkatan akhiran) ke sebuah TextView. */
    public static void styleBadge(Context ctx, TextView badge, String ext) {
        float d = ctx.getResources().getDisplayMetrics().density;
        int bg = color(ext);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(10 * d);
        badge.setBackground(g);
        badge.setText(label(ext));
        badge.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        badge.setTextSize(10f);
        badge.setGravity(android.view.Gravity.CENTER);
        badge.setIncludeFontPadding(false);
        badge.setSingleLine(true);
        badge.setTextColor(ColorUtils.calculateLuminance(bg) > 0.55 ? 0xFF1E1B33 : Color.WHITE);
    }
}
