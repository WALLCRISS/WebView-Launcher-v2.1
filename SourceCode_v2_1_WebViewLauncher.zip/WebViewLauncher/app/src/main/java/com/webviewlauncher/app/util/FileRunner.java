package com.webviewlauncher.app.util;

import android.content.Context;

import com.webviewlauncher.app.R;
import com.webviewlauncher.app.theme.Palette;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Menyiapkan berkas dari Text Editor untuk tombol Jalankan.
 *
 * - Berkas visual (.html .htm .xhtml .svg): folder berkas disalin ke penyimpanan aplikasi lalu dibuka di
 *   WebView, jadi CSS / JS / gambar relatif di dalam folder tetap termuat.
 * - Selain itu hanya menghasilkan teks: .js dijalankan dan keluaran console-nya ditampilkan sebagai
 *   teks; .py, .css, .txt, dan lainnya ditampilkan sebagai teks.
 */
public final class FileRunner {

    private FileRunner() {
    }

    public static final class Result {
        public final File entry;
        public final File root;

        Result(File entry, File root) {
            this.entry = entry;
            this.root = root;
        }
    }

    /** HTML yang merujuk "../" membutuhkan folder di atasnya, jadi seluruh folder utama disalin. */
    public static boolean needsWholeRoot(String text) {
        return text != null && (text.contains("../") || text.contains("..\\"));
    }

    public static Result prepareVisual(Context ctx, DocStore store, String parentId, String fileName,
                                       String relPath, boolean wholeRoot) throws IOException {
        String scopeId = wholeRoot ? store.rootId() : parentId;
        File base = new File(ctx.getFilesDir(), "flash/files");
        String key = Integer.toHexString((store.treeUri().toString() + "|" + scopeId).hashCode());
        File dest = new File(base, key);

        // Hanya satu salinan kerja yang disimpan; salinan proyek lain dibersihkan.
        File[] others = base.listFiles();
        if (others != null) {
            for (File f : others) {
                if (!f.getName().equals(key)) FileUtils.deleteRecursive(f);
            }
        }
        store.mirror(scopeId, dest);

        File entry = new File(dest, wholeRoot ? relPath : fileName);
        if (!entry.isFile()) throw new IOException("entry missing");
        return new Result(entry, dest);
    }

    public static Result prepareText(Context ctx, String fileName, String ext, String text) throws IOException {
        File root = new File(ctx.getFilesDir(), "flash/out");
        FileUtils.deleteRecursive(root);
        if (!root.mkdirs() && !root.isDirectory()) throw new IOException("mkdir failed");

        String body;
        String note;
        if (FileKind.isJs(ext)) {
            write(new File(root, "script.js"), text);
            body = "<div id=\"out\"></div>\n<script src=\"script.js\"></script>";
            note = ctx.getString(R.string.run_js_note);
        } else {
            body = "<pre id=\"txt\">" + escape(text) + "</pre>";
            note = ctx.getString(R.string.run_text_note);
        }

        String tpl = readRaw(ctx, R.raw.run_output);
        // BODY diganti paling akhir supaya teks pengguna tidak ikut diproses sebagai penanda.
        String html = tpl.replace("%%TITLE%%", escape(fileName))
                .replace("%%NOTE%%", escape(note))
                .replace("%%ACCENT%%", String.format(Locale.US, "#%06X", 0xFFFFFF & Palette.accent(ctx)))
                .replace("%%EMPTY%%", ctx.getString(R.string.run_no_output).replace("'", "\\'"))
                .replace("%%BODY%%", body);
        File index = new File(root, "index.html");
        write(index, html);
        return new Result(index, root);
    }

    private static String escape(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&':
                    sb.append("&amp;");
                    break;
                case '<':
                    sb.append("&lt;");
                    break;
                case '>':
                    sb.append("&gt;");
                    break;
                case '"':
                    sb.append("&quot;");
                    break;
                default:
                    sb.append(c);
            }
        }
        return sb.toString();
    }

    private static String readRaw(Context ctx, int res) throws IOException {
        try (InputStream in = ctx.getResources().openRawResource(res)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static void write(File f, String content) throws IOException {
        try (FileOutputStream out = new FileOutputStream(f)) {
            out.write(content.getBytes(StandardCharsets.UTF_8));
        }
    }
}
