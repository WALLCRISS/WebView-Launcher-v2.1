package com.webviewlauncher.app.util;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.text.format.DateFormat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

public class FileUtils {

    /**
     * Menyalin seluruh isi InputStream ke sebuah berkas tujuan (dipakai untuk menyalin
     * gambar ikon yang dipilih pengguna ke storage internal aplikasi).
     */
    public static void copyStreamToFile(InputStream in, File outFile) throws IOException {
        File parent = outFile.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (OutputStream out = new FileOutputStream(outFile)) {
            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }
        }
    }

    /** Membaca seluruh isi berkas ke memori. Dipakai untuk berkas kecil (ikon, html tunggal). */
    public static byte[] readAllBytes(File file) throws IOException {
        try (java.io.FileInputStream in = new java.io.FileInputStream(file);
             java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(
                     (int) Math.min(Math.max(file.length(), 32L), 1L << 26))) {
            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }
            return out.toByteArray();
        }
    }

    public static void deleteRecursive(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) deleteRecursive(child);
            }
        }
        file.delete();
    }

    public static String formatMillis(int millis) {
        int totalSeconds = millis / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    public static String randomId() {
        return java.util.UUID.randomUUID().toString();
    }

    /**
     * Mencoba membuat lokasi berkas yang mudah dibaca manusia dari Uri SAF (Storage Access
     * Framework), mis. "Download/WebViewLauncher/WebViewLauncher.zip". Dibuat dari document ID
     * penyedia dokumen (berbentuk "volume:path/relatif"), pendekatan umum yang dipakai banyak
     * aplikasi karena Android tidak memberi path berkas asli secara langsung lewat Uri content://.
     * Mengembalikan string kosong bila tidak bisa ditentukan (mis. dari penyedia cloud/awan).
     */
    public static String guessDisplayPath(Context context, Uri uri, String fallbackFileName) {
        if (uri == null) return "";
        try {
            String docId = null;
            if (DocumentsContract.isDocumentUri(context, uri)) {
                docId = DocumentsContract.getDocumentId(uri);
            } else {
                try {
                    docId = DocumentsContract.getTreeDocumentId(uri);
                } catch (Exception ignored) {
                }
            }
            if (docId == null || docId.isEmpty()) return "";

            int colon = docId.indexOf(':');
            String volume = colon >= 0 ? docId.substring(0, colon) : "";
            String relativePath = colon >= 0 ? docId.substring(colon + 1) : docId;
            if (relativePath == null || relativePath.isEmpty()) return "";

            // Penyimpanan internal utama: docId sudah berupa path relatif yang jelas
            // (mis. "primary:Download/WebViewLauncher/WebViewLauncher.zip").
            if ("primary".equalsIgnoreCase(volume) || volume.isEmpty()
                    || volume.toLowerCase(Locale.ROOT).startsWith("raw")) {
                return relativePath;
            }
            // Volume lain (mis. kartu SD eksternal atau id acak dari penyedia khusus):
            // sertakan nama volumenya di depan agar tetap informatif.
            if (relativePath.contains("/") || relativePath.contains(".")) {
                return volume + "/" + relativePath;
            }
            return "";
        } catch (Exception e) {
            return "";
        }
    }

    /** Mengambil ukuran berkas (byte) dari Uri SAF lewat ContentResolver, -1 bila gagal. */
    public static long querySizeFromUri(Context context, Uri uri) {
        if (uri == null) return -1;
        try (Cursor cursor = context.getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (idx >= 0 && !cursor.isNull(idx)) return cursor.getLong(idx);
            }
        } catch (Exception ignored) {
        }
        return -1;
    }

    /** Format ukuran berkas ramah-baca, mis. "482 KB" atau "3.1 MB". */
    public static String formatFileSize(long bytes) {
        if (bytes < 0) return "";
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024) return String.format(Locale.getDefault(), "%.0f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024) return String.format(Locale.getDefault(), "%.1f MB", mb);
        double gb = mb / 1024.0;
        return String.format(Locale.getDefault(), "%.2f GB", gb);
    }

    /** Format tanggal+jam ramah-baca sesuai format lokal perangkat, mis. "22 Sep 2026 14.05". */
    public static String formatDate(Context context, long millis) {
        if (millis <= 0) return "";
        java.util.Date date = new java.util.Date(millis);
        return DateFormat.format("d MMM yyyy, HH:mm", date).toString();
    }
}
