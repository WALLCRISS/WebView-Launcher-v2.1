package com.webviewlauncher.app.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import android.webkit.WebResourceResponse;

import com.webviewlauncher.app.App;

import java.io.ByteArrayInputStream;
import java.util.HashMap;

/**
 * Kebijakan akses internet. Bawaan MATI (100% offline: semua permintaan http/https ke luar
 * diblokir). Bila togle HIDUP dan perangkat memang punya koneksi internet, semuanya diizinkan
 * (CDN, localhost, browsing). Bila togle hidup tetapi tidak ada koneksi, perilakunya kembali
 * seperti mati.
 */
public final class InternetPolicy {

    public static final String KEY_INTERNET = "internet";
    public static final String KEY_BACKGROUND = "background";
    public static final String KEY_WARNED = "internet_warned";

    private static long lastCheckAt = 0;
    private static boolean lastHasNetwork = false;

    private InternetPolicy() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(App.PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isEnabled(Context c) {
        return prefs(c).getBoolean(KEY_INTERNET, false);
    }

    public static void setEnabled(Context c, boolean on) {
        prefs(c).edit().putBoolean(KEY_INTERNET, on).apply();
    }

    public static boolean isBackground(Context c) {
        return prefs(c).getBoolean(KEY_BACKGROUND, false);
    }

    public static void setBackground(Context c, boolean on) {
        prefs(c).edit().putBoolean(KEY_BACKGROUND, on).apply();
    }

    public static boolean wasWarned(Context c) {
        return prefs(c).getBoolean(KEY_WARNED, false);
    }

    public static void markWarned(Context c) {
        prefs(c).edit().putBoolean(KEY_WARNED, true).apply();
    }

    /** True hanya bila togle hidup DAN ada koneksi internet. */
    public static boolean isAllowed(Context c) {
        return isEnabled(c) && hasNetwork(c);
    }

    public static synchronized boolean hasNetwork(Context c) {
        long now = System.currentTimeMillis();
        if (now - lastCheckAt < 1500) return lastHasNetwork;
        lastCheckAt = now;
        boolean result = false;
        try {
            ConnectivityManager cm = (ConnectivityManager)
                    c.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Network n = cm.getActiveNetwork();
                    NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
                    result = nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
                } else {
                    NetworkInfo info = cm.getActiveNetworkInfo();
                    result = info != null && info.isConnected();
                }
            }
        } catch (Exception ignored) {
        }
        lastHasNetwork = result;
        return result;
    }

    /** Tanggapan kosong 403 untuk permintaan keluar yang diblokir. */
    public static WebResourceResponse blockedResponse() {
        return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }
}
