package com.webviewlauncher.app.util;

import android.content.Context;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Penyimpanan Library di dalam aplikasi (filesDir/library). Berkas yang ditambahkan disalin
 * ke sini, sehingga tetap ada walau berkas aslinya di perangkat sudah dihapus. File .zip
 * diekstrak menjadi satu folder bernama sama dengan zip-nya.
 *
 * Saat HTML dijalankan, permintaan berkas yang tidak ada di proyek akan dicari di sini
 * ({@link Index}), sehingga HTML cukup menulis nama berkasnya seolah satu folder.
 */
public final class LibraryStore {

    public static class Entry {
        public final File file;
        public final boolean isDir;
        public final long size;
        public final int fileCount;

        Entry(File file, boolean isDir, long size, int fileCount) {
            this.file = file;
            this.isDir = isDir;
            this.size = size;
            this.fileCount = fileCount;
        }
    }

    private LibraryStore() {
    }

    public static File dir(Context context) {
        File d = new File(context.getFilesDir(), "library");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** Nama berkas aman: tanpa pemisah path dan karakter terlarang. */
    public static String safeName(String name, String fallback) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\x00-\\x1F]", "_").trim();
        if (n.isEmpty() || n.equals(".") || n.equals("..")) n = fallback;
        return n;
    }

    /** Daftar isi tingkat atas Library (folder dulu, lalu berkas, urut nama). Jalankan di thread latar. */
    public static List<Entry> list(Context context) {
        List<Entry> result = new ArrayList<>();
        File[] children = dir(context).listFiles();
        if (children == null) return result;
        for (File f : children) {
            if (f.isDirectory()) {
                long[] stat = new long[2];
                measure(f, stat);
                result.add(new Entry(f, true, stat[0], (int) stat[1]));
            } else {
                result.add(new Entry(f, false, f.length(), 1));
            }
        }
        Collections.sort(result, new Comparator<Entry>() {
            @Override
            public int compare(Entry a, Entry b) {
                if (a.isDir != b.isDir) return a.isDir ? -1 : 1;
                return a.file.getName().compareToIgnoreCase(b.file.getName());
            }
        });
        return result;
    }

    private static void measure(File f, long[] stat) {
        File[] kids = f.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            if (k.isDirectory()) {
                measure(k, stat);
            } else {
                stat[0] += k.length();
                stat[1]++;
            }
        }
    }

    /** Menyalin satu berkas ke Library (menimpa bila namanya sama). */
    public static void addFile(Context context, InputStream in, String name) throws IOException {
        File target = new File(dir(context), safeName(name, "file"));
        if (target.isDirectory()) FileUtils.deleteRecursive(target);
        File tmp = new File(target.getParentFile(), target.getName() + ".part");
        try {
            FileUtils.copyStreamToFile(in, tmp);
            if (target.exists() && !target.delete()) throw new IOException("replace failed");
            if (!tmp.renameTo(target)) throw new IOException("rename failed");
        } finally {
            if (tmp.exists()) tmp.delete();
        }
    }

    /** Mengekstrak zip ke folder bernama sama dengan zip-nya (menggantikan yang lama). */
    public static void addZip(Context context, InputStream in, String zipName) throws IOException {
        String base = zipName == null ? "library" : zipName;
        if (base.toLowerCase(Locale.ROOT).endsWith(".zip")) base = base.substring(0, base.length() - 4);
        File dest = new File(dir(context), safeName(base, "library"));
        FileUtils.deleteRecursive(dest);
        try {
            ZipExtractor.extract(in, dest, Long.MAX_VALUE);
        } catch (IOException | RuntimeException e) {
            FileUtils.deleteRecursive(dest);
            throw e;
        }
    }

    public static void delete(File entry) {
        FileUtils.deleteRecursive(entry);
    }

    /**
     * Pencari berkas Library untuk satu sesi WebView. Urutan pencarian:
     * 1) path persis (mis. "css/bootstrap.min.css" atau "folder-zip/css/x.css"),
     * 2) nama berkasnya saja di mana pun di Library (yang paling dangkal diutamakan).
     */
    public static final class Index {
        private final File root;
        private Map<String, String> byName;

        public Index(File root) {
            this.root = root;
        }

        /** @return path relatif di dalam Library, atau null bila tidak ada. */
        public synchronized String find(String requested) {
            if (requested == null) return null;
            String clean = requested.replace('\\', '/');
            while (clean.startsWith("/")) clean = clean.substring(1);
            if (clean.isEmpty()) return null;

            try {
                File exact = new File(root, clean);
                String canonRoot = root.getCanonicalPath();
                String canon = exact.getCanonicalPath();
                if (canon.startsWith(canonRoot + File.separator) && exact.isFile()) return clean;
            } catch (IOException ignored) {
            }

            String base = clean.substring(clean.lastIndexOf('/') + 1).toLowerCase(Locale.ROOT);
            if (base.isEmpty()) return null;
            if (byName == null) build();
            return byName.get(base);
        }

        private void build() {
            byName = new HashMap<>();
            ArrayDeque<String> queue = new ArrayDeque<>();
            queue.add("");
            while (!queue.isEmpty()) {
                String rel = queue.poll();
                File dir = rel.isEmpty() ? root : new File(root, rel);
                File[] kids = dir.listFiles();
                if (kids == null) continue;
                Arrays_sort(kids);
                for (File k : kids) {
                    String childRel = rel.isEmpty() ? k.getName() : rel + "/" + k.getName();
                    if (k.isDirectory()) {
                        queue.add(childRel);
                    } else {
                        String key = k.getName().toLowerCase(Locale.ROOT);
                        if (!byName.containsKey(key)) byName.put(key, childRel);
                    }
                }
            }
        }

        private static void Arrays_sort(File[] files) {
            java.util.Arrays.sort(files, new Comparator<File>() {
                @Override
                public int compare(File a, File b) {
                    return a.getName().compareToIgnoreCase(b.getName());
                }
            });
        }
    }
}
