package com.webviewlauncher.app.util;

import android.content.Context;
import android.os.Environment;

import androidx.core.content.ContextCompat;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Memindai seluruh penyimpanan perangkat dan mengelompokkan berkas (html/css/js/zip, sesuai
 * filter) menurut foldernya. Hanya folder yang LANGSUNG berisi berkas yang cocok yang dikembalikan.
 * Folder tersembunyi (diawali titik), "Android", dan "node_modules" dilewati.
 */
public final class StorageScanner {

    public static final class Group {
        public final File dir;
        public final List<File> files = new ArrayList<>();

        Group(File dir) {
            this.dir = dir;
        }
    }

    public interface Callback {
        void onProgress(int foldersFound);

        boolean isCancelled();
    }

    private static final int MAX_DEPTH = 16;

    private StorageScanner() {
    }

    /** Akar penyimpanan: memori internal utama + kartu SD / volume lain bila ada. */
    public static List<File> roots(Context ctx) {
        List<File> roots = new ArrayList<>();
        File primary = Environment.getExternalStorageDirectory();
        if (primary != null && primary.exists()) roots.add(primary);
        File[] dirs = ContextCompat.getExternalFilesDirs(ctx, null);
        if (dirs != null) {
            for (File f : dirs) {
                if (f == null) continue;
                String path = f.getAbsolutePath();
                int i = path.indexOf("/Android/");
                if (i <= 0) continue;
                File root = new File(path.substring(0, i));
                boolean dup = false;
                for (File r : roots) if (r.equals(root)) dup = true;
                if (!dup && root.exists()) roots.add(root);
            }
        }
        return roots;
    }

    /** Nama folder yang mudah dibaca: relatif terhadap memori utama bila mungkin. */
    public static String displayPath(Context ctx, File dir) {
        String p = dir.getAbsolutePath();
        File primary = Environment.getExternalStorageDirectory();
        if (primary != null) {
            String base = primary.getAbsolutePath();
            if (p.equals(base)) return "/";
            if (p.startsWith(base + "/")) return p.substring(base.length() + 1);
        }
        return p;
    }

    public static List<Group> scan(Context ctx, Set<String> extensions, Callback cb) {
        Map<String, Group> groups = new LinkedHashMap<>();
        for (File root : roots(ctx)) {
            ArrayDeque<File> stack = new ArrayDeque<>();
            ArrayDeque<Integer> depths = new ArrayDeque<>();
            stack.push(root);
            depths.push(0);
            while (!stack.isEmpty()) {
                if (cb != null && cb.isCancelled()) return new ArrayList<>(groups.values());
                File dir = stack.pop();
                int depth = depths.pop();
                File[] kids = dir.listFiles();
                if (kids == null) continue;
                for (File k : kids) {
                    String name = k.getName();
                    if (k.isDirectory()) {
                        if (depth >= MAX_DEPTH) continue;
                        if (name.startsWith(".") || name.equals("node_modules")) continue;
                        if (depth == 0 && name.equals("Android")) continue;
                        stack.push(k);
                        depths.push(depth + 1);
                    } else {
                        int dot = name.lastIndexOf('.');
                        if (dot <= 0) continue;
                        String ext = name.substring(dot + 1).toLowerCase(Locale.ROOT);
                        if (!extensions.contains(ext)) continue;
                        String key = dir.getAbsolutePath();
                        Group g = groups.get(key);
                        if (g == null) {
                            g = new Group(dir);
                            groups.put(key, g);
                            if (cb != null) cb.onProgress(groups.size());
                        }
                        g.files.add(k);
                    }
                }
            }
        }
        List<Group> result = new ArrayList<>(groups.values());
        Collections.sort(result, new Comparator<Group>() {
            @Override
            public int compare(Group a, Group b) {
                return a.dir.getAbsolutePath().compareToIgnoreCase(b.dir.getAbsolutePath());
            }
        });
        for (Group g : result) {
            Collections.sort(g.files, new Comparator<File>() {
                @Override
                public int compare(File a, File b) {
                    return a.getName().compareToIgnoreCase(b.getName());
                }
            });
        }
        return result;
    }
}
