package com.webviewlauncher.app.util;

import android.content.Context;
import android.content.res.Configuration;

import androidx.core.content.ContextCompat;

import com.webviewlauncher.app.R;
import com.webviewlauncher.app.theme.Palette;

/** Warna token sintaks untuk tema saat ini (terang/gelap + warna aksen). */
public final class SyntaxColors {

    private SyntaxColors() {
    }

    public static int[] forContext(Context c) {
        boolean dark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int accent = Palette.accentForSyntax(c, dark);
        int[] t = new int[9];
        t[SyntaxHighlighter.T_COMMENT] = ContextCompat.getColor(c, R.color.syn_comment);
        t[SyntaxHighlighter.T_STRING] = ContextCompat.getColor(c, R.color.syn_string);
        t[SyntaxHighlighter.T_KEYWORD] = accent;
        t[SyntaxHighlighter.T_NUMBER] = ContextCompat.getColor(c, R.color.syn_number);
        t[SyntaxHighlighter.T_FUNCTION] = ContextCompat.getColor(c, R.color.syn_function);
        t[SyntaxHighlighter.T_TAG] = accent;
        t[SyntaxHighlighter.T_ATTR] = ContextCompat.getColor(c, R.color.syn_attr);
        t[SyntaxHighlighter.T_PROPERTY] = ContextCompat.getColor(c, R.color.syn_attr);
        t[SyntaxHighlighter.T_ATRULE] = accent;
        return t;
    }
}
