package com.webviewlauncher.app.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pewarna sintaks ringan untuk HTML / CSS / JS. Memindai satu potongan teks (jendela yang
 * terlihat di layar) dan mengembalikan daftar {awal, akhir, jenis}.
 */
public final class SyntaxHighlighter {

    public static final int LANG_NONE = 0;
    public static final int LANG_HTML = 1;
    public static final int LANG_CSS = 2;
    public static final int LANG_JS = 3;

    public static final int T_COMMENT = 0;
    public static final int T_STRING = 1;
    public static final int T_KEYWORD = 2;
    public static final int T_NUMBER = 3;
    public static final int T_FUNCTION = 4;
    public static final int T_TAG = 5;
    public static final int T_ATTR = 6;
    public static final int T_PROPERTY = 7;
    public static final int T_ATRULE = 8;

    private SyntaxHighlighter() {
    }

    private static final Pattern JS = Pattern.compile(
            "(//[^\\n]*|/\\*[\\s\\S]*?\\*/)"
                    + "|(\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'|`(?:\\\\[\\s\\S]|[^`\\\\])*`)"
                    + "|\\b(var|let|const|function|return|if|else|for|while|do|switch|case|break|continue|new|delete|typeof|instanceof|in|of|this|class|extends|super|import|export|default|from|async|await|try|catch|finally|throw|null|undefined|true|false|yield|static|get|set|void)\\b"
                    + "|\\b(0[xX][0-9a-fA-F]+|\\d[\\d_]*(?:\\.\\d+)?(?:[eE][+-]?\\d+)?)\\b"
                    + "|([A-Za-z_$][\\w$]*)(?=\\s*\\()");

    private static final Pattern CSS = Pattern.compile(
            "(/\\*[\\s\\S]*?\\*/)"
                    + "|(\"[^\"\\n]*\"|'[^'\\n]*')"
                    + "|(@[\\w-]+)"
                    + "|(#[0-9a-fA-F]{3,8}\\b|\\b\\d+(?:\\.\\d+)?(?:px|em|rem|%|vh|vw|vmin|vmax|ms|s|deg|fr|pt|cm|mm)?)"
                    + "|([A-Za-z-]+)(?=\\s*:)");

    private static final Pattern HTML_OUTER = Pattern.compile(
            "(<!--[\\s\\S]*?-->)|(<![^>]*>)|(</?[A-Za-z][^<>]*>)");
    private static final Pattern HTML_TAGNAME = Pattern.compile("^</?[A-Za-z][\\w:-]*");
    private static final Pattern HTML_INNER = Pattern.compile(
            "(\"[^\"]*\"|'[^']*')|([\\w:@.-]+)(?=\\s*=)");

    public static List<int[]> scan(int lang, String s) {
        List<int[]> out = new ArrayList<>();
        switch (lang) {
            case LANG_JS:
                scanJs(s, out);
                break;
            case LANG_CSS:
                scanCss(s, out);
                break;
            case LANG_HTML:
                scanHtml(s, out);
                break;
            default:
                break;
        }
        return out;
    }

    private static void scanJs(String s, List<int[]> out) {
        Matcher m = JS.matcher(s);
        while (m.find()) {
            if (m.group(1) != null) out.add(new int[]{m.start(), m.end(), T_COMMENT});
            else if (m.group(2) != null) out.add(new int[]{m.start(), m.end(), T_STRING});
            else if (m.group(3) != null) out.add(new int[]{m.start(), m.end(), T_KEYWORD});
            else if (m.group(4) != null) out.add(new int[]{m.start(), m.end(), T_NUMBER});
            else if (m.group(5) != null) out.add(new int[]{m.start(), m.end(), T_FUNCTION});
        }
    }

    private static void scanCss(String s, List<int[]> out) {
        Matcher m = CSS.matcher(s);
        while (m.find()) {
            if (m.group(1) != null) out.add(new int[]{m.start(), m.end(), T_COMMENT});
            else if (m.group(2) != null) out.add(new int[]{m.start(), m.end(), T_STRING});
            else if (m.group(3) != null) out.add(new int[]{m.start(), m.end(), T_ATRULE});
            else if (m.group(4) != null) out.add(new int[]{m.start(), m.end(), T_NUMBER});
            else if (m.group(5) != null) out.add(new int[]{m.start(), m.end(), T_PROPERTY});
        }
    }

    private static void scanHtml(String s, List<int[]> out) {
        Matcher m = HTML_OUTER.matcher(s);
        while (m.find()) {
            if (m.group(1) != null) {
                out.add(new int[]{m.start(), m.end(), T_COMMENT});
            } else if (m.group(2) != null) {
                out.add(new int[]{m.start(), m.end(), T_KEYWORD});
            } else {
                String tag = m.group(3);
                int base = m.start();
                Matcher nm = HTML_TAGNAME.matcher(tag);
                int nameEnd = 0;
                if (nm.find()) {
                    nameEnd = nm.end();
                    out.add(new int[]{base, base + nameEnd, T_TAG});
                }
                // penutup ">" ikut diwarnai sebagai tag
                out.add(new int[]{base + tag.length() - 1, base + tag.length(), T_TAG});
                Matcher im = HTML_INNER.matcher(tag);
                im.region(nameEnd, tag.length());
                while (im.find()) {
                    if (im.group(1) != null) out.add(new int[]{base + im.start(), base + im.end(), T_STRING});
                    else out.add(new int[]{base + im.start(), base + im.end(), T_ATTR});
                }
            }
        }
    }
}
