package com.webviewlauncher.app.util;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/** Menyimpan folder sebagai .zip ke folder Download perangkat (seperti mengunduh). */
public final class ZipExporter {

    private ZipExporter() {
    }

    public static final class Result {
        public final String fileName;
        public final int files;

        Result(String fileName, int files) {
            this.fileName = fileName;
            this.files = files;
        }
    }

    /** Android 9 ke bawah butuh izin tulis penyimpanan; Android 10+ memakai MediaStore (tanpa izin). */
    public static boolean needsLegacyPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.Q;
    }

    public static Result export(Context ctx, DocStore store, String folderId, String folderName) throws IOException {
        String wanted = DocStore.safeFileName(folderName) + ".zip";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver cr = ctx.getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, wanted);
            v.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            v.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("insert failed");
            try {
                int count;
                try (OutputStream out = cr.openOutputStream(uri)) {
                    if (out == null) throw new IOException("cannot open");
                    count = store.writeZip(folderId, out);
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                cr.update(uri, done, null, null);
                String finalName = queryName(cr, uri, wanted);
                return new Result(finalName, count);
            } catch (IOException | RuntimeException e) {
                try {
                    cr.delete(uri, null, null);
                } catch (Exception ignored) {
                }
                throw e;
            }
        }

        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("no Download dir");
        File out = uniqueFile(dir, wanted);
        int count;
        try (FileOutputStream fos = new FileOutputStream(out)) {
            count = store.writeZip(folderId, fos);
        } catch (IOException | RuntimeException e) {
            out.delete();
            throw e;
        }
        MediaScannerConnection.scanFile(ctx, new String[]{out.getAbsolutePath()}, new String[]{"application/zip"}, null);
        return new Result(out.getName(), count);
    }

    private static String queryName(ContentResolver cr, Uri uri, String fallback) {
        try (android.database.Cursor c = cr.query(uri, new String[]{MediaStore.Downloads.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst() && c.getString(0) != null) return c.getString(0);
        } catch (Exception ignored) {
        }
        return fallback;
    }

    private static File uniqueFile(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 10000; i++) {
            f = new File(dir, base + " (" + i + ")" + ext);
            if (!f.exists()) return f;
        }
        return f;
    }
}
