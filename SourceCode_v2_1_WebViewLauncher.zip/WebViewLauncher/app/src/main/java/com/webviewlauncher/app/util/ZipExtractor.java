package com.webviewlauncher.app.util;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Mengekstrak berkas .zip (proyek HTML yang berisi banyak folder dan file) ke sebuah
 * folder tujuan di storage internal, lalu mencari berkas index.html sebagai titik masuk
 * dan gambar icon.png / icon.jpg (bila ada) sebagai ikon otomatis.
 */
public class ZipExtractor {

    /** Nama gambar ikon yang dikenali, berurutan dari yang paling diutamakan. */
    private static final String[] ICON_EXTENSIONS = {"png", "jpg", "jpeg", "webp"};

    private static final int MAX_ICON_BYTES = 8 * 1024 * 1024;

    /**
     * Mengekstrak seluruh isi zip dari inputStream ke destDir.
     */
    public static void extract(InputStream inputStream, File destDir) throws IOException {
        extract(inputStream, destDir, Long.MAX_VALUE);
    }

    /**
     * Sama seperti {@link #extract(InputStream, File)} tetapi menolak zip yang setelah
     * diekstrak melebihi maxTotalBytes (perlindungan dari zip bomb pada data terima).
     */
    public static void extract(InputStream inputStream, File destDir, long maxTotalBytes)
            throws IOException {
        if (!destDir.exists()) destDir.mkdirs();

        long total = 0;
        try (ZipInputStream zis = new ZipInputStream(inputStream)) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = zis.getNextEntry()) != null) {
                File outFile = new File(destDir, entry.getName());

                // Cegah path traversal (zip slip)
                String canonicalDest = destDir.getCanonicalPath();
                String canonicalOut = outFile.getCanonicalPath();
                if (!canonicalOut.startsWith(canonicalDest + File.separator) && !canonicalOut.equals(canonicalDest)) {
                    continue;
                }

                if (entry.isDirectory()) {
                    outFile.mkdirs();
                } else {
                    File parent = outFile.getParentFile();
                    if (parent != null && !parent.exists()) parent.mkdirs();
                    try (OutputStream os = new BufferedOutputStream(new FileOutputStream(outFile))) {
                        int len;
                        while ((len = zis.read(buffer)) != -1) {
                            total += len;
                            if (total > maxTotalBytes) {
                                throw new IOException("Isi zip terlalu besar");
                            }
                            os.write(buffer, 0, len);
                        }
                    }
                }
                zis.closeEntry();
            }
        }
    }

    /**
     * Mencari berkas index.html (atau berkas .html lain bila tidak ada) di dalam folder,
     * dengan memprioritaskan file yang paling dekat dengan folder akar.
     */
    public static File findEntryHtml(File rootDir) {
        File direct = new File(rootDir, "index.html");
        if (direct.exists()) return direct;

        File best = searchRecursive(rootDir, rootDir, "index.html", 0);
        if (best != null) return best;

        return searchAnyHtml(rootDir, rootDir, 0);
    }

    // ------------------------------------------------------------------ ikon di dalam zip

    /** True bila nama berkas adalah icon.png / icon.jpg / icon.jpeg / icon.webp (huruf besar-kecil bebas). */
    public static boolean isIconName(String fileName) {
        return iconRank(fileName) >= 0;
    }

    private static int iconRank(String fileName) {
        if (fileName == null) return -1;
        String lower = fileName.toLowerCase(Locale.ROOT);
        for (int i = 0; i < ICON_EXTENSIONS.length; i++) {
            if (lower.equals("icon." + ICON_EXTENSIONS[i])) return i;
        }
        return -1;
    }

    /**
     * Mencari gambar bernama icon di folder hasil ekstrak. Yang paling dekat dengan folder
     * akar diutamakan (icon di akar menang atas icon di subfolder).
     */
    public static File findIconFile(File rootDir) {
        List<File> level = new ArrayList<>();
        level.add(rootDir);
        for (int depth = 0; depth < 8 && !level.isEmpty(); depth++) {
            File best = null;
            List<File> next = new ArrayList<>();
            for (File dir : level) {
                File[] files = dir.listFiles();
                if (files == null) continue;
                Arrays.sort(files);
                for (File f : files) {
                    if (f.isDirectory()) {
                        if (!f.getName().equals("__MACOSX")) next.add(f);
                    } else {
                        int rank = iconRank(f.getName());
                        if (rank >= 0 && (best == null || rank < iconRank(best.getName()))) {
                            best = f;
                        }
                    }
                }
            }
            if (best != null) return best;
            level = next;
        }
        return null;
    }

    /**
     * Mengintip isi zip (tanpa mengekstrak ke disk) untuk mengambil byte gambar icon.*
     * yang paling dekat dengan akar. Dipakai untuk pratinjau ikon sebelum disimpan.
     *
     * @return byte gambar, atau null bila tidak ada
     */
    public static byte[] peekIcon(InputStream inputStream) throws IOException {
        byte[] bestData = null;
        int bestDepth = Integer.MAX_VALUE;
        int bestRank = Integer.MAX_VALUE;

        try (ZipInputStream zis = new ZipInputStream(inputStream)) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                String name = entry.getName().replace('\\', '/');
                if (name.startsWith("__MACOSX/")) continue;

                int slash = name.lastIndexOf('/');
                String base = slash >= 0 ? name.substring(slash + 1) : name;
                int rank = iconRank(base);
                if (rank < 0) continue;

                int depth = 0;
                for (int i = 0; i < name.length(); i++) {
                    if (name.charAt(i) == '/') depth++;
                }
                if (depth > bestDepth || (depth == bestDepth && rank >= bestRank)) continue;

                byte[] data = readLimited(zis, MAX_ICON_BYTES);
                if (data == null) continue;
                bestData = data;
                bestDepth = depth;
                bestRank = rank;
            }
        }
        return bestData;
    }

    private static byte[] readLimited(InputStream in, int limit) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int len;
        int total = 0;
        while ((len = in.read(buffer)) != -1) {
            total += len;
            if (total > limit) return null;
            out.write(buffer, 0, len);
        }
        return out.toByteArray();
    }

    // ------------------------------------------------------------------ pencarian html

    private static File searchRecursive(File dir, File root, String targetName, int depth) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        File found = null;
        int foundDepth = Integer.MAX_VALUE;
        for (File f : files) {
            if (f.isDirectory()) {
                File sub = searchRecursive(f, root, targetName, depth + 1);
                if (sub != null && depth + 1 < foundDepth) {
                    found = sub;
                    foundDepth = depth + 1;
                }
            } else if (f.getName().equalsIgnoreCase(targetName)) {
                if (depth < foundDepth) {
                    found = f;
                    foundDepth = depth;
                }
            }
        }
        return found;
    }

    private static File searchAnyHtml(File dir, File root, int depth) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File f : files) {
            if (f.isFile() && f.getName().toLowerCase().endsWith(".html")) {
                return f;
            }
        }
        for (File f : files) {
            if (f.isDirectory()) {
                File sub = searchAnyHtml(f, root, depth + 1);
                if (sub != null) return sub;
            }
        }
        return null;
    }
}
