package com.webviewlauncher.app.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Penggeser kecerahan (value 0–100%): dari hitam sampai warna hue/saturasi saat ini. */
public class BrightnessSlider extends View {

    public interface Listener {
        void onValueChanged(float value);
    }

    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float density;
    private float hue = 0f, sat = 0f, value = 1f;
    private Listener listener;

    public BrightnessSlider(Context c) {
        this(c, null);
    }

    public BrightnessSlider(Context c, AttributeSet a) {
        super(c, a);
        density = getResources().getDisplayMetrics().density;
        thumbRing.setStyle(Paint.Style.STROKE);
        thumbRing.setStrokeWidth(3f * density);
        thumbRing.setColor(0xFFFFFFFF);
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public void setColor(float h, float s, float v) {
        hue = h;
        sat = s;
        value = v;
        rebuildShader();
        invalidate();
    }

    private void rebuildShader() {
        int w = getWidth();
        if (w <= 0) return;
        int end = Color.HSVToColor(new float[]{hue, sat, 1f});
        barPaint.setShader(new LinearGradient(0, 0, w, 0, 0xFF000000, end, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        rebuildShader();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), (int) (36 * density));
    }

    @Override
    protected void onDraw(Canvas c) {
        float pad = 14f * density;
        float barH = 14f * density;
        float cy = getHeight() / 2f;
        rect.set(pad, cy - barH / 2f, getWidth() - pad, cy + barH / 2f);
        c.drawRoundRect(rect, barH / 2f, barH / 2f, barPaint);
        float x = pad + value * (getWidth() - 2 * pad);
        thumbFill.setColor(Color.HSVToColor(new float[]{hue, sat, value}));
        c.drawCircle(x, cy, 12f * density, thumbFill);
        c.drawCircle(x, cy, 12f * density, thumbRing);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) getParent().requestDisallowInterceptTouchEvent(true);
        float pad = 14f * density;
        float v = (e.getX() - pad) / (getWidth() - 2 * pad);
        value = Math.max(0f, Math.min(1f, v));
        invalidate();
        if (listener != null) listener.onValueChanged(value);
        return true;
    }
}
