package com.webviewlauncher.app.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Layout;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.AttributeSet;
import android.util.TypedValue;

import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.content.ContextCompat;

import com.webviewlauncher.app.R;
import com.webviewlauncher.app.theme.Palette;
import com.webviewlauncher.app.util.SyntaxHighlighter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Kotak kode: nomor baris, pewarna sintaks (hanya bagian yang terlihat, jadi tetap ringan
 * untuk puluhan ribu baris), cari/ganti dengan sorotan hasil, undo/redo sendiri, indentasi
 * otomatis, dan operasi baris (duplikat, hapus, pindah, komentar, indent).
 */
public class CodeEditText extends AppCompatEditText {

    public interface CursorListener {
        void onCursorChanged();
    }

    private static final int HIGHLIGHT_MARGIN_LINES = 40;
    private static final int MAX_MATCHES = 20000;
    private static final int MAX_UNDO_CHARS = 4_000_000;

    private final float density;
    private final Paint gutterTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gutterBgPaint = new Paint();
    private final Paint gutterLinePaint = new Paint();
    private final Paint matchPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint currentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tmpPath = new Path();
    private final int gutterNumColor;
    private final int gutterCurColor;
    private final int[] tokenColors = new int[9];

    private boolean showLineNumbers = true;
    private boolean highlightEnabled = true;
    private boolean readOnly = false;
    private boolean wrapOff = true;
    private boolean autoComplete = true;
    private int pendingCursor = -1;
    private int lastStart, lastBefore, lastCount;
    private String lastRemoved = "";
    private boolean pendingAuto = false;
    private boolean autoIndent = true;
    private int language = SyntaxHighlighter.LANG_NONE;
    private int gutterWidth = 0;
    private int lastDigits = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Object> appliedSpans = new ArrayList<>();
    private final Runnable highlightRunnable = this::applyHighlight;
    private final Runnable gutterRunnable = this::updateGutterWidth;
    private CursorListener cursorListener;

    // cari
    private int[] matchStart = new int[0];
    private int[] matchEnd = new int[0];
    private int matchCount = 0;
    private int currentMatch = -1;

    // undo / redo
    private static final class Edit {
        int start;
        String before;
        String after;
        long time;
    }

    private final ArrayList<Edit> undoStack = new ArrayList<>();
    private final ArrayList<Edit> redoStack = new ArrayList<>();
    private long undoChars = 0;
    private boolean applying = false;
    private int pendingStart;
    private String pendingBefore = "";

    public CodeEditText(Context context) {
        this(context, null);
    }

    public CodeEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = getResources().getDisplayMetrics().density;
        gutterNumColor = ContextCompat.getColor(context, R.color.text_faint);
        gutterCurColor = Palette.accent(context);
        gutterBgPaint.setColor(ContextCompat.getColor(context, R.color.bg_surface));
        gutterLinePaint.setColor(ContextCompat.getColor(context, R.color.divider));
        gutterTextPaint.setTypeface(getTypeface());
        gutterTextPaint.setTextAlign(Paint.Align.RIGHT);
        matchPaint.setColor(ContextCompat.getColor(context, R.color.match_bg));
        currentPaint.setColor((Palette.accent(context) & 0x00FFFFFF) | 0x88000000);

        boolean dark = (getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        int accentSyn = Palette.accentForSyntax(context, dark);
        tokenColors[SyntaxHighlighter.T_COMMENT] = ContextCompat.getColor(context, R.color.syn_comment);
        tokenColors[SyntaxHighlighter.T_STRING] = ContextCompat.getColor(context, R.color.syn_string);
        tokenColors[SyntaxHighlighter.T_KEYWORD] = accentSyn;
        tokenColors[SyntaxHighlighter.T_NUMBER] = ContextCompat.getColor(context, R.color.syn_number);
        tokenColors[SyntaxHighlighter.T_FUNCTION] = ContextCompat.getColor(context, R.color.syn_function);
        tokenColors[SyntaxHighlighter.T_TAG] = accentSyn;
        tokenColors[SyntaxHighlighter.T_ATTR] = ContextCompat.getColor(context, R.color.syn_attr);
        tokenColors[SyntaxHighlighter.T_PROPERTY] = ContextCompat.getColor(context, R.color.syn_attr);
        tokenColors[SyntaxHighlighter.T_ATRULE] = accentSyn;

        setHorizontallyScrolling(true);
        syncGutterTextSize();

        addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (applying) return;
                pendingStart = start;
                pendingBefore = count == 0 ? "" : s.subSequence(start, start + count).toString();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (applying) return;
                String added = count == 0 ? "" : s.subSequence(start, start + count).toString();
                recordEdit(pendingStart, pendingBefore, added);
                lastStart = start;
                lastBefore = before;
                lastCount = count;
                lastRemoved = pendingBefore;
                pendingAuto = true;
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (pendingAuto) {
                    pendingAuto = false;
                    runAutoEdit();
                }
                handler.removeCallbacks(gutterRunnable);
                handler.postDelayed(gutterRunnable, 120);
                scheduleHighlight();
                if (matchCount > 0) clearSearch();
            }
        });

        // Indentasi otomatis saat Enter (dan baris kosong ber-indentasi di antara { } ( ) [ ] atau <tag></tag>)
        setFilters(new InputFilter[]{(source, start, end, dest, dstart, dend) -> {
            if (readOnly) return dest.subSequence(dstart, dend);
            if (!autoIndent || applying || end - start != 1 || source.charAt(start) != '\n') return null;
            int ls = dstart;
            while (ls > 0 && dest.charAt(ls - 1) != '\n') ls--;
            int p = ls;
            while (p < dstart && (dest.charAt(p) == ' ' || dest.charAt(p) == '\t')) p++;
            String indent = dest.subSequence(ls, p).toString();
            char before = dstart > 0 ? dest.charAt(dstart - 1) : '\0';
            char after = dend < dest.length() ? dest.charAt(dend) : '\0';
            boolean between = (before == '{' && after == '}') || (before == '(' && after == ')')
                    || (before == '[' && after == ']')
                    || (language == SyntaxHighlighter.LANG_HTML && before == '>' && after == '<');
            if (between && autoComplete) {
                pendingCursor = dstart + 1 + indent.length() + 2;
                handler.post(() -> {
                    if (pendingCursor >= 0 && pendingCursor <= getText().length()) setSelection(pendingCursor);
                    pendingCursor = -1;
                });
                return "\n" + indent + "  \n" + indent;
            }
            StringBuilder sb = new StringBuilder("\n");
            sb.append(indent);
            int q = dstart - 1;
            while (q >= ls && dest.charAt(q) == ' ') q--;
            if (q >= ls) {
                char pc = dest.charAt(q);
                if (pc == '{' || pc == '(' || pc == '[') sb.append("  ");
            }
            return sb.toString();
        }});
    }

    // ------------------------------------------------------------------ pengaturan

    public void setCursorListener(CursorListener l) {
        cursorListener = l;
    }

    public void setLanguage(int lang) {
        language = lang;
        scheduleHighlight();
    }

    public void setReadOnly(boolean ro) {
        readOnly = ro;
        setShowSoftInputOnFocus(!ro);
    }

    public void setShowLineNumbers(boolean show) {
        showLineNumbers = show;
        lastDigits = 0;
        updateGutterWidth();
        invalidate();
    }

    public boolean isShowLineNumbers() {
        return showLineNumbers;
    }

    public void setHighlightEnabled(boolean on) {
        highlightEnabled = on;
        scheduleHighlight();
    }

    public boolean isHighlightEnabled() {
        return highlightEnabled;
    }

    public void setWordWrap(boolean wrap) {
        wrapOff = !wrap;
        setHorizontallyScrolling(wrapOff);
        scrollTo(0, getScrollY());
        invalidate();
    }

    public void setEditorTextSize(float sp) {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        syncGutterTextSize();
        lastDigits = 0;
        updateGutterWidth();
    }

    private void syncGutterTextSize() {
        gutterTextPaint.setTextSize(getTextSize() * 0.85f);
    }

    /** Mengisi teks tanpa dicatat ke riwayat undo (muat draf / berkas). */
    public void loadText(CharSequence text) {
        applying = true;
        setText(text);
        applying = false;
        undoStack.clear();
        redoStack.clear();
        undoChars = 0;
        clearSearch();
        lastDigits = 0;
        updateGutterWidth();
        scheduleHighlight();
    }

    // ------------------------------------------------------------------ nomor baris

    private void updateGutterWidth() {
        int target = 0;
        if (showLineNumbers) {
            int lines = Math.max(1, getLineCount());
            int digits = Math.max(2, String.valueOf(lines).length());
            if (digits == lastDigits && gutterWidth > 0) return;
            lastDigits = digits;
            target = (int) (gutterTextPaint.measureText("0") * digits + 16 * density);
        } else {
            lastDigits = 0;
        }
        if (target != gutterWidth) {
            gutterWidth = target;
            int pad = (int) (12 * density);
            setPadding(gutterWidth + (gutterWidth > 0 ? (int) (8 * density) : pad), pad, pad, pad);
        }
    }

    private int logicalLineAt(Layout layout, int visualLine) {
        int offset = layout.getLineStart(visualLine);
        CharSequence t = getText();
        int count = 0;
        for (int i = 0; i < offset && i < t.length(); i++) {
            if (t.charAt(i) == '\n') count++;
        }
        return count + 1;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Layout layout = getLayout();
        if (layout == null) return;

        drawMatches(canvas, layout);

        if (!showLineNumbers || gutterWidth == 0) return;
        int sx = getScrollX();
        int sy = getScrollY();
        int h = getHeight();
        canvas.drawRect(sx, sy, sx + gutterWidth, sy + h, gutterBgPaint);
        canvas.drawRect(sx + gutterWidth - density, sy, sx + gutterWidth, sy + h, gutterLinePaint);

        int top = getExtendedPaddingTop();
        int first = layout.getLineForVertical(Math.max(0, sy - top));
        int last = layout.getLineForVertical(sy + h - top);
        boolean wrapped = !wrapOff;
        int curLine = layout.getLineForOffset(Math.max(0, getSelectionStart()));
        int logical = wrapped ? logicalLineAt(layout, first) : first + 1;
        CharSequence text = getText();
        for (int i = first; i <= last && i < layout.getLineCount(); i++) {
            int start = layout.getLineStart(i);
            boolean isStart = i == 0 || !wrapped || (start > 0 && text.charAt(start - 1) == '\n');
            if (wrapped && i > first && isStart) logical++;
            if (isStart) {
                gutterTextPaint.setColor(i == curLine ? gutterCurColor : gutterNumColor);
                float y = top + layout.getLineBaseline(i);
                canvas.drawText(String.valueOf(wrapped ? logical : i + 1), sx + gutterWidth - 8 * density, y, gutterTextPaint);
            }
        }
    }


    // ------------------------------------------------------------------ cari / ganti

    private void drawMatches(Canvas canvas, Layout layout) {
        if (matchCount == 0) return;
        int top = getExtendedPaddingTop();
        int firstLine = layout.getLineForVertical(Math.max(0, getScrollY() - top));
        int lastLine = layout.getLineForVertical(getScrollY() + getHeight() - top);
        int visStart = layout.getLineStart(firstLine);
        int visEnd = layout.getLineEnd(Math.min(lastLine, layout.getLineCount() - 1));

        // cari biner posisi awal
        int lo = 0, hi = matchCount - 1, idx = matchCount;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (matchEnd[mid] >= visStart) {
                idx = mid;
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        }
        canvas.save();
        canvas.translate(getCompoundPaddingLeft(), top);
        for (int i = idx; i < matchCount && matchStart[i] <= visEnd; i++) {
            tmpPath.reset();
            layout.getSelectionPath(matchStart[i], matchEnd[i], tmpPath);
            canvas.drawPath(tmpPath, i == currentMatch ? currentPaint : matchPaint);
        }
        canvas.restore();
    }

    /** @return jumlah hasil. Memilih hasil pertama pada/sesudah kursor. */
    public int findAll(String query, boolean matchCase, boolean regex) throws PatternSyntaxException {
        matchCount = 0;
        currentMatch = -1;
        if (query == null || query.isEmpty()) {
            invalidate();
            return 0;
        }
        int flags = matchCase ? 0 : (Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        Pattern p = Pattern.compile(regex ? query : Pattern.quote(query), flags | (regex ? Pattern.MULTILINE : 0));
        Matcher m = p.matcher(getText().toString());
        int[] ms = new int[256];
        int[] me = new int[256];
        int n = 0;
        while (m.find() && n < MAX_MATCHES) {
            if (m.end() == m.start()) continue;
            if (n == ms.length) {
                ms = java.util.Arrays.copyOf(ms, n * 2);
                me = java.util.Arrays.copyOf(me, n * 2);
            }
            ms[n] = m.start();
            me[n] = m.end();
            n++;
        }
        matchStart = ms;
        matchEnd = me;
        matchCount = n;
        if (n > 0) {
            int cursor = Math.max(0, getSelectionStart());
            int pick = 0;
            for (int i = 0; i < n; i++) {
                if (matchStart[i] >= cursor) {
                    pick = i;
                    break;
                }
            }
            goToMatch(pick);
        } else {
            invalidate();
        }
        return n;
    }

    public int getMatchCount() {
        return matchCount;
    }

    public int getCurrentMatch() {
        return currentMatch;
    }

    public void goToMatch(int index) {
        if (matchCount == 0) return;
        currentMatch = ((index % matchCount) + matchCount) % matchCount;
        revealOffset(matchStart[currentMatch]);
        invalidate();
    }

    public void nextMatch() {
        goToMatch(currentMatch + 1);
    }

    public void prevMatch() {
        goToMatch(currentMatch - 1);
    }

    public void clearSearch() {
        if (matchCount == 0 && currentMatch == -1) return;
        matchCount = 0;
        currentMatch = -1;
        invalidate();
    }

    /** Mengganti hasil yang sedang dipilih. @return true bila ada yang diganti. */
    public boolean replaceCurrent(String replacement) {
        if (currentMatch < 0 || currentMatch >= matchCount) return false;
        int s = matchStart[currentMatch];
        int e = matchEnd[currentMatch];
        getText().replace(s, e, replacement);
        setSelection(s + replacement.length());
        return true;
    }

    /** Mengganti semua hasil; dicatat sebagai satu langkah undo. @return jumlah diganti. */
    public int replaceAll(String query, String replacement, boolean matchCase, boolean regex)
            throws PatternSyntaxException, IllegalArgumentException {
        int flags = matchCase ? 0 : (Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        Pattern p = Pattern.compile(regex ? query : Pattern.quote(query), flags | (regex ? Pattern.MULTILINE : 0));
        String old = getText().toString();
        Matcher m = p.matcher(old);
        String rep = regex ? replacement : Matcher.quoteReplacement(replacement);
        StringBuffer sb = new StringBuffer(old.length());
        int count = 0;
        while (m.find()) {
            if (m.end() == m.start()) continue;
            m.appendReplacement(sb, rep);
            count++;
        }
        if (count == 0) return 0;
        m.appendTail(sb);
        replaceWholeText(sb.toString());
        return count;
    }

    // ------------------------------------------------------------------ undo / redo

    private void recordEdit(int start, String before, String after) {
        if (before.isEmpty() && after.isEmpty()) return;
        long now = System.currentTimeMillis();
        redoStack.clear();
        if (!undoStack.isEmpty()) {
            Edit last = undoStack.get(undoStack.size() - 1);
            boolean recent = now - last.time < 1000;
            if (recent && before.isEmpty() && last.before.isEmpty() && after.indexOf('\n') < 0
                    && last.after.indexOf('\n') < 0 && start == last.start + last.after.length()
                    && last.after.length() < 200) {
                last.after = last.after + after;
                last.time = now;
                undoChars += after.length();
                return;
            }
            if (recent && after.isEmpty() && last.after.isEmpty() && start + before.length() == last.start
                    && last.before.length() < 200) {
                last.start = start;
                last.before = before + last.before;
                last.time = now;
                undoChars += before.length();
                return;
            }
        }
        Edit e = new Edit();
        e.start = start;
        e.before = before;
        e.after = after;
        e.time = now;
        undoStack.add(e);
        undoChars += before.length() + after.length();
        while ((undoStack.size() > 500 || undoChars > MAX_UNDO_CHARS) && undoStack.size() > 1) {
            Edit old = undoStack.remove(0);
            undoChars -= old.before.length() + old.after.length();
        }
    }

    public boolean canUndo() {
        return !undoStack.isEmpty();
    }

    public boolean canRedo() {
        return !redoStack.isEmpty();
    }

    public void undo() {
        if (undoStack.isEmpty()) return;
        Edit e = undoStack.remove(undoStack.size() - 1);
        undoChars -= e.before.length() + e.after.length();
        applying = true;
        getText().replace(e.start, e.start + e.after.length(), e.before);
        setSelection(Math.min(getText().length(), e.start + e.before.length()));
        applying = false;
        redoStack.add(e);
        revealOffset(getSelectionStart());
    }

    public void redo() {
        if (redoStack.isEmpty()) return;
        Edit e = redoStack.remove(redoStack.size() - 1);
        applying = true;
        getText().replace(e.start, e.start + e.before.length(), e.after);
        setSelection(Math.min(getText().length(), e.start + e.after.length()));
        applying = false;
        undoStack.add(e);
        undoChars += e.before.length() + e.after.length();
        revealOffset(getSelectionStart());
    }

    /** Mengganti seluruh teks sebagai satu langkah undo (format, ganti semua). */
    public void replaceWholeText(String newText) {
        String old = getText().toString();
        if (old.equals(newText)) return;
        int sel = Math.min(getSelectionStart(), newText.length());
        applying = true;
        setText(newText);
        applying = false;
        Edit e = new Edit();
        e.start = 0;
        e.before = old;
        e.after = newText;
        e.time = 0;
        redoStack.clear();
        undoStack.add(e);
        undoChars += old.length() + newText.length();
        while ((undoStack.size() > 500 || undoChars > MAX_UNDO_CHARS) && undoStack.size() > 1) {
            Edit o = undoStack.remove(0);
            undoChars -= o.before.length() + o.after.length();
        }
        setSelection(Math.max(0, sel));
        lastDigits = 0;
        updateGutterWidth();
    }

    // ------------------------------------------------------------------ navigasi

    public void revealOffset(int offset) {
        Layout l = getLayout();
        if (l == null) return;
        offset = Math.max(0, Math.min(offset, getText().length()));
        int line = l.getLineForOffset(offset);
        int viewH = getHeight() - getExtendedPaddingTop() - getExtendedPaddingBottom();
        int target = l.getLineTop(line) - viewH / 3;
        int max = Math.max(0, l.getHeight() + getExtendedPaddingTop() + getExtendedPaddingBottom() - getHeight());
        scrollTo(getScrollX(), Math.max(0, Math.min(target, max)));
        if (!wrapOff) return;
        float x = l.getPrimaryHorizontal(offset);
        int visW = getWidth() - getCompoundPaddingLeft() - getCompoundPaddingRight();
        if (x < getScrollX() || x > getScrollX() + visW) {
            scrollTo(Math.max(0, (int) x - visW / 3), getScrollY());
        }
    }

    public int lineCountLogical() {
        CharSequence t = getText();
        int c = 1;
        for (int i = 0; i < t.length(); i++) if (t.charAt(i) == '\n') c++;
        return c;
    }

    public void goToLine(int line) {
        CharSequence t = getText();
        int offset = 0;
        int cur = 1;
        while (cur < line && offset < t.length()) {
            if (t.charAt(offset) == '\n') cur++;
            offset++;
        }
        setSelection(Math.min(offset, t.length()));
        revealOffset(offset);
    }

    /** Baris (mulai 1) dan kolom (mulai 1) kursor. */
    public int[] cursorLineCol() {
        CharSequence t = getText();
        int sel = Math.max(0, Math.min(getSelectionStart(), t.length()));
        int line = 1;
        int lineStart = 0;
        for (int i = 0; i < sel; i++) {
            if (t.charAt(i) == '\n') {
                line++;
                lineStart = i + 1;
            }
        }
        return new int[]{line, sel - lineStart + 1};
    }

    @Override
    protected void onSelectionChanged(int selStart, int selEnd) {
        super.onSelectionChanged(selStart, selEnd);
        if (cursorListener != null) cursorListener.onCursorChanged();
        if (showLineNumbers) invalidate();
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        scheduleHighlight();
    }

    // ------------------------------------------------------------------ operasi baris

    private int lineStartOf(int offset) {
        CharSequence t = getText();
        int i = Math.min(offset, t.length());
        while (i > 0 && t.charAt(i - 1) != '\n') i--;
        return i;
    }

    private int lineEndOf(int offset) {
        CharSequence t = getText();
        int i = Math.max(0, offset);
        while (i < t.length() && t.charAt(i) != '\n') i++;
        return i;
    }

    private int[] selectedLinesRange() {
        int s = Math.max(0, Math.min(getSelectionStart(), getSelectionEnd()));
        int e = Math.max(0, Math.max(getSelectionStart(), getSelectionEnd()));
        int ls = lineStartOf(s);
        int le = lineEndOf(e > s && e > 0 && getText().charAt(e - 1) == '\n' ? e - 1 : e);
        return new int[]{ls, le};
    }

    public void duplicateLines() {
        int[] r = selectedLinesRange();
        String block = getText().subSequence(r[0], r[1]).toString();
        getText().insert(r[1], "\n" + block);
        setSelection(r[1] + 1 + block.length());
    }

    public void deleteLines() {
        int[] r = selectedLinesRange();
        Editable t = getText();
        int end = r[1] < t.length() ? r[1] + 1 : r[1];
        int start = r[0];
        if (end == r[1] && start > 0) start--;   // baris terakhir: hapus pemisah sebelumnya
        t.delete(start, end);
        setSelection(Math.min(start, t.length()));
    }

    public void moveLines(boolean up) {
        int[] r = selectedLinesRange();
        Editable t = getText();
        if (up) {
            if (r[0] == 0) return;
            int ps = lineStartOf(r[0] - 1);
            String prev = t.subSequence(ps, r[0] - 1).toString();
            String block = t.subSequence(r[0], r[1]).toString();
            t.replace(ps, r[1], block + "\n" + prev);
            setSelection(ps, ps + block.length());
        } else {
            if (r[1] >= t.length()) return;
            int ne = lineEndOf(r[1] + 1);
            String next = t.subSequence(r[1] + 1, ne).toString();
            String block = t.subSequence(r[0], r[1]).toString();
            t.replace(r[0], ne, next + "\n" + block);
            int bs = r[0] + next.length() + 1;
            setSelection(bs, bs + block.length());
        }
    }

    public void indentLines(boolean indent) {
        int[] r = selectedLinesRange();
        Editable t = getText();
        String block = t.subSequence(r[0], r[1]).toString();
        String[] lines = block.split("\n", -1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            if (indent) {
                l = l.isEmpty() ? l : "  " + l;
            } else if (l.startsWith("  ")) {
                l = l.substring(2);
            } else if (l.startsWith("\t") || l.startsWith(" ")) {
                l = l.substring(1);
            }
            if (i > 0) sb.append('\n');
            sb.append(l);
        }
        t.replace(r[0], r[1], sb.toString());
        setSelection(r[0], r[0] + sb.length());
    }

    public void toggleComment() {
        String open;
        String close;
        switch (language) {
            case SyntaxHighlighter.LANG_HTML:
                open = "<!-- ";
                close = " -->";
                break;
            case SyntaxHighlighter.LANG_CSS:
                open = "/* ";
                close = " */";
                break;
            default:
                open = "// ";
                close = "";
        }
        int[] r = selectedLinesRange();
        Editable t = getText();
        String[] lines = t.subSequence(r[0], r[1]).toString().split("\n", -1);
        boolean allCommented = true;
        for (String l : lines) {
            String tr = l.trim();
            if (tr.isEmpty()) continue;
            if (!tr.startsWith(open.trim()) || (!close.isEmpty() && !tr.endsWith(close.trim()))) {
                allCommented = false;
                break;
            }
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            if (i > 0) sb.append('\n');
            if (l.trim().isEmpty()) {
                sb.append(l);
                continue;
            }
            int lead = 0;
            while (lead < l.length() && (l.charAt(lead) == ' ' || l.charAt(lead) == '\t')) lead++;
            String body = l.substring(lead);
            if (allCommented) {
                if (body.startsWith(open)) body = body.substring(open.length());
                else if (body.startsWith(open.trim())) body = body.substring(open.trim().length());
                if (!close.isEmpty()) {
                    if (body.endsWith(close)) body = body.substring(0, body.length() - close.length());
                    else if (body.endsWith(close.trim())) body = body.substring(0, body.length() - close.trim().length());
                }
                sb.append(l, 0, lead).append(body);
            } else {
                sb.append(l, 0, lead).append(open).append(body).append(close);
            }
        }
        t.replace(r[0], r[1], sb.toString());
        setSelection(r[0], r[0] + sb.length());
    }

    /** Menyisipkan teks pada kursor / menggantikan pilihan. */
    public void insertAtCursor(String s) {
        int a = Math.max(0, Math.min(getSelectionStart(), getSelectionEnd()));
        int b = Math.max(0, Math.max(getSelectionStart(), getSelectionEnd()));
        getText().replace(a, b, s);
    }

    public void moveCursor(int delta) {
        int pos = Math.max(0, Math.min(getText().length(), getSelectionStart() + delta));
        setSelection(pos);
    }


    // ------------------------------------------------------------------ auto-complete

    private static final java.util.regex.Pattern TAG_NAME = java.util.regex.Pattern.compile("^[A-Za-z][\\w:-]*");
    private static final java.util.regex.Pattern TAG_SCAN = java.util.regex.Pattern.compile(
            "<!--[\\s\\S]*?-->|<(/?)([A-Za-z][\\w:-]*)(?:\"[^\"]*\"|'[^']*'|[^<>\"'])*?(/?)>");
    private static final java.util.Set<String> VOID_TAGS = new java.util.HashSet<>(java.util.Arrays.asList(
            "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param",
            "source", "track", "wbr"));

    public void setAutoComplete(boolean on) {
        autoComplete = on;
    }

    private static String pairOf(char c) {
        switch (c) {
            case '{': return "}";
            case '(': return ")";
            case '[': return "]";
            case '"': return "\"";
            case '\'': return "'";
            case '`': return "`";
            default: return null;
        }
    }

    private void runAutoEdit() {
        if (readOnly || !autoComplete || applying) return;
        Editable e = getText();
        int len = e.length();
        int p = lastStart;
        if (lastBefore == 0 && lastCount == 1 && p < len) {
            char c = e.charAt(p);
            char next = p + 1 < len ? e.charAt(p + 1) : '\0';
            char prev = p > 0 ? e.charAt(p - 1) : '\0';

            // 1) mengetik penutup yang sudah ada di depan kursor: cukup lompati
            if ((c == '}' || c == ')' || c == ']' || c == '"' || c == '\'' || c == '`') && next == c) {
                applying = true;
                e.delete(p, p + 1);
                applying = false;
                dropLastTypedChar(c);
                setSelection(p + 1);
                return;
            }

            // 2) penutup pasangan otomatis: { } ( ) [ ] " ' `
            String closer = pairOf(c);
            if (closer != null && !closer.equals(String.valueOf(c))) {
                // kurung: selalu boleh bila setelahnya kosong/penutup/spasi
            } else if (closer != null) {
                // tanda kutip: jangan di tengah kata (mis. don't) atau setelah garis miring
                if (Character.isLetterOrDigit(prev) || prev == c || prev == '\\') closer = null;
            }
            if (closer != null && (next == '\0' || Character.isWhitespace(next)
                    || ")]},;:>/<".indexOf(next) >= 0)) {
                autoInsert(p + 1, closer, p + 1);
                return;
            }

            // 3) khusus HTML: tag penutup, </ + nama, dan komentar
            if (language == SyntaxHighlighter.LANG_HTML) {
                if (c == '>') {
                    autoCloseTag(e, p);
                } else if (c == '/' && prev == '<') {
                    autoCompleteClosingTag(e, p);
                } else if (c == '-' && p >= 3 && "<!--".contentEquals(e.subSequence(p - 3, p + 1))
                        && !(p + 3 < len && "-->".contentEquals(e.subSequence(p + 1, p + 4)))) {
                    autoInsert(p + 1, "-->", p + 1);
                }
            }
        } else if (lastBefore == 1 && lastCount == 0 && lastRemoved.length() == 1 && p < len) {
            // Backspace pada pasangan kosong: hapus penutupnya juga
            String pair = pairOf(lastRemoved.charAt(0));
            if (pair != null && e.charAt(p) == pair.charAt(0)) {
                applying = true;
                e.delete(p, p + 1);
                applying = false;
                patchUndoRemoved(pair);
                setSelection(p);
            }
        }
    }

    private void autoInsert(int pos, String text, int cursor) {
        applying = true;
        getText().insert(pos, text);
        applying = false;
        patchUndoAppended(pos, text);
        setSelection(Math.min(cursor, getText().length()));
    }

    private void patchUndoAppended(int pos, String text) {
        if (undoStack.isEmpty()) return;
        Edit last = undoStack.get(undoStack.size() - 1);
        if (last.start + last.after.length() == pos) {
            last.after = last.after + text;
            undoChars += text.length();
        }
    }

    private void patchUndoRemoved(String removedAfter) {
        if (undoStack.isEmpty()) return;
        Edit last = undoStack.get(undoStack.size() - 1);
        last.before = last.before + removedAfter;
        undoChars += removedAfter.length();
    }

    private void dropLastTypedChar(char c) {
        if (undoStack.isEmpty()) return;
        Edit last = undoStack.get(undoStack.size() - 1);
        if (last.after.length() > 0 && last.after.charAt(last.after.length() - 1) == c) {
            last.after = last.after.substring(0, last.after.length() - 1);
            undoChars -= 1;
            if (last.before.isEmpty() && last.after.isEmpty()) undoStack.remove(undoStack.size() - 1);
        }
    }

    private void autoCloseTag(Editable e, int p) {
        int limit = Math.max(0, p - 400);
        int i = p - 1;
        while (i >= limit && e.charAt(i) != '<' && e.charAt(i) != '>') i--;
        if (i < limit || e.charAt(i) != '<') return;
        String inner = e.subSequence(i + 1, p).toString();
        if (inner.isEmpty() || inner.startsWith("/") || inner.startsWith("!") || inner.startsWith("?")
                || inner.endsWith("/")) return;
        Matcher nm = TAG_NAME.matcher(inner);
        if (!nm.find()) return;
        String name = nm.group();
        String lowName = name.toLowerCase(java.util.Locale.ROOT);
        if (VOID_TAGS.contains(lowName) || lowName.equals("doctype")) return;   // <DOCTYPE ...> bukan tag berpasangan
        String closing = "</" + name + ">";
        int end = Math.min(e.length(), p + 1 + closing.length());
        if (closing.equalsIgnoreCase(e.subSequence(p + 1, end).toString())) return;
        autoInsert(p + 1, closing, p + 1);
    }

    private void autoCompleteClosingTag(Editable e, int p) {
        int from = Math.max(0, p - 1 - 40000);
        String before = e.subSequence(from, p - 1).toString();
        java.util.ArrayList<String> stack = new java.util.ArrayList<>();
        Matcher m = TAG_SCAN.matcher(before);
        while (m.find()) {
            if (m.group(2) == null) continue;           // komentar
            String name = m.group(2);
            String low = name.toLowerCase(java.util.Locale.ROOT);
            boolean closing = "/".equals(m.group(1));
            boolean selfClose = "/".equals(m.group(3));
            if (closing) {
                for (int k = stack.size() - 1; k >= 0; k--) {
                    if (stack.get(k).equalsIgnoreCase(name)) {
                        while (stack.size() > k) stack.remove(stack.size() - 1);
                        break;
                    }
                }
            } else if (!selfClose && !VOID_TAGS.contains(low)) {
                stack.add(name);
            }
        }
        if (stack.isEmpty()) return;
        String name = stack.get(stack.size() - 1);
        if (p + 1 < e.length() && e.charAt(p + 1) == '>') {
            autoInsert(p + 1, name, p + 1 + name.length());
        } else {
            autoInsert(p + 1, name + ">", p + 1 + name.length() + 1);
        }
    }

    // ------------------------------------------------------------------ pewarna sintaks

    private void scheduleHighlight() {
        handler.removeCallbacks(highlightRunnable);
        handler.postDelayed(highlightRunnable, 90);
    }

    private void clearSpans(Editable e) {
        for (Object o : appliedSpans) e.removeSpan(o);
        appliedSpans.clear();
    }

    private void applyHighlight() {
        Editable e = getText();
        Layout layout = getLayout();
        if (e == null) return;
        clearSpans(e);
        if (!highlightEnabled || language == SyntaxHighlighter.LANG_NONE || layout == null || e.length() == 0) return;

        int top = getExtendedPaddingTop();
        int first = Math.max(0, layout.getLineForVertical(Math.max(0, getScrollY() - top)) - HIGHLIGHT_MARGIN_LINES);
        int last = Math.min(layout.getLineCount() - 1,
                layout.getLineForVertical(getScrollY() + getHeight() - top) + HIGHLIGHT_MARGIN_LINES);
        int from = layout.getLineStart(first);
        int to = Math.min(e.length(), layout.getLineEnd(last));
        if (to <= from) return;

        String window = e.subSequence(from, to).toString();
        List<int[]> tokens = SyntaxHighlighter.scan(language, window);
        for (int[] t : tokens) {
            ForegroundColorSpan span = new ForegroundColorSpan(tokenColors[t[2]]);
            e.setSpan(span, from + t[0], from + t[1], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            appliedSpans.add(span);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
