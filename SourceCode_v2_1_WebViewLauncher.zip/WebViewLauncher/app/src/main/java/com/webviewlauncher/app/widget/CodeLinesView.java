package com.webviewlauncher.app.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.OverScroller;

import androidx.core.content.ContextCompat;

import com.webviewlauncher.app.R;
import com.webviewlauncher.app.theme.Palette;
import com.webviewlauncher.app.util.SyntaxColors;
import com.webviewlauncher.app.util.SyntaxHighlighter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Penampil kode baca-saja yang digambar langsung di kanvas dan hanya memproses baris yang
 * terlihat, sehingga file puluhan ribu baris tetap mulus: tidak ada layout teks raksasa, gulir
 * vertikal dengan fling, penggeser cepat di tepi kanan, nomor baris, dan pewarna sintaks.
 * Tidak bisa digeser ke samping: baris yang melebihi lebar layar otomatis turun ke bawah (soft wrap)
 * tanpa menjadi baris baru, jadi nomor baris hanya muncul di potongan pertama.
 * Ketuk lama pada sebuah baris untuk menyalinnya.
 */
public class CodeLinesView extends View {

    public interface LineListener {
        void onLineLongPress(int lineIndex, String text);
    }

    private static final int WINDOW_MARGIN = 40;
    private static final int MAX_HIGHLIGHT_CHARS = 200_000;

    private final float density;
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gutterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint();
    private final int colText, colBg, colGutterBg, colGutterNum, colDivider, colAccent;
    private final int[] tokenColors;

    private String[] lines = new String[0];
    private int language = SyntaxHighlighter.LANG_NONE;
    private float charW;
    private float lineH;
    private float baseline;
    private float gutterW;
    private float scrollY = 0f;
    /** Jumlah karakter per baris tampilan (font monospace, jadi tetap). */
    private int cols = 80;
    /** rowOff[i] = indeks baris tampilan pertama dari baris kode i; rowOff[lines.length] = total. */
    private int[] rowOff = new int[]{0};
    private int markedLine = -1;

    private final OverScroller scroller;
    private final GestureDetector detector;
    private boolean draggingThumb = false;
    private LineListener lineListener;

    // cache pewarna sintaks untuk jendela baris [cacheFrom, cacheTo]
    private int cacheFrom = -1;
    private int cacheTo = -2;
    private List<int[]>[] cacheTokens;

    @SuppressWarnings("unchecked")
    public CodeLinesView(Context c) {
        this(c, null);
    }

    public CodeLinesView(Context c, AttributeSet a) {
        super(c, a);
        density = getResources().getDisplayMetrics().density;
        colText = ContextCompat.getColor(c, R.color.text_primary);
        colBg = ContextCompat.getColor(c, R.color.bg_root);
        colGutterBg = ContextCompat.getColor(c, R.color.bg_surface);
        colGutterNum = ContextCompat.getColor(c, R.color.text_faint);
        colDivider = ContextCompat.getColor(c, R.color.divider);
        colAccent = Palette.accent(c);
        tokenColors = SyntaxColors.forContext(c);

        textPaint.setTypeface(Typeface.MONOSPACE);
        gutterPaint.setTypeface(Typeface.MONOSPACE);
        gutterPaint.setTextAlign(Paint.Align.RIGHT);
        setTextSizeSp(13f);

        scroller = new OverScroller(c);
        detector = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                scroller.forceFinished(true);
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                scrollBy(dx, dy);
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                scroller.fling(0, (int) scrollY, 0, (int) -vy, 0, 0, 0, (int) maxScrollY());
                postInvalidateOnAnimation();
                return true;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                int idx = lineOfRow((int) ((e.getY() + scrollY) / lineH));
                if (lineListener != null && idx >= 0 && idx < lines.length) {
                    lineListener.onLineLongPress(idx, lines[idx]);
                }
            }
        });
    }

    public void setLineListener(LineListener l) {
        lineListener = l;
    }

    public void setTextSizeSp(float sp) {
        float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, getResources().getDisplayMetrics());
        textPaint.setTextSize(px);
        gutterPaint.setTextSize(px * 0.85f);
        charW = textPaint.measureText("0");
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        lineH = fm.descent - fm.ascent + 3f * density;
        baseline = -fm.ascent + 1.5f * density;
        recomputeMetrics();
        invalidate();
    }

    /** @param newLines baris-baris kode (tanpa \n; tab sudah diganti spasi). */
    public void setLines(String[] newLines, int lang) {
        lines = newLines;
        language = lang;
        cacheFrom = -1;
        cacheTo = -2;
        scrollY = 0f;
        markedLine = -1;
        recomputeMetrics();
        invalidate();
    }

    public int getLineCount() {
        return lines.length;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        recomputeMetrics();
    }

    /** Menghitung lebar gutter, jumlah kolom per baris tampilan, dan awal baris tampilan tiap baris kode. */
    private void recomputeMetrics() {
        int digits = Math.max(2, String.valueOf(Math.max(1, lines.length)).length());
        gutterW = digits * charW * 0.85f + 20f * density;
        int w = getWidth();
        float avail = w - gutterW - 24f * density;
        cols = w <= 0 ? 80 : Math.max(1, (int) (avail / charW));
        if (rowOff.length != lines.length + 1) rowOff = new int[lines.length + 1];
        int acc = 0;
        for (int i = 0; i < lines.length; i++) {
            rowOff[i] = acc;
            int len = lines[i].length();
            acc += Math.max(1, (len + cols - 1) / cols);
        }
        rowOff[lines.length] = acc;
        scrollY = Math.max(0f, Math.min(maxScrollY(), scrollY));
        cacheFrom = -1;
        cacheTo = -2;
    }

    /** Baris kode yang memuat baris tampilan ke-r. */
    private int lineOfRow(int r) {
        if (lines.length == 0) return 0;
        int lo = 0, hi = lines.length - 1;
        while (lo < hi) {
            int mid = (lo + hi + 1) >>> 1;
            if (rowOff[mid] <= r) lo = mid;
            else hi = mid - 1;
        }
        return lo;
    }

    private float totalHeight() {
        return rowOff[lines.length] * lineH + 24f * density;
    }

    private float maxScrollY() {
        return Math.max(0f, totalHeight() - getHeight());
    }

    public void scrollBy(float dx, float dy) {
        scrollY = Math.max(0f, Math.min(maxScrollY(), scrollY + dy));
        postInvalidateOnAnimation();
    }

    /** Menggulir halus ke baris n (mulai 1) dan menandainya. */
    public void goToLine(int n) {
        if (lines.length == 0) return;
        int idx = Math.max(0, Math.min(lines.length - 1, n - 1));
        markedLine = idx;
        float target = Math.max(0f, Math.min(maxScrollY(), rowOff[idx] * lineH - getHeight() / 3f));
        scroller.forceFinished(true);
        scroller.startScroll(0, (int) scrollY, 0, (int) (target - scrollY), 350);
        postInvalidateOnAnimation();
    }

    @Override
    public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollY = scroller.getCurrY();
            postInvalidateOnAnimation();
        }
    }

    // ------------------------------------------------------------------ sentuhan

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float thumbZone = getWidth() - 30f * density;
        if (e.getAction() == MotionEvent.ACTION_DOWN && e.getX() > thumbZone && totalHeight() > getHeight()) {
            draggingThumb = true;
            scroller.forceFinished(true);
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        if (draggingThumb) {
            if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                draggingThumb = false;
            } else {
                float frac = Math.max(0f, Math.min(1f, e.getY() / getHeight()));
                scrollY = frac * maxScrollY();
                postInvalidateOnAnimation();
            }
            return true;
        }
        return detector.onTouchEvent(e);
    }

    // ------------------------------------------------------------------ pewarna sintaks (jendela)

    @SuppressWarnings("unchecked")
    private void ensureCache(int first, int last) {
        if (language == SyntaxHighlighter.LANG_NONE || lines.length == 0) return;
        if (first >= cacheFrom && last <= cacheTo) return;
        int from = Math.max(0, first - WINDOW_MARGIN);
        int to = Math.min(lines.length - 1, last + WINDOW_MARGIN);

        int total = 0;
        for (int i = from; i <= to; i++) total += lines[i].length() + 1;
        cacheFrom = from;
        cacheTo = to;
        cacheTokens = (List<int[]>[]) new List[to - from + 1];
        if (total > MAX_HIGHLIGHT_CHARS) return;     // jendela terlalu besar (kode minify): tanpa warna

        StringBuilder sb = new StringBuilder(total);
        int[] starts = new int[to - from + 2];
        for (int i = from; i <= to; i++) {
            starts[i - from] = sb.length();
            sb.append(lines[i]).append('\n');
        }
        starts[to - from + 1] = sb.length();

        for (int[] t : SyntaxHighlighter.scan(language, sb.toString())) {
            int li = lineOfOffset(starts, t[0]);
            int s = t[0];
            while (li <= to - from && s < t[1]) {
                int lineStart = starts[li];
                int lineEnd = starts[li + 1] - 1;           // tanpa '\n'
                int segEnd = Math.min(t[1], lineEnd);
                if (segEnd > s) {
                    if (cacheTokens[li] == null) cacheTokens[li] = new ArrayList<>();
                    cacheTokens[li].add(new int[]{s - lineStart, segEnd - lineStart, t[2]});
                }
                s = starts[li + 1];
                li++;
            }
        }
        for (List<int[]> l : cacheTokens) {
            if (l != null && l.size() > 1) {
                Collections.sort(l, new Comparator<int[]>() {
                    @Override
                    public int compare(int[] a, int[] b) {
                        return a[0] - b[0];
                    }
                });
            }
        }
    }

    private static int lineOfOffset(int[] starts, int off) {
        int lo = 0, hi = starts.length - 2;
        while (lo < hi) {
            int mid = (lo + hi + 1) >>> 1;
            if (starts[mid] <= off) lo = mid;
            else hi = mid - 1;
        }
        return lo;
    }

    // ------------------------------------------------------------------ gambar

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        canvas.drawColor(colBg);
        if (lines.length == 0) return;

        scrollY = Math.max(0f, Math.min(maxScrollY(), scrollY));

        int first = lineOfRow(Math.max(0, (int) (scrollY / lineH)));
        int last = lineOfRow((int) ((scrollY + h) / lineH));
        ensureCache(first, last);

        float textX0 = gutterW + 12f * density;

        canvas.save();
        canvas.clipRect(gutterW, 0, w, h);
        for (int i = first; i <= last; i++) {
            String line = lines[i];
            int rows = rowOff[i + 1] - rowOff[i];
            if (i == markedLine) {
                float top = rowOff[i] * lineH - scrollY;
                fillPaint.setColor((colAccent & 0x00FFFFFF) | 0x33000000);
                canvas.drawRect(gutterW, top, w, top + rows * lineH, fillPaint);
            }
            List<int[]> toks = (cacheTokens != null && i >= cacheFrom && i <= cacheTo)
                    ? cacheTokens[i - cacheFrom] : null;
            for (int r = 0; r < rows; r++) {
                float top = (rowOff[i] + r) * lineH - scrollY;
                if (top + lineH < 0 || top > h) continue;
                int cs = r * cols;
                int ce = Math.min(line.length(), cs + cols);
                if (cs >= ce) continue;
                float y = top + baseline;
                int pos = cs;
                if (toks != null) {
                    for (int[] t : toks) {
                        if (t[1] <= cs) continue;
                        if (t[0] >= ce) break;
                        int sg = Math.max(t[0], cs);
                        int eg = Math.min(t[1], ce);
                        if (sg < pos) sg = pos;
                        if (sg > pos) drawSeg(canvas, line, pos, sg, cs, textX0, y, colText);
                        if (eg > sg) drawSeg(canvas, line, sg, eg, cs, textX0, y, tokenColors[t[2]]);
                        pos = Math.max(pos, eg);
                    }
                }
                if (pos < ce) drawSeg(canvas, line, pos, ce, cs, textX0, y, colText);
            }
        }
        canvas.restore();

        // gutter (nomor baris): hanya di potongan pertama tiap baris kode
        fillPaint.setColor(colGutterBg);
        canvas.drawRect(0, 0, gutterW, h, fillPaint);
        fillPaint.setColor(colDivider);
        canvas.drawRect(gutterW - density, 0, gutterW, h, fillPaint);
        for (int i = first; i <= last; i++) {
            gutterPaint.setColor(i == markedLine ? colAccent : colGutterNum);
            canvas.drawText(String.valueOf(i + 1), gutterW - 8f * density, rowOff[i] * lineH - scrollY + baseline, gutterPaint);
        }

        // penggeser cepat
        float total = totalHeight();
        if (total > h) {
            float thumbH = Math.max(36f * density, h * h / total);
            float maxY = maxScrollY();
            float ty = maxY <= 0 ? 0 : (scrollY / maxY) * (h - thumbH);
            fillPaint.setColor((colAccent & 0x00FFFFFF) | (draggingThumb ? 0xCC000000 : 0x88000000));
            canvas.drawRoundRect(w - 7f * density, ty, w - 3f * density, ty + thumbH,
                    2f * density, 2f * density, fillPaint);
        }
    }

    /** Menggambar potongan [a,b) dari baris; chunkStart = indeks karakter awal baris tampilan ini. */
    private void drawSeg(Canvas c, String line, int a, int b, int chunkStart, float x0, float y, int color) {
        textPaint.setColor(color);
        c.drawText(line, a, b, x0 + (a - chunkStart) * charW, y, textPaint);
    }
}
