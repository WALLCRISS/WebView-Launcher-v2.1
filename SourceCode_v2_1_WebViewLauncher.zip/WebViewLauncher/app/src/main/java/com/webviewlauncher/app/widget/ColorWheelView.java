package com.webviewlauncher.app.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Roda warna HSV penuh: sudut = hue (0–360), jarak dari pusat = saturasi (0–100%).
 * Kecerahan (value) diatur oleh {@link BrightnessSlider}; roda ikut menggelap sesuai kecerahan.
 * Gabungan hue × saturasi × kecerahan mencakup seluruh warna RGB 24-bit.
 */
public class ColorWheelView extends View {

    public interface Listener {
        void onWheelChanged(float hue, float sat);
    }

    private final Paint huePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint satPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringOuter = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringInner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;
    private float hue = 0f;
    private float sat = 0f;
    private float value = 1f;
    private float cx, cy, radius;
    private Listener listener;

    public ColorWheelView(Context c) {
        this(c, null);
    }

    public ColorWheelView(Context c, AttributeSet a) {
        super(c, a);
        density = getResources().getDisplayMetrics().density;
        ringOuter.setStyle(Paint.Style.STROKE);
        ringOuter.setStrokeWidth(3f * density);
        ringOuter.setColor(0xFFFFFFFF);
        ringInner.setStyle(Paint.Style.STROKE);
        ringInner.setStrokeWidth(1.2f * density);
        ringInner.setColor(0xFF000000);
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public void setHs(float h, float s) {
        hue = h;
        sat = s;
        invalidate();
    }

    public void setValue(float v) {
        value = v;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        int size = Math.min(MeasureSpec.getSize(w), (int) (300 * density));
        setMeasuredDimension(size, size);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        cx = w / 2f;
        cy = h / 2f;
        radius = Math.min(w, h) / 2f - 6f * density;
        int[] colors = new int[361];
        for (int i = 0; i <= 360; i++) colors[i] = Color.HSVToColor(new float[]{i, 1f, 1f});
        huePaint.setShader(new SweepGradient(cx, cy, colors, null));
        satPaint.setShader(new RadialGradient(cx, cy, radius, 0xFFFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawCircle(cx, cy, radius, huePaint);
        c.drawCircle(cx, cy, radius, satPaint);
        dimPaint.setColor(Color.argb((int) (255 * (1f - value)), 0, 0, 0));
        c.drawCircle(cx, cy, radius, dimPaint);

        double ang = Math.toRadians(hue);
        float tx = (float) (cx + Math.cos(ang) * sat * radius);
        float ty = (float) (cy + Math.sin(ang) * sat * radius);
        c.drawCircle(tx, ty, 9f * density, ringOuter);
        c.drawCircle(tx, ty, 9f * density + 1.5f * density, ringInner);
        c.drawCircle(tx, ty, 9f * density - 1.5f * density, ringInner);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                // fallthrough
            case MotionEvent.ACTION_MOVE:
                float dx = e.getX() - cx;
                float dy = e.getY() - cy;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                float a = (float) Math.toDegrees(Math.atan2(dy, dx));
                if (a < 0) a += 360f;
                hue = a;
                sat = Math.min(1f, dist / radius);
                invalidate();
                if (listener != null) listener.onWheelChanged(hue, sat);
                return true;
            default:
                return true;
        }
    }
}
