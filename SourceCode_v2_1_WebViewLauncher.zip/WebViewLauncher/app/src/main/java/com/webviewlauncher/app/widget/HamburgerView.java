package com.webviewlauncher.app.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.PathInterpolator;

import androidx.core.content.ContextCompat;

import com.webviewlauncher.app.R;

/**
 * Logo menu 3 garis. Garis tengah berwarna toska (ciri khas WebView Launcher) dan saat menu
 * terbuka ketiga garis berubah mulus menjadi tanda silang (X).
 */
public class HamburgerView extends View {

    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint midPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float progress = 0f;
    private ValueAnimator animator;

    public HamburgerView(Context context) {
        this(context, null);
    }

    public HamburgerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        float d = getResources().getDisplayMetrics().density;
        linePaint.setColor(ContextCompat.getColor(context, R.color.text_primary));
        linePaint.setStrokeWidth(2.2f * d);
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        midPaint.setColor(com.webviewlauncher.app.theme.Palette.accent(context));
        midPaint.setStrokeWidth(2.2f * d);
        midPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    public float getProgress() {
        return progress;
    }

    public void setProgress(float p) {
        progress = Math.max(0f, Math.min(1f, p));
        invalidate();
    }

    /** Menganimasikan ke 0 (3 garis) atau 1 (silang). */
    public void animateTo(float target, boolean animate) {
        if (animator != null) animator.cancel();
        if (!animate) {
            setProgress(target);
            return;
        }
        animator = ValueAnimator.ofFloat(progress, target);
        animator.setDuration(380);
        animator.setInterpolator(new PathInterpolator(0.22f, 1f, 0.36f, 1f));
        animator.addUpdateListener(a -> setProgress((float) a.getAnimatedValue()));
        animator.start();
    }

    @Override
    protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float half = 10f * d;
        float gap = 6.5f * d;
        float p = progress;

        c.save();
        c.translate(cx, cy - gap * (1f - p));
        c.rotate(45f * p);
        c.drawLine(-half, 0, half, 0, linePaint);
        c.restore();

        midPaint.setAlpha((int) (255 * (1f - p)));
        float mh = half * (1f - p);
        c.drawLine(cx - mh, cy, cx + mh, cy, midPaint);

        c.save();
        c.translate(cx, cy + gap * (1f - p));
        c.rotate(-45f * p);
        c.drawLine(-half, 0, half, 0, linePaint);
        c.restore();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }
}
