package com.webviewlauncher.app.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.PathInterpolator;

import androidx.core.content.ContextCompat;
import androidx.core.graphics.ColorUtils;

import com.webviewlauncher.app.R;

/**
 * Togle bahasa: geser ke kiri = Indonesia (ID), geser ke kanan = Inggris (EN).
 */
public class LangToggle extends View {

    public interface OnToggleListener {
        void onToggle(boolean english);
    }

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float density;
    private final int colorOn;
    private final int colorOff;
    private final int gradStart;
    private final int gradEnd;

    private float baseTextSize = 0f;
    private String leftLabel = "ID";
    private String rightLabel = "EN";
    private float progress = 0f;
    private boolean english = false;
    private ValueAnimator animator;
    private OnToggleListener listener;

    public LangToggle(Context context) {
        this(context, null);
    }

    public LangToggle(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = getResources().getDisplayMetrics().density;
        trackPaint.setColor(ContextCompat.getColor(context, R.color.bg_root));
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(density);
        strokePaint.setColor(ContextCompat.getColor(context, R.color.divider));
        colorOn = com.webviewlauncher.app.theme.Palette.onAccent(com.webviewlauncher.app.theme.Palette.accentDim(context));
        colorOff = ContextCompat.getColor(context, R.color.text_faint);
        gradStart = com.webviewlauncher.app.theme.Palette.accentDim(context);
        gradEnd = com.webviewlauncher.app.theme.Palette.accent(context);
        textPaint.setTextAlign(Paint.Align.CENTER);
        baseTextSize = 13f * density;
        textPaint.setTextSize(baseTextSize);
        setClickable(true);
        setFocusable(true);
        setOnClickListener(v -> {
            setEnglish(!english, true);
            if (listener != null) {
                // Beri waktu animasi geser selesai sebelum bahasa diterapkan (layar dibuat ulang).
                postDelayed(() -> listener.onToggle(english), 280);
            }
        });
    }

    public void setLabels(String left, String right, float textSp) {
        leftLabel = left;
        rightLabel = right;
        baseTextSize = textSp * density;
        textPaint.setTextSize(baseTextSize);
        invalidate();
    }

    public void setOnToggleListener(OnToggleListener l) {
        listener = l;
    }

    public boolean isEnglish() {
        return english;
    }

    public void setEnglish(boolean en, boolean animate) {
        english = en;
        float target = en ? 1f : 0f;
        if (animator != null) animator.cancel();
        if (!animate) {
            progress = target;
            invalidate();
            return;
        }
        animator = ValueAnimator.ofFloat(progress, target);
        animator.setDuration(260);
        animator.setInterpolator(new PathInterpolator(0.22f, 1f, 0.36f, 1f));
        animator.addUpdateListener(a -> {
            progress = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        thumbPaint.setShader(new LinearGradient(0, 0, w, 0, gradStart, gradEnd, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float r = h / 2f;
        float half = density * 0.5f;

        rect.set(half, half, w - half, h - half);
        c.drawRoundRect(rect, r, r, trackPaint);
        c.drawRoundRect(rect, r, r, strokePaint);

        float pad = 3f * density;
        float thumbW = (w - 2 * pad) / 2f;
        float tx = pad + progress * thumbW;
        rect.set(tx, pad, tx + thumbW, h - pad);
        float tr = (h - 2 * pad) / 2f;
        c.drawRoundRect(rect, tr, tr, thumbPaint);

        // Label mengecil otomatis bila tidak muat di dalam penggeser (layar kecil / font besar)
        textPaint.setTextSize(baseTextSize);
        float maxW = thumbW - 10f * density;
        float need = Math.max(textPaint.measureText(leftLabel), textPaint.measureText(rightLabel));
        if (need > maxW && need > 0) textPaint.setTextSize(baseTextSize * maxW / need);
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float baseline = h / 2f - (fm.ascent + fm.descent) / 2f;

        textPaint.setColor(ColorUtils.blendARGB(colorOn, colorOff, progress));
        c.drawText(leftLabel, pad + thumbW / 2f, baseline, textPaint);
        textPaint.setColor(ColorUtils.blendARGB(colorOff, colorOn, progress));
        c.drawText(rightLabel, pad + thumbW * 1.5f, baseline, textPaint);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }
}
