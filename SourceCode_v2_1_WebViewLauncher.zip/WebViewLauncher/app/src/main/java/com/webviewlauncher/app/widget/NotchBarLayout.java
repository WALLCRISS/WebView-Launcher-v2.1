package com.webviewlauncher.app.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.FrameLayout;

import androidx.core.content.ContextCompat;

import com.webviewlauncher.app.R;

/**
 * Bilah tab bawah. Bentuknya sekarang DATAR (lurus): tanpa bayangan dan tanpa lekukan.
 *
 * Ruang kosong di tengah (antara tab Grid Launcher dan Text Editor) tetap dipertahankan lewat
 * {@link #notchWidth(float, float)} supaya posisi logo dan teks kedua tab tidak berubah.
 */
public class NotchBarLayout extends FrameLayout {

    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public NotchBarLayout(Context c) {
        this(c, null);
    }

    public NotchBarLayout(Context c, AttributeSet a) {
        super(c, a);
        setWillNotDraw(false);
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(ContextCompat.getColor(c, R.color.bg_surface));
    }

    /**
     * Lebar ruang tengah (px) untuk lebar layar tertentu: maksimal 120dp dan tidak lebih dari 30%
     * lebar layar. MainActivity memakainya untuk jarak antar tab.
     */
    public static float notchWidth(float widthPx, float density) {
        return Math.min(120f * density, widthPx * 0.30f);
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawRect(0, 0, getWidth(), getHeight(), fillPaint);
    }
}
