package com.webviewlauncher.app.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.PathInterpolator;

import androidx.core.content.ContextCompat;
import androidx.core.graphics.ColorUtils;

import com.webviewlauncher.app.R;

/**
 * Togle hidup/mati bergaya WebView Launcher. Ketukan TIDAK mengubah tampilannya sendiri:
 * pemilik menerima {@link Listener#onRequest(boolean)} lalu memanggil {@link #setChecked}
 * (sehingga bisa menolak atau meminta konfirmasi dulu).
 */
public class OnOffToggle extends View {

    public interface Listener {
        void onRequest(boolean newState);
    }

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint onPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float density;
    private final int knobOff;
    private final int knobOn;
    private final int gradStart;
    private final int gradEnd;

    private boolean checked = false;
    private float progress = 0f;
    private ValueAnimator animator;
    private Listener listener;

    public OnOffToggle(Context context) {
        this(context, null);
    }

    public OnOffToggle(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = getResources().getDisplayMetrics().density;
        trackPaint.setColor(ContextCompat.getColor(context, R.color.bg_root));
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(density);
        strokePaint.setColor(ContextCompat.getColor(context, R.color.divider));
        knobOff = ContextCompat.getColor(context, R.color.text_faint);
        knobOn = com.webviewlauncher.app.theme.Palette.onAccent(com.webviewlauncher.app.theme.Palette.accentDim(context));
        gradStart = com.webviewlauncher.app.theme.Palette.accentDim(context);
        gradEnd = com.webviewlauncher.app.theme.Palette.accent(context);
        setClickable(true);
        setFocusable(true);
        setOnClickListener(v -> {
            if (listener != null) listener.onRequest(!checked);
        });
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean value, boolean animate) {
        if (checked == value && animator == null) {
            progress = value ? 1f : 0f;
            invalidate();
            checked = value;
            return;
        }
        checked = value;
        float target = value ? 1f : 0f;
        if (animator != null) animator.cancel();
        if (!animate) {
            progress = target;
            invalidate();
            return;
        }
        animator = ValueAnimator.ofFloat(progress, target);
        animator.setDuration(240);
        animator.setInterpolator(new PathInterpolator(0.22f, 1f, 0.36f, 1f));
        animator.addUpdateListener(a -> {
            progress = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        onPaint.setShader(new LinearGradient(0, 0, w, 0, gradStart, gradEnd, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float r = h / 2f;
        float half = density * 0.5f;

        rect.set(half, half, w - half, h - half);
        c.drawRoundRect(rect, r, r, trackPaint);
        onPaint.setAlpha((int) (255 * progress));
        c.drawRoundRect(rect, r, r, onPaint);
        c.drawRoundRect(rect, r, r, strokePaint);

        float pad = 4f * density;
        float kr = (h - 2 * pad) / 2f;
        float cx = pad + kr + progress * (w - 2 * pad - 2 * kr);
        knobPaint.setColor(ColorUtils.blendARGB(knobOff, knobOn, progress));
        c.drawCircle(cx, h / 2f, kr, knobPaint);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }
}
