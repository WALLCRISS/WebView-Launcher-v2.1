# Panduan UI: tampilan harus tahan di semua ukuran layar

Bug yang melatarbelakangi: label tab "Grid Launcher" turun ke dua baris di HP berlayar kecil, karena
tiap tab hanya mendapat setengah lebar layar sementara padding 30dp kiri + 30dp kanan, ikon 24dp, dan
jarak ikon memakan hampir semua ruangnya.

## Aturan
1. **Jangan hitung lebar dengan angka tetap.** Bagi ruang dengan `layout_weight` + `0dp`, bukan lebar `dp`
   yang "kira-kira muat di HP saya". Layar 320–360dp harus tetap muat.
2. **Padding horizontal kecil pada elemen berbobot** (≤ 12dp). Padding besar memakan ruang teks.
3. **Label satu baris wajib "tahan sempit":** beri `android:tag="fit"` (teks mengecil otomatis sampai 9sp,
   `maxLines=1`, elipsis). Tag ini juga ikut aktif pada tag `bg_run` dan `on_accent`. Tag boleh digabung
   dengan koma, mis. `android:tag="accent,fit"`.
   - Syarat: lebar view terbatas (`0dp` berbobot atau `match_parent`), bukan `wrap_content`.
4. **Tinggi tetap (dp) hanya bila teksnya dijamin satu baris** (maxLines/fit). Kalau tidak, pakai
   `wrap_content` + `minHeight`.
5. **Teks panjang boleh ke banyak baris, tapi wadahnya harus `wrap_content`** (bukan tinggi tetap).
6. **Teks yang digambar manual di Canvas (widget kustom) harus mengukur lalu mengecilkan sendiri**
   bila tidak muat (lihat `LangToggle.onDraw`).
7. **Daftar yang bisa panjang di layar sempit** (toolbar, tombol simbol) ditaruh di `HorizontalScrollView`.
8. **Uji** di layar kecil (320dp lebar) dan dengan ukuran font sistem "Besar" sebelum rilis.

## Pemeriksa otomatis
```
python3 tools/check_layouts.py
```
Memindai `res/layout*` dan melaporkan: R1 tinggi tetap tanpa maxLines/fit, R2 padding horizontal besar
pada TextView berbobot, R3 lebar tetap ≥ 100dp tanpa maxLines/fit. Keluar dengan kode 1 bila ada temuan,
jadi bisa dijalankan sebelum build atau di CI. Tambahkan aturan baru di skrip itu bila menemukan pola
rawan lain.
