#!/usr/bin/env python3
"""
Pemeriksa layout: mencari pola yang rawan merusak tampilan di layar kecil / font besar.
Jalankan dari folder proyek:  python3 tools/check_layouts.py
Keluar dengan kode 1 bila ada temuan, sehingga bisa dipasang di CI / sebelum build.

Aturan (lihat docs/UI_GUIDELINES.md):
  R1  TextView/Button bertinggi tetap (dp) tapi teksnya bisa lebih dari satu baris
      -> wajib maxLines/singleLine, atau android:tag="fit" (ukuran huruf mengecil otomatis).
  R2  TextView berbobot (layout_weight) dengan padding kiri+kanan >= 40dp
      -> padding besar memakan ruang teks di layar sempit.
  R3  TextView berlebar tetap (dp) >= 100dp tanpa maxLines/singleLine/fit.
"""
import glob, re, sys

DP = re.compile(r'^(\d+(?:\.\d+)?)dp$')

def attr(el, name):
    m = re.search(r'android:%s="([^"]*)"' % name, el)
    return m.group(1) if m else None

def dp(v):
    m = DP.match(v or '')
    return float(m.group(1)) if m else None

problems = []
for f in sorted(glob.glob('app/src/main/res/layout*/*.xml')):
    text = open(f, encoding='utf-8').read()
    for m in re.finditer(r'<(TextView|Button|com\.google\.android\.material\.button\.MaterialButton)\b[^>]*?/?>', text, re.S):
        el = m.group(0)
        line = text[:m.start()].count('\n') + 1
        name = attr(el, 'id') or attr(el, 'text') or '?'
        guarded = ('maxLines' in el or 'singleLine' in el or re.search(r'android:tag="[^"]*fit', el) is not None
                   or 'android:tag="on_accent"' in el or 'android:tag="bg_run"' in el)
        h, w = dp(attr(el, 'layout_height')), dp(attr(el, 'layout_width'))
        weighted = attr(el, 'layout_weight') is not None
        pad = 0.0
        for k in ('paddingStart', 'paddingEnd', 'paddingLeft', 'paddingRight'):
            pad += dp(attr(el, k)) or 0
        p_all = dp(attr(el, 'padding')) or 0
        pad += 2 * p_all
        if h and not guarded:
            problems.append((f, line, name, 'R1 tinggi tetap %gdp tanpa maxLines/fit' % h))
        if weighted and pad >= 40:
            problems.append((f, line, name, 'R2 padding horizontal total %gdp pada TextView berbobot' % pad))
        if w and w >= 100 and not guarded:
            problems.append((f, line, name, 'R3 lebar tetap %gdp tanpa maxLines/fit' % w))

for p in problems:
    print('%s:%d  [%s]  %s' % p)
print('%d temuan' % len(problems))
sys.exit(1 if problems else 0)
